#pragma once
/* ==========================================================================
 *  使用者設定（要改嘢多數改呢個檔就夠）
 * ========================================================================== */

// ---- 螢幕方向 ----
// 0 = 直向, 1 = 橫向, 2 = 直向倒轉, 3 = 橫向上下倒轉（Neil 部機而家用 3）
// 介面係為 320x240 橫向設計，請用 1 或 3。觸控座標會自動跟同一個方向。
#define SCREEN_ROTATION 3

// 如果觸控位置同畫面唔夾（例如撳左邊反應喺右邊），可以獨立改觸控方向：
// #define TOUCH_ROTATION 1
#ifndef TOUCH_ROTATION
#define TOUCH_ROTATION SCREEN_ROTATION
#endif
// 觸控晶片會自動偵測：0x1A = CST328（V1 板）、0x58 = CST3530（V2 板）。
// 如果開咗 TOUCH_DEBUG 見到原始座標（raw）方向唔啱，可以喺「轉方向之前」先調整原始座標：
#define TOUCH_SWAP_XY  0   // 1 = 原始 X / Y 對調
#define TOUCH_MIRROR_X 0   // 1 = 原始 X 左右反轉
#define TOUCH_MIRROR_Y 0   // 1 = 原始 Y 上下反轉
// 原始座標範圍（0 = 用晶片預設：CST328 讀晶片資料，CST3530 = 240x320）
#define TOUCH_RAW_W 0
#define TOUCH_RAW_H 0
// 觸控除錯：改做 1 →
//   畫面：手指位置畫十字，左下角顯示原始座標（raw）同轉換後座標（scr）
//   Serial Monitor（115200）：印出每次觸碰嘅座標
#define TOUCH_DEBUG 0
// 開機畫面嘅觸控測試時間（毫秒）：期間撳畫面會見到一點。觸控有問題時固定顯示 4 秒。0 = 正常時唔等
#define BOOT_TOUCH_TEST_MS 2000

// ---- 背光亮度 0–255 ----
#define BL_DUTY 170

// ---- 更新間隔 ----
#define WEATHER_INTERVAL_MS   (10UL * 60UL * 1000UL)  // 天氣 10 分鐘
#define BUS_INTERVAL_MS       (30UL * 1000UL)         // 儀表板 / 主畫面開住時，巴士 30 秒
#define BUS_IDLE_INTERVAL_MS  (180UL * 1000UL)        // 其他畫面（WiFi / 巴士站設定），3 分鐘
#define WIFI_RETRY_MS         (30UL * 1000UL)         // 斷線後每 30 秒試重連
#define MAX_SAVED_WIFI        5                       // 最多記住 5 個 WiFi

// ---- 天文台 API ----
#define HKO_RHR_URL "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=rhrread&lang=tc"
#define HKO_FND_URL "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=fnd&lang=tc"
#define HKO_WARNSUM_URL "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=warnsum&lang=tc"
#define HKO_FLW_URL "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=flw&lang=tc"
// 溫度測站優先次序（rhrread 入面嘅 place 名）；例如想用元朗就將 "元朗公園" 放第一
static const char *const WEATHER_STATIONS[] = {"香港天文台", "元朗公園", "京士柏"};

// ---- 九巴到站 ----
// 路線喺主畫面「巴士站設定」度設定（最多 3 條，可以唔同巴士站），會記住喺 NVS，重開機都唔會唔見。
// 未設定過（或者撳咗「還原預設」）就用下面三條預設路線（YOHO MALL II／形點 II）。
// 儀表板只顯示最近兩班、唔顯示已開出嘅班次。
#define BUS_MAX_SLOTS 3
struct BusDefault {
  const char *code;      // 站牌號碼
  const char *stopId;    // ETA API 用嘅 16 位站 ID
  const char *stopName;  // 站名（中文，唔包括號碼）
  const char *route;
  char dir;              // 'O' 去程 / 'I' 回程
  uint8_t serviceType;
  const char *dest;      // 目的地（中文）
};
static const BusDefault BUS_DEFAULTS[BUS_MAX_SLOTS] = {
  {"YL395", "4E2EC89B41600D7E", "形點 II", "276",  'O', 1, "上水"},
  {"YL395", "4E2EC89B41600D7E", "形點 II", "276P", 'O', 1, "上水"},
  {"YL392", "723EF8D7809D3ADB", "形點 II", "268X", 'O', 1, "高鐵(西九龍站)"},
};
#define KMB_API "https://data.etabus.gov.hk/v1/transport/kmb"

// ---- 時間 ----
#define TZ_INFO      "HKT-8"
#define NTP_SERVER_1 "stdtime.gov.hk"
#define NTP_SERVER_2 "pool.ntp.org"
#define NTP_SERVER_3 "time.google.com"

// ---- （可選）secrets.h 後備 WiFi ----
// 如果 NVS 入面一個 WiFi 都未記住，而 sketch 資料夾有 secrets.h 定義
// WIFI_SSID / WIFI_PASS，開機就會用佢。冇 secrets.h 一樣可以正常開機。
