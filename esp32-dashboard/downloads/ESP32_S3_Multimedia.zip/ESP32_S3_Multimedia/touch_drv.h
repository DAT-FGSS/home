#pragma once
// 觸控驅動（輪詢方式，同官方 LVGL Demo 一樣唔靠中斷），開機自動偵測晶片：
//   0x1A  CST328   Waveshare ESP32-S3-Touch-LCD-2.8 V1
//         暫存器同讀法跟官方 Demo：Touch_CST328.h / .cpp（16-bit 暫存器）
//   0x58  CST3530  Waveshare ESP32-S3-Touch-LCD-2.8 V2（2026-06-05 起出貨）
//         讀法跟官方 V2 Demo：ESP32-S3-Touch-LCD-2.8-V2-Demo.zip → Touch_CST3530.cpp（32-bit 暫存器）
//   0x5D / 0x14 GT911、0x38 FT6x36、0x15 CST816：常見後備，未喺呢塊板驗證
//
// 穩定性 / 自我診斷：
//   * 開機 reset 觸控晶片，逐個位址試，I2C 線路檢查 + 解鎖，掃描成條 Wire1 印出所有位址
//   * 晶片有 ACK 就當正常（CST328 唔理 0xCACA 檢查碼）
//   * 用唔到時每 2 秒喺 loop 入面再試（每次只係幾毫秒）；每 3 次做一次 reset + 掃描
//   * 連續 I2C 錯誤 → 自動重新初始化
//   * INT（GPIO4）只用嚟做提示：有脈衝但 I2C 用唔到 → 即刻再試；讀取照樣係輪詢
#include <Wire.h>

#ifndef TOUCH_ROTATION
#define TOUCH_ROTATION SCREEN_ROTATION
#endif
#ifndef TOUCH_DEBUG
#define TOUCH_DEBUG 0
#endif
#ifndef TOUCH_SWAP_XY
#define TOUCH_SWAP_XY 0
#endif
#ifndef TOUCH_MIRROR_X
#define TOUCH_MIRROR_X 0
#endif
#ifndef TOUCH_MIRROR_Y
#define TOUCH_MIRROR_Y 0
#endif
#ifndef TOUCH_RAW_W
#define TOUCH_RAW_W 0
#endif
#ifndef TOUCH_RAW_H
#define TOUCH_RAW_H 0
#endif

// ---- CST328（V1）----
#define CST328_REG_NUM     0xD005  // 觸點數（低 4 bit）
#define CST328_REG_XY      0xD000  // 第一點座標
#define CST328_REG_DBGINFO 0xD101  // 進入資訊模式
#define CST328_REG_NORMAL  0xD109  // 回到正常回報模式
#define CST328_REG_INFO    0xD1F4  // 資訊區（含解像度、0xCACA 檢查碼）
// ---- CST3530（V2）----
#define CST3530_REG_DATA     0xD0070000UL  // 觸控資料（9 byte）
#define CST3530_REG_END_READ 0xD00002ABUL  // 讀完確認（清除中斷）
// ---- GT911 ----
#define GT911_REG_ID     0x8140  // 產品 ID（"911"）
#define GT911_REG_CFG_XY 0x8048  // X / Y 最大值
#define GT911_REG_STATUS 0x814E  // bit7 = 有資料，低 4 bit = 點數
#define GT911_REG_POINT1 0x8150

#define TP_RETRY_MS     2000  // 用唔到時隔幾耐再試
#define TP_RESET_EVERY  3     // 每第 3 次重試：硬件 reset + I2C 掃描
#define TP_MAX_ERR_RUN  8     // 連續幾多次 I2C 錯誤就當失去連線
#define TP_ERR_MIN_MS   500   // …而且錯誤要持續最少幾耐（ms）
#define TP_I2C_TIMEOUT  20    // 每次 I2C 傳輸最多等幾耐（ms），唔好阻住畫面

struct TpCand {
  uint8_t addr, chip;
};
// 偵測次序：先 CST328（0x1A），再 CST3530（0x58），之後係後備
static const TpCand TP_CANDS[] = {
  {0x1A, TC_CST328}, {0x58, TC_CST3530}, {0x5D, TC_GT911}, {0x14, TC_GT911}, {0x38, TC_FT6X36}, {0x15, TC_CST816},
};
#define TP_NCANDS (sizeof(TP_CANDS) / sizeof(TP_CANDS[0]))

static bool tpOk = false;
static bool tpWireOn = false;
static bool tpIsrOn = false;
static bool tpDumped = false;
static uint8_t tpChip = TC_NONE, tpAddr = 0;
static uint16_t tpResX = 240, tpResY = 320;  // 晶片原始座標範圍
static uint8_t tpErrRun = 0;
static uint8_t tpFailTries = 0;
static uint32_t tpNextTry = 0, tpLastTry = 0, tpLastInts = 0;
static volatile uint32_t tpIntPulses = 0;

static void IRAM_ATTR tpIsr() { tpIntPulses = tpIntPulses + 1; }

// ===================== I2C 基本讀寫 =====================
static bool tpTx(uint8_t addr, const uint8_t *w, size_t nw) {
  Wire1.beginTransmission(addr);
  Wire1.write(w, nw);
  return Wire1.endTransmission(true) == 0;
}
// 寫暫存器位址再讀。stop=true：中間有 STOP（CST328 Demo 做法）；false：repeated start
static bool tpTxRx(uint8_t addr, const uint8_t *w, size_t nw, uint8_t *r, size_t nr, bool stop) {
  Wire1.beginTransmission(addr);
  Wire1.write(w, nw);
  if (Wire1.endTransmission(stop) != 0) return false;
  if (Wire1.requestFrom(addr, nr) != nr) return false;
  for (size_t i = 0; i < nr; i++) r[i] = Wire1.read();
  return true;
}
static bool tpRd8(uint8_t addr, uint8_t reg, uint8_t *r, size_t n) { return tpTxRx(addr, &reg, 1, r, n, false); }
static bool tpWr8(uint8_t addr, uint8_t reg, uint8_t v) {
  uint8_t w[2] = {reg, v};
  return tpTx(addr, w, 2);
}
static bool tpRd16(uint8_t addr, uint16_t reg, uint8_t *r, size_t n, bool stop) {
  uint8_t w[2] = {(uint8_t)(reg >> 8), (uint8_t)reg};
  return tpTxRx(addr, w, 2, r, n, stop);
}
static bool tpWr16(uint8_t addr, uint16_t reg, const uint8_t *d, size_t n) {
  uint8_t w[6] = {(uint8_t)(reg >> 8), (uint8_t)reg};
  if (n > 4) n = 4;
  for (size_t i = 0; i < n; i++) w[2 + i] = d[i];
  return tpTx(addr, w, 2 + n);
}
static bool tpRd32(uint8_t addr, uint32_t reg, uint8_t *r, size_t n) {
  uint8_t w[4] = {(uint8_t)(reg >> 24), (uint8_t)(reg >> 16), (uint8_t)(reg >> 8), (uint8_t)reg};
  return tpTxRx(addr, w, 4, r, n, false);  // 官方 V2 Demo：endTransmission(false)
}
static bool tpWr32(uint8_t addr, uint32_t reg) {
  uint8_t w[4] = {(uint8_t)(reg >> 24), (uint8_t)(reg >> 16), (uint8_t)(reg >> 8), (uint8_t)reg};
  return tpTx(addr, w, 4);
}
// 0 = 有 ACK；2 = 冇回應（NACK）；4 / 5 = 匯流排錯誤 / 逾時
static uint8_t tpProbe(uint8_t addr) {
  Wire1.beginTransmission(addr);
  return Wire1.endTransmission(true);
}
static uint8_t tpChipFor(uint8_t addr) {
  for (size_t i = 0; i < TP_NCANDS; i++)
    if (TP_CANDS[i].addr == addr) return TP_CANDS[i].chip;
  return TC_NONE;
}

// I2C 線路檢查：SDA 被拉低就打 9 下 SCL + STOP 嘗試解鎖。回傳兩條線係咪都係高
static bool tpCheckLines(bool *sdaHi, bool *sclHi) {
  pinMode(TP_SDA, INPUT_PULLUP);
  pinMode(TP_SCL, INPUT_PULLUP);
  delayMicroseconds(50);
  if (digitalRead(TP_SDA) == LOW && digitalRead(TP_SCL) == HIGH) {
    pinMode(TP_SCL, OUTPUT_OPEN_DRAIN);
    digitalWrite(TP_SCL, HIGH);
    for (int i = 0; i < 9 && digitalRead(TP_SDA) == LOW; i++) {
      digitalWrite(TP_SCL, LOW);
      delayMicroseconds(5);
      digitalWrite(TP_SCL, HIGH);
      delayMicroseconds(5);
    }
    pinMode(TP_SDA, OUTPUT_OPEN_DRAIN);  // STOP：SCL 高時 SDA 由低變高
    digitalWrite(TP_SDA, LOW);
    delayMicroseconds(5);
    digitalWrite(TP_SDA, HIGH);
    delayMicroseconds(5);
    pinMode(TP_SDA, INPUT_PULLUP);
    pinMode(TP_SCL, INPUT_PULLUP);
    delayMicroseconds(50);
  }
  *sdaHi = digitalRead(TP_SDA) == HIGH;
  *sclHi = digitalRead(TP_SCL) == HIGH;
  return *sdaHi && *sclHi;
}

// 掃描 Wire1，印出「所有」有回應嘅位址，記低頭 8 個。回傳裝置數
static int tpScan() {
  int n = 0, errs = 0;
  Serial.printf("[TP] I2C scan Wire1 (SDA=%d SCL=%d):", TP_SDA, TP_SCL);
  for (uint8_t a = 0x08; a < 0x78; a++) {
    uint8_t e = tpProbe(a);
    if (e == 0) {
      if (n < TOUCH_FOUND_MAX) gTouch.found[n] = a;
      n++;
      Serial.printf(" 0x%02X", a);
      uint8_t c = tpChipFor(a);
      if (c) Serial.printf("(%s)", touchChipName(c));
    } else if (e != 2 && ++errs >= 3) {
      Serial.print(" ...匯流排錯誤/逾時，掃描中止");
      break;
    }
  }
  if (n == 0) Serial.print(" 冇任何裝置回應");
  Serial.printf("  [共 %d 個]\n", n);
  gTouch.devCount = (uint8_t)(n > 255 ? 255 : n);
  return n;
}
static void tpHex(const char *label, const uint8_t *b, size_t n) {
  Serial.printf("[TP]   %-14s", label);
  for (size_t i = 0; i < n; i++) Serial.printf(" %02X", b[i]);
  Serial.println();
}
// 唔認得嘅晶片：試幾種常見暫存器格式，印出嚟方便認晶片
static void tpDumpUnknown(uint8_t addr) {
  uint8_t b[16];
  Serial.printf("[TP] 唔認得 0x%02X，試讀常見暫存器（請將以下幾行影低）：\n", addr);
  memset(b, 0xEE, sizeof(b));
  bool ok = tpRd8(addr, 0x00, b, 16);
  tpHex(ok ? "reg8 0x00:" : "reg8 0x00 ERR", b, 16);
  memset(b, 0xEE, sizeof(b));
  ok = tpRd8(addr, 0xA0, b, 16);
  tpHex(ok ? "reg8 0xA0:" : "reg8 0xA0 ERR", b, 16);
  memset(b, 0xEE, sizeof(b));
  ok = tpRd16(addr, 0x8140, b, 8, false);
  tpHex(ok ? "reg16 0x8140:" : "reg16 0x8140 ERR", b, 8);
  memset(b, 0xEE, sizeof(b));
  ok = tpRd16(addr, 0xD000, b, 8, true);
  tpHex(ok ? "reg16 0xD000:" : "reg16 0xD000 ERR", b, 8);
  memset(b, 0xEE, sizeof(b));
  ok = tpRd32(addr, CST3530_REG_DATA, b, 9);
  tpHex(ok ? "reg32 D0070000:" : "reg32 D0070000 ERR", b, 9);
}

// ===================== 各晶片初始化 =====================
static bool cst328Init(uint8_t addr, uint16_t *check) {
  uint8_t buf[24] = {0};
  bool info = false;
  for (int i = 0; i < 3 && !info; i++) {
    if (i) delay(10);
    if (!tpWr16(addr, CST328_REG_DBGINFO, nullptr, 0)) continue;
    info = tpRd16(addr, CST328_REG_INFO, buf, 24, true);
  }
  if (info) {
    *check = ((uint16_t)buf[11] << 8) | buf[10];
    uint16_t rx = ((uint16_t)buf[5] << 8) | buf[4];
    uint16_t ry = ((uint16_t)buf[7] << 8) | buf[6];
    if (rx >= 100 && rx <= 1000 && ry >= 100 && ry <= 1000) {
      tpResX = rx;
      tpResY = ry;
    }
  }
  // 返正常模式：失敗嘅話晶片會停喺資訊模式唔報觸點，所以要試多幾次
  bool normal = false;
  for (int i = 0; i < 5 && !normal; i++) {
    if (i) delay(5);
    normal = tpWr16(addr, CST328_REG_NORMAL, nullptr, 0);
  }
  uint8_t clr = 0;
  tpWr16(addr, CST328_REG_NUM, &clr, 1);
  Serial.printf("[TP] CST328 info=%d check=0x%04X%s res=%ux%u normal=%d\n", info, *check,
                (info && *check != 0xCACA) ? "(唔係0xCACA，照用)" : "", tpResX, tpResY, normal);
  if (!normal) Serial.println("[TP] 警告：返唔到正常模式，可能冇觸點回報；出錯後會自動重新初始化");
  return info;
}
static bool tpChipInit(uint8_t chip, uint8_t addr) {
  uint8_t b[16] = {0};
  bool info = false;
  tpResX = 240;
  tpResY = 320;
  switch (chip) {
    case TC_CST328: {
      uint16_t check = 0;
      info = cst328Init(addr, &check);
      break;
    }
    case TC_CST3530:
      // 官方 V2 Demo 冇額外初始化；讀一次資料區確認讀得到，再送「讀完」
      for (int i = 0; i < 3 && !info; i++) {
        if (i) delay(10);
        info = tpRd32(addr, CST3530_REG_DATA, b, 9);
      }
      tpWr32(addr, CST3530_REG_END_READ);
      if (info) tpHex("CST3530 data:", b, 9);
      else Serial.println("[TP] CST3530：讀唔到資料區（照用）");
      break;
    case TC_GT911:
      info = tpRd16(addr, GT911_REG_ID, b, 4, false);
      if (info) {
        Serial.printf("[TP] GT911 ID=\"%c%c%c%c\"\n", isprint(b[0]) ? b[0] : '?', isprint(b[1]) ? b[1] : '?',
                      isprint(b[2]) ? b[2] : '?', isprint(b[3]) ? b[3] : '?');
        if (tpRd16(addr, GT911_REG_CFG_XY, b, 4, false)) {
          uint16_t mx = b[0] | (b[1] << 8), my = b[2] | (b[3] << 8);
          if (mx >= 100 && mx <= 4096 && my >= 100 && my <= 4096) {
            tpResX = mx;
            tpResY = my;
          }
        }
      }
      b[0] = 0;
      tpWr16(addr, GT911_REG_STATUS, b, 1);
      break;
    case TC_FT6X36:
    case TC_CST816:
      if (chip == TC_CST816) tpWr8(addr, 0xFE, 0x01);  // CST816：關閉自動休眠（休眠時唔應 I2C）
      info = tpRd8(addr, 0xA3, b, 6);                   // FT: A3 = chip ID；CST816: A7 = chip ID
      if (info) tpHex("ID regs A3..A8:", b, 6);
      break;
  }
  if (TOUCH_RAW_W > 0) tpResX = TOUCH_RAW_W;
  if (TOUCH_RAW_H > 0) tpResY = TOUCH_RAW_H;
  gTouch.rawW = tpResX;
  gTouch.rawH = tpResY;
  return info;
}

static void tpResetPulse(bool forBoot) {
  // CST328 Demo：HIGH 50ms → LOW 5ms → HIGH；CST3530 Demo：LOW 100ms → HIGH，再等 500ms
  pinMode(TP_RST, OUTPUT);
  if (forBoot) {
    digitalWrite(TP_RST, HIGH);
    delay(50);
  }
  digitalWrite(TP_RST, LOW);
  delay((tpChip == TC_CST328) ? 5 : (forBoot ? 20 : 100));
  digitalWrite(TP_RST, HIGH);
}
static void tpSetStat(uint8_t st) {
  bool fail = !(st == TS_OK || st == TS_OK_NOINFO);
  if (gTouch.stat != st || gTouch.fail != fail) bumpVer();  // 主畫面紅色指示要重畫
  gTouch.stat = st;
  gTouch.fail = fail;
}
static void tpPrintStat() {
  char l1[96], l2[96];
  uint16_t c;
  touchStatusText(l1, sizeof(l1), l2, sizeof(l2), &c);
  Serial.printf("[TP] %s | %s\n", l1, l2);
}
// 試所有候選位址（已知晶片就只試嗰個）。搵到回傳 true
static bool tpFindChip(uint8_t *chip, uint8_t *addr) {
  for (size_t i = 0; i < TP_NCANDS; i++) {
    if (tpChip && TP_CANDS[i].addr != tpAddr) continue;
    if (tpProbe(TP_CANDS[i].addr) == 0) {
      *chip = TP_CANDS[i].chip;
      *addr = TP_CANDS[i].addr;
      return true;
    }
  }
  return false;
}

// doReset：開機 reset（等晶片開機，最多約 0.6 秒）；full：重新開 Wire1 + 線路檢查 + 掃描
static bool touchBegin(bool doReset = true, bool full = true) {
  gTouch.inits++;
  if (!tpIsrOn) {
    pinMode(TP_INT, INPUT);
    attachInterrupt(TP_INT, tpIsr, RISING);  // 只係計數做提示
    tpIsrOn = true;
  }
  bool sdaHi = true, sclHi = true;
  if (full || !tpWireOn) {
    if (tpWireOn) Wire1.end();
    tpWireOn = false;
    tpCheckLines(&sdaHi, &sclHi);
    gTouch.sdaLow = !sdaHi;
    gTouch.sclLow = !sclHi;
    tpWireOn = Wire1.begin(TP_SDA, TP_SCL, TP_I2C_HZ);
    if (tpWireOn) Wire1.setTimeOut(TP_I2C_TIMEOUT);
  }
  uint32_t rel = millis();
  if (doReset) {
    tpResetPulse(true);
    rel = millis();
    delay(50);
  }
  if (!tpWireOn) {
    tpOk = false;
    if (full) {
      tpSetStat(TS_BUS_FAIL);
      Serial.println("[TP] Wire1.begin() 失敗");
      tpPrintStat();
    }
    return false;
  }
  uint8_t chip = TC_NONE, addr = 0;
  bool ack = tpFindChip(&chip, &addr);
  // 開機：逐個位址試，等晶片開機（CST3530 官方等 500ms）
  while (!ack && doReset && millis() - rel < 600) {
    delay(25);
    ack = tpFindChip(&chip, &addr);
  }
  if (!ack && !doReset) {
    delay(2);
    ack = tpFindChip(&chip, &addr);
  }
  if (full) {
    tpScan();
    if (!ack) {  // 掃描見到候選位址都照用
      int k = gTouch.devCount < TOUCH_FOUND_MAX ? gTouch.devCount : TOUCH_FOUND_MAX;
      for (size_t c = 0; c < TP_NCANDS && !ack; c++)
        for (int i = 0; i < k && !ack; i++)
          if (gTouch.found[i] == TP_CANDS[c].addr && (!tpChip || TP_CANDS[c].addr == tpAddr)) {
            chip = TP_CANDS[c].chip;
            addr = TP_CANDS[c].addr;
            ack = true;
          }
    }
  }
  if (!ack) {
    tpOk = false;
    if (full) {
      if (!sdaHi || !sclHi) tpSetStat(TS_BUS_STUCK);
      else if (gTouch.devCount > 0) tpSetStat(TS_OTHER_ADDR);
      else if (gTouch.stat != TS_LOST) tpSetStat(TS_NO_CHIP);
      Serial.printf("[TP] 搵唔到支援嘅觸控晶片（試咗 0x1A 0x58 0x5D 0x14 0x38 0x15；SDA=%d SCL=%d INT脈衝=%u）\n", sdaHi,
                    sclHi, (unsigned)tpIntPulses);
      if (tpIntPulses) Serial.println("[TP] 提示：INT(GPIO4) 有脈衝 → 晶片應該有電，問題似乎喺 I2C 線（SDA1/SCL3）");
      if (gTouch.stat == TS_OTHER_ADDR && !tpDumped) {
        tpDumped = true;
        tpDumpUnknown(gTouch.found[0]);
      }
      tpPrintStat();
    }
    return false;
  }
  if (doReset && chip == TC_CST3530) {  // 官方 V2 Demo：reset 後等 500ms 先讀
    uint32_t el = millis() - rel;
    if (el < 500) delay(500 - el);
  }
  if (tpChip != chip || tpAddr != addr)
    Serial.printf("[TP] 偵測到觸控晶片：%s @0x%02X\n", touchChipName(chip), addr);
  tpChip = chip;
  tpAddr = addr;
  gTouch.chip = chip;
  gTouch.addr = addr;
  bool info = tpChipInit(chip, addr);
  tpOk = true;
  tpErrRun = 0;
  tpFailTries = 0;
  tpSetStat(info ? TS_OK : TS_OK_NOINFO);
  Serial.printf("[TP] %s @0x%02X OK  info=%d raw=%ux%u  SCREEN_ROTATION=%d TOUCH_ROTATION=%d SWAP=%d MIRROR_X=%d MIRROR_Y=%d\n",
                touchChipName(chip), addr, info, tpResX, tpResY, SCREEN_ROTATION, TOUCH_ROTATION, TOUCH_SWAP_XY,
                TOUCH_MIRROR_X, TOUCH_MIRROR_Y);
  tpPrintStat();
  return true;
}

// 用唔到時喺 loop 度叫：每次最多幾毫秒（掃描 / reset 嗰次約 20–120ms）
static void tpRetry(uint32_t now) {
  tpLastTry = now;
  tpFailTries++;
  bool big = (tpFailTries % TP_RESET_EVERY) == 0;
  if (touchBegin(false, big)) {
    Serial.println("[TP] 觸控恢復正常");
    return;
  }
  if (big) tpResetPulse(false);  // 晶片有成 2 秒時間開機，下次再試
  tpNextTry = millis() + TP_RETRY_MS;
}
static void tpIoError(uint32_t now) {
  static uint32_t runStart = 0;
  gTouch.errCount++;
  if (tpErrRun == 0) runStart = now;
  if (tpErrRun < 255) tpErrRun++;
  // 要連續錯 8 次，而且持續超過 0.5 秒先當失去連線（偶然一兩次錯唔會觸發 reset）
  if (tpErrRun < TP_MAX_ERR_RUN || now - runStart < TP_ERR_MIN_MS) return;
  Serial.printf("[TP] %s 連續 %d 次以上 I2C 錯誤，重新初始化觸控\n", touchChipName(tpChip), TP_MAX_ERR_RUN);
  tpOk = false;
  tpErrRun = 0;
  tpFailTries = TP_RESET_EVERY - 1;  // 下一次就係 reset + 掃描
  tpSetStat(TS_LOST);
  tpResetPulse(false);
  tpNextTry = millis() + (tpChip == TC_CST328 ? 300 : 600);  // 等晶片開機
}

// ===================== 各晶片讀觸點 =====================
// 回傳 1 = 有觸碰（*rx, *ry = 原始座標）、0 = 冇、-1 = I2C 錯誤
static int tpChipRead(int *rx, int *ry) {
  uint8_t b[9];
  uint8_t clr = 0;
  switch (tpChip) {
    case TC_CST328: {
      uint8_t n = 0;
      if (!tpRd16(tpAddr, CST328_REG_NUM, &n, 1, true)) return -1;
      uint8_t cnt = n & 0x0F;
      if (cnt == 0 || cnt > 5) return tpWr16(tpAddr, CST328_REG_NUM, &clr, 1) ? 0 : -1;
      bool ok = tpRd16(tpAddr, CST328_REG_XY, b, 5, true);
      bool okClr = tpWr16(tpAddr, CST328_REG_NUM, &clr, 1);
      if (!ok || !okClr) return -1;
      *rx = ((int)b[1] << 4) | (b[3] >> 4);
      *ry = ((int)b[2] << 4) | (b[3] & 0x0F);
      return 1;
    }
    case TC_CST3530: {  // 官方 V2 Demo：Touch2_Read_Data()
      if (!tpRd32(tpAddr, CST3530_REG_DATA, b, 9)) return -1;
      uint8_t cnt = b[3] & 0x0F;
      bool okEnd = tpWr32(tpAddr, CST3530_REG_END_READ);
      if (cnt == 0 || cnt > 5 || (b[8] & 0xF0) == 0) return okEnd ? 0 : -1;
      if (!okEnd) return -1;
      *rx = ((int)(b[7] & 0x0F) << 8) | b[4];
      *ry = ((int)(b[7] & 0xF0) << 4) | b[5];
      return 1;
    }
    case TC_GT911: {
      uint8_t st = 0;
      if (!tpRd16(tpAddr, GT911_REG_STATUS, &st, 1, false)) return -1;
      if (!(st & 0x80)) return 0;  // 未有新資料
      uint8_t cnt = st & 0x0F;
      bool ok = (cnt > 0 && cnt <= 5) ? tpRd16(tpAddr, GT911_REG_POINT1, b, 4, false) : true;
      bool okClr = tpWr16(tpAddr, GT911_REG_STATUS, &clr, 1);
      if (!ok || !okClr) return -1;
      if (cnt == 0 || cnt > 5) return 0;
      *rx = b[0] | (b[1] << 8);
      *ry = b[2] | (b[3] << 8);
      return 1;
    }
    case TC_FT6X36:
    case TC_CST816: {
      if (!tpRd8(tpAddr, 0x02, b, 5)) return -1;
      uint8_t cnt = b[0] & 0x0F;
      if (cnt == 0 || cnt > 5 || (b[1] >> 6) == 1) return 0;  // event 1 = 放手
      *rx = ((int)(b[1] & 0x0F) << 8) | b[2];
      *ry = ((int)(b[3] & 0x0F) << 8) | b[4];
      return 1;
    }
    default: return -1;
  }
}

// 讀一點；有觸碰回傳 true，(x, y) 已轉換成畫面座標
static bool touchRead(int16_t *x, int16_t *y) {
  uint32_t now = millis();
  uint32_t ints = tpIntPulses;
  gTouch.intCount = ints;
  if (!tpOk) {
    bool intHint = ints != tpLastInts;  // 有 INT 脈衝 = 晶片應該喺度 → 早啲再試
    tpLastInts = ints;
    if ((int32_t)(now - tpNextTry) >= 0 || (intHint && now - tpLastTry > 500)) tpRetry(now);
    if (!tpOk) return false;
  }
  int rx = 0, ry = 0;
  int r = tpChipRead(&rx, &ry);
  if (r < 0) {
    tpIoError(now);
    return false;
  }
  tpErrRun = 0;
  if (r == 0) return false;
  gTouch.rawX = rx;
  gTouch.rawY = ry;
  // 1) 原始座標調整（config.h：TOUCH_MIRROR_X / TOUCH_MIRROR_Y / TOUCH_SWAP_XY）
  int w = tpResX, h = tpResY;
  if (TOUCH_MIRROR_X) rx = w - 1 - rx;
  if (TOUCH_MIRROR_Y) ry = h - 1 - ry;
  if (TOUCH_SWAP_XY) {
    int t = rx; rx = ry; ry = t;
    t = w; w = h; h = t;
  }
  // 2) 縮放到直向 240x320
  if (w != 240 && w > 0) rx = rx * 240 / w;
  if (h != 320 && h > 0) ry = ry * 320 / h;
  if (rx < 0) rx = 0;
  if (rx > 239) rx = 239;
  if (ry < 0) ry = 0;
  if (ry > 319) ry = 319;
  // 3) 直向（rotation 0）畫面座標 → 跟 Arduino_GFX 嘅旋轉方式轉換
  switch (TOUCH_ROTATION & 3) {
    case 0: *x = rx; *y = ry; break;
    case 1: *x = ry; *y = 239 - rx; break;
    case 2: *x = 239 - rx; *y = 319 - ry; break;
    default: *x = 319 - ry; *y = rx; break;
  }
  gTouch.x = *x;
  gTouch.y = *y;
  gTouch.lastMs = now;
  gTouch.seen = true;
#if TOUCH_DEBUG
  static uint32_t lastPrint = 0;
  if (now - lastPrint > 50) {
    lastPrint = now;
    Serial.printf("[TP] %s raw=%d,%d -> scr=%d,%d (TOUCH_ROTATION=%d)\n", touchChipName(tpChip), gTouch.rawX, gTouch.rawY,
                  *x, *y, TOUCH_ROTATION);
  }
#endif
  return true;
}
