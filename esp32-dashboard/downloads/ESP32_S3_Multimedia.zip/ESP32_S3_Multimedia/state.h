#pragma once
// 各工作（UI / 網絡）之間共用嘅資料
#include <time.h>
#include <string.h>

#ifdef HOST_MOCKUP
#define STATE_LOCK()
#define STATE_UNLOCK()
#else
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
static SemaphoreHandle_t gLock = nullptr;
#define STATE_LOCK() xSemaphoreTake(gLock, portMAX_DELAY)
#define STATE_UNLOCK() xSemaphoreGive(gLock)
#endif

// ---------- 天氣 ----------
struct WeatherNow {
  bool valid;
  int icon;
  int tempC;
  int humidity;   // -1 = 冇
  bool failed;    // 上次更新失敗
};
struct ForecastDay {
  bool valid;
  int icon;
  int minC, maxC;
  char week[16];  // 「星期三」
};
static WeatherNow gWeather = {false, 50, -999, -1, false};
static ForecastDay gForecast[3];

// ---------- 巴士 ----------
#define BUS_MAX_ETA 3
struct BusInfo {
  bool valid;            // 至少成功攞過一次
  bool failed;           // 上次失敗
  uint8_t n;             // 有效（未開出）班次數
  time_t eta[BUS_MAX_ETA];
  bool sched[BUS_MAX_ETA];  // 「原定班次」（非實時）
};
static BusInfo gBus[BUS_MAX_SLOTS];
static volatile bool gBusFetching = false;

// 巴士站設定：每一格 = 一個站 + 一條路線（可以唔同站）。UI 改，網絡工作讀（要 STATE_LOCK）
struct BusSlot {
  bool used;
  char route[6];        // 例如 "276P"
  char dir;             // 'O' / 'I'（0 = 唔分方向）
  uint8_t serviceType;  // 通常係 1
  char stopId[17];      // 16 位站 ID
  char code[8];         // 站牌號碼，例如 "YL395"（冇就空）
  char stopName[49];    // 站名（中文）
  char dest[37];        // 目的地（中文）
};
static BusSlot gBusCfg[BUS_MAX_SLOTS];
static volatile uint32_t gBusCfgVer = 0;  // 設定改咗 +1 → 網絡工作清舊資料、即刻重新攞

// 巴士站設定嘅搜尋結果（網絡工作寫，UI 讀）
#define BS_MAX_STOPS 8
#define BS_MAX_ROUTES 32
struct BusStopCand {
  char id[17];
  char code[8];
  char name[49];
};
struct BusRouteOpt {
  char route[6];
  char dir;
  uint8_t serviceType;
  uint8_t stop;         // 屬於 stops[] 第幾個站
  char dest[37];
};
enum BusSearchSt : uint8_t {
  BSS_IDLE = 0,
  BSS_BUSY,      // 搜尋中
  BSS_STOPS,     // 搵到幾個站，要使用者揀
  BSS_ROUTES,    // 已經有站 + 路線列表
  BSS_ROUTE_OK,  // 手動輸入嘅路線查到（結果喺 checked）
  BSS_FAIL       // 失敗（原因喺 msg）
};
struct BusSearch {
  uint8_t st;          // BusSearchSt
  char msg[64];
  char progress[40];   // 搜尋中顯示嘅進度
  char query[33];      // 使用者輸入（已整理）
  uint8_t nStops;
  BusStopCand stops[BS_MAX_STOPS];
  uint8_t nRoutes;
  BusRouteOpt routes[BS_MAX_ROUTES];
  bool routesFailed;   // 攞唔到路線列表（仍然可以手動輸入）
  BusRouteOpt checked;
};
static BusSearch gBusS;
static char gBusQ[33];          // UI → 網絡：搜尋字串 / 手動輸入嘅路線
static volatile uint8_t gBusQStop = 0;  // UI → 網絡：揀咗邊個站

// 整理使用者輸入嘅巴士站：回傳 1 = 站牌號碼（YL395 / KT512a），2 = 16 位站 ID，3 = 英文站名關鍵字，0 = 太短
static int busClassify(const char *in, char *out, size_t n) {
  size_t k = 0;
  bool lastSp = true;
  for (const char *p = in; *p && k + 1 < n; p++) {  // 去頭尾空格、多個空格變一個、轉大楷
    char c = *p;
    if (c == ' ') {
      if (!lastSp) out[k++] = ' ';
      lastSp = true;
      continue;
    }
    lastSp = false;
    out[k++] = (c >= 'a' && c <= 'z') ? c - 32 : c;
  }
  while (k && out[k - 1] == ' ') k--;
  out[k] = 0;
  auto isU = [](char c) { return c >= 'A' && c <= 'Z'; };
  auto isD = [](char c) { return c >= '0' && c <= '9'; };
  // 「YL 395」咁打都當站牌號碼：去晒空格再睇
  char ns[33];
  size_t m = 0;
  for (size_t i = 0; i < k && m + 1 < sizeof(ns); i++)
    if (out[i] != ' ') ns[m++] = out[i];
  ns[m] = 0;
  if (m >= 5 && m <= 6 && m != k && isU(ns[0]) && isU(ns[1]) && isD(ns[2])) {
    memcpy(out, ns, m + 1);
    k = m;
  }
  if ((k == 5 || k == 6) && isU(out[0]) && isU(out[1]) && isD(out[2]) && isD(out[3]) && isD(out[4]) &&
      (k == 5 || isU(out[5]))) {
    if (k == 6) out[5] = out[5] + 32;  // 後綴用細楷（KT512a）
    return 1;
  }
  if (k == 16) {
    bool hex = true;
    for (size_t i = 0; i < 16; i++)
      if (!isD(out[i]) && !(out[i] >= 'A' && out[i] <= 'F')) hex = false;
    if (hex) return 2;
  }
  return k >= 3 ? 3 : 0;
}
// 安全複製 UTF-8（唔會切開半個中文字）。九巴資料用嘅「‧」(U+2027) 字型冇，順手換做「·」
static void utf8Copy(char *dst, size_t n, const char *src) {
  size_t L = strlen(src);
  if (L >= n) {
    L = n - 1;
    while (L > 0 && ((uint8_t)src[L] & 0xC0) == 0x80) L--;
  }
  memmove(dst, src, L);
  dst[L] = 0;
  for (char *p = dst; (p = strstr(p, "\xE2\x80\xA7")) != nullptr;) {
    p[0] = (char)0xC2;
    p[1] = (char)0xB7;
    memmove(p + 2, p + 3, strlen(p + 3) + 1);
    p += 2;
  }
}
// 「形點 II (YL395)」→ name「形點 II」、code「YL395」
static void busSplitName(const char *full, char *name, size_t nn, char *code, size_t cn) {
  char tmp[96];
  utf8Copy(tmp, sizeof(tmp), full);
  if (code && cn) code[0] = 0;
  size_t L = strlen(tmp);
  while (L && tmp[L - 1] == ' ') tmp[--L] = 0;
  if (L >= 7 && tmp[L - 1] == ')') {
    char *op = strrchr(tmp, '(');
    if (op) {
      size_t cl = (size_t)(tmp + L - 1 - (op + 1));
      bool ok = (cl == 5 || cl == 6);
      for (size_t i = 0; ok && i < cl; i++) {  // 2 個大楷 + 3 個數字 +（可能）1 個細楷，例如 YL395、KT512a
        char c = op[1 + i];
        ok = i < 2 ? (c >= 'A' && c <= 'Z') : (i < 5 ? (c >= '0' && c <= '9') : (c >= 'a' && c <= 'z'));
      }
      if (ok) {
        if (code && cn) {
          size_t m = cl < cn - 1 ? cl : cn - 1;
          memcpy(code, op + 1, m);
          code[m] = 0;
        }
        *op = 0;
        L = strlen(tmp);
        while (L && tmp[L - 1] == ' ') tmp[--L] = 0;
      }
    }
  }
  utf8Copy(name, nn, tmp);
}
static void busSlotFromDefault(BusSlot &s, const BusDefault &d) {
  memset(&s, 0, sizeof(s));
  s.used = true;
  utf8Copy(s.route, sizeof(s.route), d.route);
  s.dir = d.dir;
  s.serviceType = d.serviceType;
  utf8Copy(s.stopId, sizeof(s.stopId), d.stopId);
  utf8Copy(s.code, sizeof(s.code), d.code);
  utf8Copy(s.stopName, sizeof(s.stopName), d.stopName);
  utf8Copy(s.dest, sizeof(s.dest), d.dest);
}

// ---------- WiFi ----------
#define SCAN_MAX 20
struct ScanItem {
  char ssid[33];
  int8_t rssi;
  bool secure;
};
struct SavedNet {
  char ssid[33];
  char pass[65];
};
enum UserConn : uint8_t { UC_NONE = 0, UC_BUSY, UC_OK, UC_FAIL };
struct NetState {
  bool connected;
  bool connecting;        // 背景自動連線中
  bool timeSynced;
  char ssid[33];
  char ip[16];
  int8_t rssi;
  uint8_t scanState;      // 0 未掃描, 1 掃描中, 2 完成
  uint8_t scanCount;
  ScanItem scan[SCAN_MAX];
  uint8_t savedCount;
  SavedNet saved[MAX_SAVED_WIFI];
  UserConn userConn;      // 使用者喺 WiFi 設定撳「連線」嘅結果
  char userMsg[64];
};
static NetState gNet;

// UI → 網絡工作 嘅指令
enum NetCmd : uint8_t { NC_NONE = 0, NC_SCAN, NC_CONNECT, NC_FORGET, NC_BUS_FIND, NC_BUS_ROUTES, NC_BUS_CHECK };
static volatile NetCmd gNetCmd = NC_NONE;
static char gCmdSsid[33];
static char gCmdPass[65];
static volatile bool gDashboardActive = false;  // 儀表板或主畫面開住（巴士資料要密啲更新）
static volatile bool gBusForce = false;

// ---------- 觸控診斷（只有 UI loop 讀寫；ISR 只改 INT 計數）----------
enum TouchStat : uint8_t {
  TS_UNKNOWN = 0,  // 未初始化
  TS_OK,           // 認得嘅觸控晶片有回應
  TS_OK_NOINFO,    // 晶片有回應，但讀唔到晶片資料（照用）
  TS_NO_CHIP,      // I2C 上冇任何裝置回應
  TS_OTHER_ADDR,   // I2C 上有裝置，但位址唔係支援嘅觸控晶片
  TS_BUS_STUCK,    // SDA / SCL 被拉低
  TS_BUS_FAIL,     // Wire1.begin() 失敗
  TS_LOST          // 本來正常，之後連續 I2C 錯誤
};
// 支援嘅觸控晶片（自動偵測）
enum TouchChip : uint8_t {
  TC_NONE = 0,
  TC_CST328,   // 0x1A：Waveshare ESP32-S3-Touch-LCD-2.8 V1
  TC_CST3530,  // 0x58：Waveshare ESP32-S3-Touch-LCD-2.8 V2（2026 年 6 月起出貨）
  TC_GT911,    // 0x5D / 0x14（後備，未喺呢塊板驗證）
  TC_FT6X36,   // 0x38（後備，未喺呢塊板驗證）
  TC_CST816    // 0x15（後備，未喺呢塊板驗證）
};
#define TOUCH_FOUND_MAX 8
struct TouchDiag {
  uint8_t stat;        // TouchStat
  bool fail;           // true = 觸控而家用唔到（主畫面狀態列會有紅色「觸控」）
  uint8_t chip;        // TouchChip：偵測到嘅晶片
  uint8_t addr;        // 用緊嘅 I2C 位址
  uint8_t devCount;    // I2C 掃描見到幾多個裝置
  uint8_t found[TOUCH_FOUND_MAX];  // 掃描見到嘅位址（最多 8 個）
  bool sdaLow, sclLow; // 開機檢查時線路被拉低
  bool seen;           // 開機後收過最少一次觸碰
  int16_t rawX, rawY;  // 晶片原始座標
  uint16_t rawW, rawH; // 晶片座標範圍（用嚟縮放到 240x320）
  int16_t x, y;        // 轉換後嘅畫面座標（320x240）
  uint32_t lastMs;     // 最後一次讀到觸碰嘅時間
  uint32_t intCount;   // INT（GPIO4）脈衝數
  uint32_t errCount;   // I2C 錯誤總數
  uint16_t inits;      // 初始化次數
};
static TouchDiag gTouch = {};


// ---------- 天文台天氣警告（warnsum）----------
#define WX_WARN_MAX 6
struct WxWarn {
  char code[12];   // 例如 TC8NE、WRAINA、WFIREY
  char name[28];   // 短名（顯示用）
};
struct WxWarnSum {
  bool valid;
  bool failed;
  uint8_t n;
  WxWarn items[WX_WARN_MAX];
};
static WxWarnSum gWxWarn = {};

// ---------- 計時／倒數／鬧鐘（UI loop 推進；跨畫面仍運作）----------
enum AlertKind : uint8_t { ALERT_NONE = 0, ALERT_COUNTDOWN, ALERT_ALARM };
struct TimerRT {
  // 計時（碼錶）
  bool swRun;
  uint32_t swAcc;     // 已累積 ms（暫停時）
  uint32_t swStart;   // 開始／繼續時嘅 millis
  // 倒數
  bool cdRun;
  uint32_t cdLeft;    // 剩餘 ms
  uint32_t cdTick;    // 上次推進時間
  uint8_t cdSetM;    // 設定分鐘 0–99
  uint8_t cdSetS;    // 設定秒 0–59
  // 鬧鐘（持久化到 NVS）
  bool almOn;
  uint8_t almH, almM;
  char almLabel[20];
  int almLastYday;    // 今日已響過就唔重複；-1 = 未響
  // 全屏提示（無喇叭：亮畫面 + 背光閃）
  uint8_t alert;      // AlertKind
  uint32_t alertSince;
};
static TimerRT gTmr = {};

// 改咗資料就 +1，UI 見到就重畫
static volatile uint32_t gDataVer = 0;
static inline void bumpVer() { gDataVer = gDataVer + 1; }
