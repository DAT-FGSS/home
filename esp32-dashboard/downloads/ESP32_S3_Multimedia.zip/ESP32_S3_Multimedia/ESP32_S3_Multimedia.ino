/**
 * ESP32-S3 多媒體（類似手機介面）
 * 硬體：Waveshare ESP32-S3-Touch-LCD-2.8 V1 / V2（ST7789 240x320 + CST328 或 CST3530 觸控，自動偵測）
 *       （板上嘅 microSD 同 PCM5101 喇叭本程式冇用）
 *
 * 主畫面三個 App：資訊儀表板、WiFi 設定、巴士站設定
 * 粉嶺官立中學製作（開機畫面同主畫面有校徽）
 *
 * 程式結構：
 *   loop()（core 1）  ：觸控 + 畫面（全部畫喺 PSRAM 畫布，畫完一次過送去 LCD，唔會閃）
 *   netTask（core 0） ：WiFi / NTP / 天文台 / 九巴（HTTPS 慢都唔會阻住觸控）
 *
 * 開發板設定（Arduino IDE → 工具）：
 *   開發板 ESP32S3 Dev Module；USB CDC On Boot: Enabled；Flash Size: 16MB；
 *   PSRAM: OPI PSRAM；Partition Scheme: 16M Flash (3MB APP/9.9MB FATFS)
 * 詳情睇 README.md
 */

// U8g2 要喺 Arduino_GFX 之前 include，Arduino_GFX 先會啟用 U8g2 字型（包括內附 CJK 字型）
#include <U8g2lib.h>
#include <Arduino_GFX_Library.h>
#include <esp_heap_caps.h>
#include <time.h>

#include "board_pins.h"
#include "config.h"
#include "theme.h"
#include "state.h"
#include "ui_core.h"
#include "ui_screens.h"
#include "touch_drv.h"
#include "net_task.h"
#include "ui_input.h"

static uint32_t uiMillis() { return millis(); }

// ---------- 顯示 ----------
// 畫布用 PSRAM（320x240x2 = 150KB），唔好霸住內部 RAM（WiFi / TLS 要用）
class PsramCanvas : public Arduino_Canvas {
 public:
  PsramCanvas(int16_t w, int16_t h, Arduino_G *out) : Arduino_Canvas(w, h, out) {}
  bool begin(int32_t speed = GFX_NOT_DEFINED) override {
    if (!_framebuffer) {
      _framebuffer = (uint16_t *)heap_caps_aligned_alloc(16, (size_t)WIDTH * HEIGHT * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    }
    return Arduino_Canvas::begin(speed);
  }
};
static Arduino_DataBus *lcdBus = new Arduino_ESP32SPI(LCD_DC, LCD_CS, LCD_SCK, LCD_MOSI, LCD_MISO);
static Arduino_GFX *lcd = new Arduino_ST7789(lcdBus, LCD_RST, SCREEN_ROTATION, true /* IPS */, 240, 320, 0, 0, 0, 0);

static void backlight(uint8_t duty) {
  ledcAttach(LCD_BL, 5000, 8);
  ledcWrite(LCD_BL, duty);
}
static void flushScreen() { gfx->flush(); }

static void splash(const char *msg, bool showTouch = false, int dotX = -1, int dotY = -1) {
  drawSplash(msg, showTouch, dotX, dotY);
  flushScreen();
}
// 開機觸控測試：顯示觸控狀態，期間撳畫面會畫出位置（唔使 Serial、唔使長按）
static void bootTouchTest() {
  uint32_t t0 = millis();
  uint32_t ms = gTouch.fail ? 4000 : BOOT_TOUCH_TEST_MS;
  uint8_t lastStat = gTouch.stat;
  int16_t lx = -1, ly = -1;
  splash("啟動中…", true);
  while (millis() - t0 < ms) {
    int16_t x, y;
    bool t = touchRead(&x, &y);  // 觸控用唔到時，入面會每 2 秒自動重試
    if ((t && (x != lx || y != ly)) || gTouch.stat != lastStat) {
      if (t && lx < 0) ms = max(ms, (uint32_t)(millis() - t0 + 1500));  // 第一次撳到：留多 1.5 秒睇結果
      if (t) {
        lx = x;
        ly = y;
      }
      lastStat = gTouch.stat;
      splash("啟動中…", true, lx, ly);
    }
    delay(10);
  }
}

// 電池供電時要鎖住電源（官方 Demo PWR_Key.cpp 做法）；USB 供電冇影響
static void powerLatch() {
  pinMode(PWR_KEY_PIN, INPUT);
  pinMode(PWR_CTRL_PIN, OUTPUT);
  digitalWrite(PWR_CTRL_PIN, LOW);
  delay(100);
  if (!digitalRead(PWR_KEY_PIN)) digitalWrite(PWR_CTRL_PIN, HIGH);
}

void setup() {
  Serial.begin(115200);
  powerLatch();
  gLock = xSemaphoreCreateMutex();
  setenv("TZ", TZ_INFO, 1);
  tzset();
  Serial.printf("ESP32-S3 Multimedia  PSRAM=%u bytes\n", (unsigned)ESP.getPsramSize());

  gfx = new PsramCanvas(320, 240, lcd);
  if (!gfx->begin(LCD_SPI_HZ)) Serial.println("[LCD] canvas begin failed (PSRAM 有冇開 OPI?)");
  gfx->setUTF8Print(true);
  gfx->setTextWrap(false);
  splash("啟動中…");
  backlight(BL_DUTY);

  if (!touchBegin()) Serial.println("[TP] 觸控初始化失敗（loop 入面會每 2 秒自動重試）");
  busCfgLoad();  // 巴士站設定（NVS；冇就用預設路線）
  alarmLoad();
  if (gTmr.cdSetM == 0 && gTmr.cdSetS == 0) gTmr.cdSetM = 5;
  gTmr.almLastYday = -1;
  xTaskCreatePinnedToCore(netTask, "net", 16384, nullptr, 1, nullptr, 0);
  bootTouchTest();
  openApp(APP_HOME);
}

void loop() {
  static uint32_t lastVer = 0, lastDraw = 0, lastFrame = 0;
  static int lastMin = -1;
  touchUpdate();
  timerTick();
  uint32_t now = millis();
  // 鬧鐘／倒數提示：背光閃爍（板上無喇叭）
  {
    static bool alertBl = false;
    if (ui.dlg == DLG_ALERT) {
      bool on = ((now / 250) & 1);
      if (on != alertBl) {
        alertBl = on;
        ledcWrite(LCD_BL, on ? 255 : 50);
      }
    } else if (alertBl) {
      alertBl = false;
      ledcWrite(LCD_BL, BL_DUTY);
    }
  }

  if (gDataVer != lastVer) {
    lastVer = gDataVer;
    gNeedDraw = true;
  }
  // WiFi 連線結果
  if (ui.dlg == DLG_CONNECTING) {
    STATE_LOCK();
    UserConn uc = gNet.userConn;
    if (uc == UC_OK || uc == UC_FAIL) {
      snprintf(ui.dlgMsg, sizeof(ui.dlgMsg), "%s", gNet.userMsg);
      gNet.userConn = UC_NONE;
    }
    STATE_UNLOCK();
    if (uc == UC_OK) ui.dlg = DLG_OK;
    if (uc == UC_FAIL) ui.dlg = DLG_FAIL;
    if (uc == UC_OK || uc == UC_FAIL) gNeedDraw = true;
  }
  busPoll();  // 巴士站設定：搜尋結果
  // 每分鐘重畫時鐘 / 巴士分鐘
  struct tm t;
  time_t tt = time(nullptr);
  localtime_r(&tt, &t);
  if (t.tm_min != lastMin) {
    lastMin = t.tm_min;
    gNeedDraw = true;
  }
  // 動畫（轉圈、游標）
  bool anim = ui.dlg == DLG_CONNECTING || ui.dlg == DLG_BUS_BUSY || ui.dlg == DLG_ALERT ||
              (ui.app == APP_BUS && ui.busView == BV_KB) ||
              (ui.app == APP_WIFI && (ui.wv == WV_KB || gNet.scanState == 1)) ||
              (ui.app == APP_TMR && (gTmr.swRun || gTmr.cdRun));
  if (anim && now - lastFrame > 120) {
    lastFrame = now;
    ui.frame++;
    gNeedDraw = true;
  }
  if (ui.toast[0] && (int32_t)(now - ui.toastUntil) > 0) {
    ui.toast[0] = 0;
    gNeedDraw = true;
  }
  if (gNeedDraw && now - lastDraw >= 25) {
    gNeedDraw = false;
    lastDraw = now;
    drawScreen();
    flushScreen();
  }
  delay(5);
}
