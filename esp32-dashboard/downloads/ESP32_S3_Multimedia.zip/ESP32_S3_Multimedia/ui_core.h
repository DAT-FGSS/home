#pragma once
// 繪圖基本工具：文字（CJK 字型後備）、漸層、粗線、天氣圖示、App 圖示
// 呢個檔只用 Arduino_GFX API，所以亦可以喺電腦上編譯嚟出預覽圖。
#include <math.h>
#include <string.h>

static Arduino_Canvas *gfx = nullptr;  // 320x240 畫布（PSRAM），畫完一次過送去 LCD

// ===================== U8g2 字型查字 / 量闊度 =====================
static inline uint16_t u8Word(const uint8_t *p, uint16_t off) {
  return ((uint16_t)p[off] << 8) | p[off + 1];
}
struct U8Bits {
  const uint8_t *p;
  uint8_t bit;
};
static uint8_t u8Get(U8Bits &b, uint8_t cnt) {
  uint8_t val = *b.p;
  uint8_t bp = b.bit;
  val >>= bp;
  uint8_t bpc = bp + cnt;
  if (bpc >= 8) {
    uint8_t s = 8 - bp;
    b.p++;
    val |= (uint8_t)(*b.p << s);
    bpc -= 8;
  }
  val &= (uint8_t)((1U << cnt) - 1);
  b.bit = bpc;
  return val;
}
static int8_t u8GetS(U8Bits &b, uint8_t cnt) {
  int8_t v = (int8_t)u8Get(b, cnt);
  int8_t d = (int8_t)(1 << (cnt - 1));
  return v - d;
}
// 搵字型入面某個字（code point）嘅 glyph；冇就回傳 nullptr
static const uint8_t *u8FindGlyph(const uint8_t *font, uint32_t enc) {
  if (enc > 0xFFFE) return nullptr;
  const uint8_t *f = font + 23;
  if (enc <= 255) {
    if (enc >= 'a') f += u8Word(font, 19);
    else if (enc >= 'A') f += u8Word(font, 17);
    for (;;) {
      if (f[1] == 0) break;
      if (f[0] == enc) return f + 2;
      f += f[1];
    }
    return nullptr;
  }
  uint16_t uoff = u8Word(font, 21);
  if (uoff == 0) return nullptr;
  f += uoff;
  const uint8_t *lut = f;
  uint16_t e;
  do {
    f += u8Word(lut, 0);
    e = u8Word(lut, 2);
    lut += 4;
  } while (e < enc);
  for (;;) {
    e = u8Word(f, 0);
    if (e == 0) break;
    if (e == enc) return f + 3;
    f += f[2];
  }
  return nullptr;
}
// 字嘅前進闊度（px）；字型冇呢個字回傳 -1
static int u8Advance(const uint8_t *font, uint32_t cp) {
  const uint8_t *g = u8FindGlyph(font, cp);
  if (!g) return -1;
  U8Bits b{g, 0};
  u8Get(b, font[4]);
  u8Get(b, font[5]);
  u8GetS(b, font[6]);
  u8GetS(b, font[7]);
  return u8GetS(b, font[8]);
}
// 讀一個 UTF-8 字；回傳佔幾多 byte
static int utf8Next(const char *s, uint32_t *cp) {
  const uint8_t *p = (const uint8_t *)s;
  if (p[0] < 0x80) { *cp = p[0]; return 1; }
  if ((p[0] & 0xE0) == 0xC0 && p[1]) { *cp = ((p[0] & 0x1F) << 6) | (p[1] & 0x3F); return 2; }
  if ((p[0] & 0xF0) == 0xE0 && p[1] && p[2]) {
    *cp = ((p[0] & 0x0F) << 12) | ((p[1] & 0x3F) << 6) | (p[2] & 0x3F);
    return 3;
  }
  if ((p[0] & 0xF8) == 0xF0 && p[1] && p[2] && p[3]) {
    *cp = ((uint32_t)(p[0] & 0x07) << 18) | ((p[1] & 0x3F) << 12) | ((p[2] & 0x3F) << 6) | (p[3] & 0x3F);
    return 4;
  }
  *cp = '?';
  return 1;
}

// ===================== 文字 =====================
// 主字型冇嗰個字 → 用後備字型（俐方體11號）→ 都冇就畫個細方格
#define BOX_W 9
static int glyphPick(const uint8_t *font, const uint8_t *fb, uint32_t cp, const uint8_t **use) {
  int a = u8Advance(font, cp);
  if (a >= 0) { *use = font; return a; }
  if (fb) {
    a = u8Advance(fb, cp);
    if (a >= 0) { *use = fb; return a; }
  }
  *use = nullptr;
  return BOX_W;
}
static int textW(const char *s, const uint8_t *font, const uint8_t *fb = F_ZH12) {
  int w = 0;
  while (*s) {
    uint32_t cp;
    int n = utf8Next(s, &cp);
    const uint8_t *u;
    w += glyphPick(font, fb, cp, &u);
    s += n;
  }
  return w;
}
static void drawOneGlyph(int x, int y, const char *bytes, int n, const uint8_t *use, uint16_t color) {
  if (!use) {  // 冇字：畫方格
    gfx->drawRect(x + 1, y - 10, BOX_W - 2, 11, color);
    return;
  }
  char buf[5];
  memcpy(buf, bytes, n);
  buf[n] = 0;
  gfx->setFont(use);
  gfx->setTextColor(color);
  gfx->setCursor(x, y);
  gfx->print(buf);
}
// 喺 (x, 基線 y) 畫字；maxW > 0 時太長會用「…」截短。回傳畫咗幾闊
static int drawText(int x, int y, const char *s, const uint8_t *font, uint16_t color,
                    int maxW = 0, const uint8_t *fb = F_ZH12) {
  if (!s) return 0;
  int total = textW(s, font, fb);
  bool cut = (maxW > 0 && total > maxW);
  int ellW = cut ? u8Advance(F_ZH12, 0x2026) : 0;
  int limit = cut ? maxW - ellW : 0x7FFF;
  int cx = x;
  while (*s) {
    uint32_t cp;
    int n = utf8Next(s, &cp);
    const uint8_t *u;
    int a = glyphPick(font, fb, cp, &u);
    if (cx + a - x > limit) break;
    if (cp != ' ') drawOneGlyph(cx, y, s, n, u, color);
    cx += a;
    s += n;
  }
  if (cut) {
    drawOneGlyph(cx, y, "\xE2\x80\xA6", 3, F_ZH12, color);
    cx += ellW;
  }
  return cx - x;
}
static int drawTextC(int cx, int y, const char *s, const uint8_t *font, uint16_t color, int maxW = 0) {
  int w = textW(s, font);
  if (maxW > 0 && w > maxW) w = maxW;
  return drawText(cx - w / 2, y, s, font, color, maxW);
}
static int drawTextR(int rx, int y, const char *s, const uint8_t *font, uint16_t color) {
  int w = textW(s, font);
  return drawText(rx - w, y, s, font, color);
}

// ===================== 顏色 / 形狀 =====================
static uint16_t lerp565(uint16_t a, uint16_t b, int t) {  // t: 0..255
  int ar = (a >> 11) & 31, ag = (a >> 5) & 63, ab = a & 31;
  int br = (b >> 11) & 31, bg = (b >> 5) & 63, bb = b & 31;
  int r = ar + ((br - ar) * t) / 255;
  int g = ag + ((bg - ag) * t) / 255;
  int bl = ab + ((bb - ab) * t) / 255;
  return (uint16_t)((r << 11) | (g << 5) | bl);
}
static void fillGradV(int x, int y, int w, int h, uint16_t c1, uint16_t c2) {
  for (int j = 0; j < h; j++) gfx->drawFastHLine(x, y + j, w, lerp565(c1, c2, h > 1 ? j * 255 / (h - 1) : 0));
}
// 圓角長方形 + 由上至下漸層
static void fillRRGrad(int x, int y, int w, int h, int r, uint16_t c1, uint16_t c2) {
  for (int j = 0; j < h; j++) {
    float dy = -1;
    if (j < r) dy = r - j - 0.5f;
    else if (j >= h - r) dy = j - (h - r) + 0.5f;
    int inset = 0;
    if (dy >= 0) inset = (int)(r - sqrtf((float)r * r - dy * dy) + 0.5f);
    gfx->drawFastHLine(x + inset, y + j, w - 2 * inset, lerp565(c1, c2, h > 1 ? j * 255 / (h - 1) : 0));
  }
}
static void card(int x, int y, int w, int h, int r = 10, uint16_t c = COL_CARD) {
  gfx->fillRoundRect(x, y, w, h, r, c);
}
// 粗線（兩個三角形 + 圓頭）
static void thickLine(float x0, float y0, float x1, float y1, float t, uint16_t c) {
  float dx = x1 - x0, dy = y1 - y0;
  float len = sqrtf(dx * dx + dy * dy);
  if (len < 0.01f) { gfx->fillCircle((int)x0, (int)y0, (int)(t / 2), c); return; }
  float nx = -dy / len * t / 2, ny = dx / len * t / 2;
  gfx->fillTriangle((int)(x0 + nx), (int)(y0 + ny), (int)(x0 - nx), (int)(y0 - ny), (int)(x1 + nx), (int)(y1 + ny), c);
  gfx->fillTriangle((int)(x0 - nx), (int)(y0 - ny), (int)(x1 - nx), (int)(y1 - ny), (int)(x1 + nx), (int)(y1 + ny), c);
  if (t >= 3) {
    gfx->fillCircle((int)x0, (int)y0, (int)(t / 2), c);
    gfx->fillCircle((int)x1, (int)y1, (int)(t / 2), c);
  }
}
// 將整塊畫布變暗（彈出視窗後面用）
static void dimCanvas() {
  uint16_t *fb = gfx->getFramebuffer();
  if (!fb) return;
  for (int i = 0; i < 320 * 240; i++) fb[i] = (fb[i] >> 1) & 0x7BEF;
}

// ===================== 細圖示 =====================
static int rssiBars(int rssi) {
  if (rssi >= -55) return 4;
  if (rssi >= -67) return 3;
  if (rssi >= -75) return 2;
  if (rssi >= -85) return 1;
  return 0;
}
// WiFi 扇形圖示：(cx, cy) 係底部圓心
static void iconWifi(int cx, int cy, int r, int level, bool on) {
  uint16_t onC = COL_TEXT, offC = 0x4208;
  int t = r / 4;
  if (t < 2) t = 2;
  for (int i = 0; i < 3; i++) {
    int ro = r - i * (t + 2);
    bool lit = on && level >= 4 - i;
    gfx->fillArc(cx, cy, ro, ro - t, 225, 315, lit ? onC : offC);
  }
  gfx->fillCircle(cx, cy - 1, t > 2 ? t / 2 + 1 : 2, (on && level >= 1) ? onC : offC);
  if (!on) {  // 未連線：細交叉
    thickLine(cx + r * 0.55f, cy - 4, cx + r * 0.95f, cy, 2, COL_DANGER);
    thickLine(cx + r * 0.95f, cy - 4, cx + r * 0.55f, cy, 2, COL_DANGER);
  }
}
// 幼身幾何箭嘴（同日曆右上角換月箭嘴一樣：stroke=2，唔用 Unicode）
static void iconChevronLeft(int x, int y, uint16_t c) {
  thickLine(x + 6, y, x, y + 6, 2, c);
  thickLine(x, y + 6, x + 6, y + 12, 2, c);
}
static void iconChevronRight(int x, int y, uint16_t c) {
  thickLine(x, y, x + 6, y + 6, 2, c);
  thickLine(x + 6, y + 6, x, y + 12, 2, c);
}
static void iconBack(int x, int y, uint16_t c) {  // 返回＝幼身 ‹
  iconChevronLeft(x, y, c);
}
static void iconLock(int x, int y, uint16_t c) {  // 左上角 (x,y)，約 9x11
  gfx->drawRoundRect(x + 2, y, 6, 8, 3, c);
  gfx->drawRoundRect(x + 3, y + 1, 4, 7, 2, c);
  gfx->fillRoundRect(x, y + 5, 10, 7, 2, c);
}
static void iconRefresh(int cx, int cy, int r, uint16_t c) {  // 循環箭咀
  gfx->fillArc(cx, cy, r, r - 2, 0, 290, c);
  float a = 290.0f * 0.0174533f;
  float px = cx + cosf(a) * (r - 1), py = cy + sinf(a) * (r - 1);
  float tx = -sinf(a), ty = cosf(a);  // 切線方向（順時針）
  float nx = cosf(a), ny = sinf(a);   // 半徑方向
  gfx->fillTriangle((int)(px + tx * 5), (int)(py + ty * 5), (int)(px + nx * 4 - tx), (int)(py + ny * 4 - ty),
                    (int)(px - nx * 4 - tx), (int)(py - ny * 4 - ty), c);
}
static void iconPlus(int cx, int cy, int r, uint16_t c) {
  thickLine(cx - r, cy, cx + r, cy, 3, c);
  thickLine(cx, cy - r, cx, cy + r, 3, c);
}
[[maybe_unused]] static void iconHome(int cx, int cy, uint16_t c) {
  gfx->fillTriangle(cx - 8, cy - 1, cx + 8, cy - 1, cx, cy - 9, c);
  gfx->fillRect(cx - 6, cy - 1, 12, 8, c);
}
static void iconEye(int cx, int cy, bool open, uint16_t c) {
  gfx->drawEllipse(cx, cy, 9, 5, c);
  gfx->drawEllipse(cx, cy, 8, 4, c);
  gfx->fillCircle(cx, cy, 2, c);
  if (!open) thickLine(cx - 9, cy + 6, cx + 9, cy - 6, 2, c);
}
static void iconDrop(int cx, int cy, int r, uint16_t c) {
  gfx->fillCircle(cx, cy + r / 3, r, c);
  gfx->fillTriangle(cx, cy - r - r / 2 - 1, cx - r + 1, cy + r / 4, cx + r - 1, cy + r / 4, c);
}
static void spinner(int cx, int cy, int r, uint32_t frame, uint16_t c) {
  float a0 = (frame % 12) * 30.0f;
  gfx->fillArc(cx, cy, r, r - 4, 0, 360, 0x3186);
  gfx->fillArc(cx, cy, r, r - 4, a0, a0 + 100, c);
}

// ===================== 天氣圖示（彩色扁平風格）=====================
// 天文台圖示編號：50 晴；51–54 間晴（54 有驟雨）；60 多雲；61 密雲；62–64 雨；65 雷暴；
// 70–75 天晴（夜間月相）；76 大致多雲（夜）；77 大致天晴（夜）；80 大風；81 乾燥；82 潮濕；
// 83 霧；84 薄霧；85 煙霞；90 熱；91 暖；92 涼；93 冷
static void wxCloud(float cx, float cy, float w, uint16_t c, int grow = 0) {
  gfx->fillCircle((int)(cx - 0.22f * w), (int)(cy + 0.04f * w), (int)(0.20f * w) + grow, c);
  gfx->fillCircle((int)(cx + 0.04f * w), (int)(cy - 0.08f * w), (int)(0.27f * w) + grow, c);
  gfx->fillCircle((int)(cx + 0.27f * w), (int)(cy + 0.08f * w), (int)(0.17f * w) + grow, c);
  gfx->fillRoundRect((int)(cx - 0.42f * w) - grow, (int)(cy + 0.04f * w) - grow, (int)(0.84f * w) + 2 * grow,
                     (int)(0.22f * w) + 2 * grow, (int)(0.11f * w) + grow, c);
}
static void wxCloudO(float cx, float cy, float w, uint16_t c, uint16_t bg) {
  wxCloud(cx, cy, w, bg, 2);
  wxCloud(cx, cy, w, c, 0);
}
static void wxSun(float cx, float cy, float r, uint16_t c = COL_SUN) {
  float t = r / 4.0f;
  if (t < 1.5f) t = 1.5f;
  for (int a = 0; a < 8; a++) {
    float rad = a * 0.785398f;
    thickLine(cx + cosf(rad) * r * 1.4f, cy + sinf(rad) * r * 1.4f, cx + cosf(rad) * r * 1.85f,
              cy + sinf(rad) * r * 1.85f, t, c);
  }
  gfx->fillCircle((int)cx, (int)cy, (int)r, c);
}
static void wxMoon(float cx, float cy, float r, uint16_t bg) {
  gfx->fillCircle((int)cx, (int)cy, (int)r, COL_MOON);
  gfx->fillCircle((int)(cx + r * 0.5f), (int)(cy - r * 0.35f), (int)(r * 0.82f), bg);
}
static void wxRain(float cx, float cy, float w, int n, uint16_t c = COL_RAIN) {
  float sp = 0.2f * w;
  float x0 = cx - sp * (n - 1) / 2.0f;
  float t = w / 16.0f;
  if (t < 2) t = 2;
  for (int i = 0; i < n; i++) {
    float x = x0 + i * sp;
    float yo = (i % 2) ? 0.06f * w : 0;
    thickLine(x + 0.04f * w, cy + yo, x - 0.04f * w, cy + yo + 0.16f * w, t, c);
  }
}
static void wxBolt(float cx, float cy, float s) {
  float Ax = cx + 0.06f * s, Ay = cy - 0.20f * s, Bx = cx - 0.08f * s, By = cy + 0.03f * s;
  float Cx = cx + 0.0f * s, Cy = cy + 0.03f * s, Dx = cx - 0.04f * s, Dy = cy + 0.24f * s;
  float Ex = cx + 0.11f * s, Ey = cy - 0.04f * s, Fx = cx + 0.03f * s, Fy = cy - 0.04f * s;
  gfx->fillTriangle(Ax, Ay, Bx, By, Cx, Cy, COL_BOLT);
  gfx->fillTriangle(Ax, Ay, Cx, Cy, Fx, Fy, COL_BOLT);
  gfx->fillTriangle(Fx, Fy, Ex, Ey, Dx, Dy, COL_BOLT);
  gfx->fillTriangle(Fx, Fy, Cx, Cy, Dx, Dy, COL_BOLT);
}
static void wxFog(float cx, float cy, float w, uint16_t c = COL_CLOUD) {
  float t = w / 12.0f;
  if (t < 2) t = 2;
  thickLine(cx - 0.36f * w, cy - 0.16f * w, cx + 0.30f * w, cy - 0.16f * w, t, c);
  thickLine(cx - 0.26f * w, cy, cx + 0.38f * w, cy, t, c);
  thickLine(cx - 0.38f * w, cy + 0.16f * w, cx + 0.20f * w, cy + 0.16f * w, t, c);
}
static void wxWind(float cx, float cy, float w) {
  float t = w / 14.0f;
  if (t < 2) t = 2;
  thickLine(cx - 0.40f * w, cy - 0.14f * w, cx + 0.22f * w, cy - 0.14f * w, t, COL_CLOUD);
  gfx->fillArc((int)(cx + 0.22f * w), (int)(cy - 0.22f * w), (int)(0.08f * w + t / 2), (int)(0.08f * w - t / 2), 270, 450, COL_CLOUD);
  thickLine(cx - 0.32f * w, cy + 0.02f * w, cx + 0.36f * w, cy + 0.02f * w, t, COL_CLOUD);
  thickLine(cx - 0.40f * w, cy + 0.18f * w, cx + 0.12f * w, cy + 0.18f * w, t, COL_CLOUD);
  gfx->fillArc((int)(cx + 0.12f * w), (int)(cy + 0.26f * w), (int)(0.08f * w + t / 2), (int)(0.08f * w - t / 2), -90, 90, COL_CLOUD);
}
static void wxThermo(float cx, float cy, float s, uint16_t c) {
  int w = (int)(s * 0.14f) + 2;
  gfx->fillRoundRect((int)(cx - w / 2), (int)(cy - 0.32f * s), w, (int)(0.5f * s), w / 2, COL_TEXT);
  gfx->fillCircle((int)cx, (int)(cy + 0.22f * s), (int)(0.13f * s) + 2, COL_TEXT);
  gfx->fillCircle((int)cx, (int)(cy + 0.22f * s), (int)(0.13f * s), c);
  gfx->fillRect((int)(cx - w / 2 + 2), (int)(cy - 0.05f * s), w - 4, (int)(0.25f * s), c);
}
static void wxSnow(float cx, float cy, float s) {
  float r = 0.3f * s, t = s / 14.0f;
  if (t < 2) t = 2;
  for (int i = 0; i < 3; i++) {
    float a = i * 1.0472f + 1.5708f;
    thickLine(cx - cosf(a) * r, cy - sinf(a) * r, cx + cosf(a) * r, cy + sinf(a) * r, t, RGB565(160, 210, 255));
  }
}
// (cx, cy) 中心；s ≈ 圖示闊度；bg = 圖示後面嘅底色（月牙 / 雲邊用）
static void drawWx(int cx, int cy, int s, int code, uint16_t bg) {
  float w = s;
  switch (code) {
    case 50: case 81: case 91: wxSun(cx, cy, 0.2f * w); break;
    case 90: wxSun(cx, cy, 0.22f * w, RGB565(255, 120, 40)); break;
    case 51: case 52: case 53: case 54:
      wxSun(cx - 0.14f * w, cy - 0.14f * w, 0.15f * w);
      wxCloudO(cx + 0.06f * w, cy + (code >= 53 ? 0.0f : 0.08f) * w, (code == 51 ? 0.62f : 0.74f) * w, COL_CLOUD, bg);
      if (code >= 53) wxRain(cx + 0.06f * w, cy + 0.24f * w, w, code == 54 ? 3 : 2);
      break;
    case 60:
      wxCloud(cx + 0.14f * w, cy - 0.10f * w, 0.62f * w, COL_CLOUD_D);
      wxCloudO(cx - 0.06f * w, cy + 0.06f * w, 0.78f * w, COL_CLOUD, bg);
      break;
    case 61: wxCloudO(cx, cy, 0.9f * w, COL_CLOUD_D, bg); break;
    case 62: case 63: case 64:
      wxCloudO(cx, cy - 0.12f * w, 0.84f * w, code == 64 ? COL_CLOUD_D : COL_CLOUD, bg);
      wxRain(cx, cy + 0.18f * w, w, code - 60);
      break;
    case 65:
      wxCloudO(cx, cy - 0.14f * w, 0.84f * w, COL_CLOUD_D, bg);
      wxBolt(cx, cy + 0.16f * w, 0.9f * w);
      wxRain(cx - 0.24f * w, cy + 0.16f * w, w * 0.8f, 1);
      wxRain(cx + 0.26f * w, cy + 0.16f * w, w * 0.8f, 1);
      break;
    case 70: case 71: case 72: case 73: case 74: case 75: wxMoon(cx, cy, 0.3f * w, bg); break;
    case 76:
      wxMoon(cx - 0.14f * w, cy - 0.12f * w, 0.2f * w, bg);
      wxCloudO(cx + 0.06f * w, cy + 0.08f * w, 0.78f * w, COL_CLOUD, bg);
      break;
    case 77:
      wxMoon(cx - 0.08f * w, cy - 0.06f * w, 0.26f * w, bg);
      wxCloudO(cx + 0.16f * w, cy + 0.16f * w, 0.5f * w, COL_CLOUD, bg);
      break;
    case 80: wxWind(cx, cy, w); break;
    case 82: iconDrop(cx, cy + 0.04f * w, (int)(0.2f * w), COL_RAIN); break;
    case 83: case 84: wxFog(cx, cy, w); break;
    case 85: wxSun(cx, cy - 0.12f * w, 0.14f * w, RGB565(230, 170, 90)); wxFog(cx, cy + 0.12f * w, w * 0.9f); break;
    case 92: wxThermo(cx, cy, w, RGB565(90, 200, 250)); break;
    case 93: wxSnow(cx, cy, w); break;
    default: wxCloudO(cx, cy, 0.84f * w, COL_CLOUD, bg); break;
  }
}

// ===================== 主畫面 App 圖示（純程式繪製）=====================
// 圖示按 72px 設計（主畫面三個圖示就用 72px）；sz 可以改細，k = 縮放比例
#define APP_ICON_SZ 72
static void appIconBase(int x, int y, int sz, uint16_t c1, uint16_t c2, bool pressed) {
  int r = sz / 4;
  if (pressed) { x += 3; y += 3; sz -= 6; }
  gfx->fillRoundRect(x + 2, y + 4, sz, sz, r, 0x0841);  // 影
  fillRRGrad(x, y, sz, sz, r, c1, c2);
  // 頂部光澤
  for (int j = 2; j < sz / 3; j++) {
    int inset = (j < r) ? (int)(r - sqrtf((float)r * r - (r - j) * (r - j))) + 3 : 3;
    uint16_t c = lerp565(c1, 0xFFFF, 40 - j * 100 / sz);
    gfx->drawFastHLine(x + inset, y + j, sz - 2 * inset, c);
  }
}
static void appIconDashboard(int x, int y, bool pressed, int sz = APP_ICON_SZ) {
  float k = sz / 72.0f;
  appIconBase(x, y, sz, RGB565(64, 156, 255), RGB565(88, 86, 214), pressed);
  int cx = x + sz / 2, cy = y + sz / 2;
  wxSun(cx - 9 * k, cy - 13 * k, 6 * k);
  wxCloud(cx + 3 * k, cy - 4 * k, 34 * k, 0xFFFF);
  gfx->fillRoundRect(cx - 20 * k, cy + 13 * k, 40 * k, 5 * k, 2, 0xFFFF);
  gfx->fillRoundRect(cx - 20 * k, cy + 21 * k, 26 * k, 5 * k, 2, lerp565(0xFFFF, RGB565(88, 86, 214), 90));
}
static void appIconWifi(int x, int y, bool pressed, int sz = APP_ICON_SZ) {
  float k = sz / 72.0f;
  appIconBase(x, y, sz, RGB565(48, 209, 88), RGB565(0, 160, 170), pressed);
  int cx = x + sz / 2, cy = y + sz / 2 + 14 * k;
  for (int i = 0; i < 3; i++) {
    int ro = (30 - i * 10) * k;
    gfx->fillArc(cx, cy, ro, ro - 6 * k, 225, 315, 0xFFFF);
  }
  gfx->fillCircle(cx, cy - 2 * k, 4 * k, 0xFFFF);
}
// 巴士（正面）＋ 站牌
static void appIconBus(int x, int y, bool pressed, int sz = APP_ICON_SZ) {
  float k = sz / 72.0f;
  uint16_t c1 = RGB565(255, 92, 72), c2 = RGB565(196, 22, 52);
  appIconBase(x, y, sz, c1, c2, pressed);
  int cx = x + sz / 2 - 5 * k, cy = y + sz / 2 + 1 * k;
  uint16_t mid = lerp565(c1, c2, 128);
  int bw = 34 * k, bh = 38 * k, bx = cx - bw / 2, by = cy - bh / 2;
  gfx->fillRoundRect(bx + 3 * k, by + bh - 4 * k, 7 * k, 9 * k, 2, 0x3186);       // 車轆
  gfx->fillRoundRect(bx + bw - 10 * k, by + bh - 4 * k, 7 * k, 9 * k, 2, 0x3186);
  gfx->fillRoundRect(bx, by, bw, bh, 7 * k, 0xFFFF);                              // 車身
  gfx->fillRoundRect(bx + 6 * k, by + 3 * k, bw - 12 * k, 5 * k, 2, mid);         // 路線牌
  gfx->fillRoundRect(bx + 4 * k, by + 11 * k, bw - 8 * k, 14 * k, 3, RGB565(40, 60, 90));  // 擋風玻璃
  gfx->fillCircle(bx + 7 * k, by + bh - 8 * k, 3 * k, COL_SUN);                   // 車頭燈
  gfx->fillCircle(bx + bw - 7 * k, by + bh - 8 * k, 3 * k, COL_SUN);
  gfx->fillRoundRect(cx - 5 * k, by + bh - 9 * k, 10 * k, 3 * k, 1, 0xBDF7);
  // 右邊細站牌
  int px = x + sz - 15 * k, py = y + 14 * k;
  gfx->fillRect(px - 1 * k, py + 8 * k, 3 * k, 36 * k, 0xFFFF);
  gfx->fillRoundRect(px - 6 * k, py, 13 * k, 13 * k, 3 * k, 0xFFFF);
  gfx->fillRoundRect(px - 4 * k, py + 2 * k, 9 * k, 9 * k, 2, c2);
}


// ===================== 天文台警告信號圖示（官方 bitmap 24px + 幾何後備）=====================
#include "warn_icons.h"

// 畫官方 24×24 圖符（可縮放至 s；cx,cy 係中心）
static bool drawWarnBitmap(int cx, int cy, int s, const char *code) {
  const WarnIconImg *img = warnIconFind(code);
  if (!img) return false;
  uint16_t *fb = gfx->getFramebuffer();
  if (!fb) return false;
  int W = gfx->width(), H = gfx->height();
  const int src = WARN_ICON_SIZE;
  int dst = s > 0 ? s : src;
  int x0 = cx - dst / 2, y0 = cy - dst / 2;
  for (int j = 0; j < dst; j++) {
    int y = y0 + j;
    if (y < 0 || y >= H) continue;
    int sy = (j * src) / dst;
    for (int i = 0; i < dst; i++) {
      int x = x0 + i;
      if (x < 0 || x >= W) continue;
      int sx = (i * src) / dst;
      int idx = sy * src + sx;
      uint8_t a = pgm_read_byte(&img->a[idx]);
      if (a == 0) continue;
      uint16_t c = pgm_read_word(&img->rgb[idx]);
      uint16_t &d = fb[y * W + x];
      d = (a >= 250) ? c : lerp565(d, c, a);
    }
  }
  return true;
}

// code 例子：TC1/TC3/TC8NE/TC9/TC10、WRAINA/WRAINR/WRAINB、WTS、WHOT、WCOLD、WMSGNL、WFIREY/WFIRER、WL、WFNTSA、WTMW…
static void drawWarnIcon(int cx, int cy, int s, const char *code) {
  if (!code || !code[0]) return;
  if (drawWarnBitmap(cx, cy, s, code)) return;
  // 未知代碼 → 簡單幾何後備（唔好用 strstr("R") 判斷火災，會誤中 WFIREY）
  float k = s / 28.0f;
  auto eq = [&](const char *a) { return strcmp(code, a) == 0; };
  auto starts = [&](const char *a) { return strncmp(code, a, strlen(a)) == 0; };
  if (starts("TC")) {
    uint16_t bg = COL_WARN;
    const char *num = "1";
    if (starts("TC10")) { bg = RGB565(180, 0, 0); num = "10"; }
    else if (starts("TC9")) { bg = RGB565(180, 0, 0); num = "9"; }
    else if (starts("TC8")) { bg = RGB565(200, 40, 40); num = "8"; }
    else if (starts("TC3")) { bg = COL_WARN; num = "3"; }
    else { bg = RGB565(80, 160, 255); num = "1"; }
    gfx->fillCircle(cx, cy, (int)(12 * k), bg);
    gfx->drawCircle(cx, cy, (int)(12 * k), 0xFFFF);
    drawTextC(cx, cy + (int)(5 * k), num, F_MED, 0xFFFF);
    return;
  }
  if (starts("WRAIN")) {
    uint16_t bg = COL_WARN;
    if (eq("WRAINB")) bg = RGB565(40, 40, 40);
    else if (eq("WRAINR")) bg = RGB565(200, 40, 40);
    gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), bg);
    uint16_t rc = (bg == COL_WARN) ? 0x0000 : 0xFFFF;
    for (int i = 0; i < 3; i++)
      gfx->fillTriangle(cx - (int)(6 * k) + i * (int)(6 * k), cy - (int)(2 * k),
                        cx - (int)(8 * k) + i * (int)(6 * k), cy + (int)(8 * k),
                        cx - (int)(4 * k) + i * (int)(6 * k), cy + (int)(8 * k), rc);
    return;
  }
  if (eq("WTS") || starts("WTS")) {
    gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), COL_WARN);
    gfx->fillTriangle(cx + (int)(2 * k), cy - (int)(10 * k), cx - (int)(6 * k), cy + (int)(2 * k), cx + (int)(1 * k), cy + (int)(2 * k), 0x0000);
    gfx->fillTriangle(cx - (int)(1 * k), cy + (int)(0 * k), cx + (int)(6 * k), cy + (int)(10 * k), cx - (int)(2 * k), cy + (int)(0 * k), 0x0000);
    return;
  }
  if (eq("WHOT") || starts("WHOT")) {
    gfx->fillCircle(cx, cy, (int)(12 * k), RGB565(255, 100, 40));
    wxSun(cx, cy, 7 * k, COL_SUN);
    return;
  }
  if (eq("WCOLD") || starts("WCOLD")) {
    gfx->fillCircle(cx, cy, (int)(12 * k), RGB565(80, 160, 255));
    gfx->drawFastHLine(cx - (int)(8 * k), cy, (int)(16 * k), 0xFFFF);
    gfx->drawFastVLine(cx, cy - (int)(8 * k), (int)(16 * k), 0xFFFF);
    return;
  }
  if (eq("WMSGNL") || starts("WMSGNL")) {
    gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), RGB565(80, 160, 255));
    for (int i = 0; i < 3; i++)
      thickLine(cx - 8 * k, cy - 6 * k + i * 6 * k, cx + 8 * k, cy - 10 * k + i * 6 * k, 2, 0xFFFF);
    return;
  }
  if (eq("WL") || starts("WL")) {
    gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), RGB565(140, 90, 40));
    gfx->fillTriangle(cx - (int)(10 * k), cy + (int)(8 * k), cx + (int)(2 * k), cy - (int)(8 * k), cx + (int)(10 * k), cy + (int)(8 * k), RGB565(180, 120, 60));
    return;
  }
  // 火災：必須用精確代碼／結尾，唔可以用 strstr(..., "R")（會誤中 WFIREY）
  if (starts("WFIRE")) {
    bool red = eq("WFIRER") || (code[5] == 'R' && code[6] == '\0');
    uint16_t bg = red ? RGB565(200, 40, 40) : COL_WARN;
    gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), bg);
    gfx->fillTriangle(cx, cy - (int)(8 * k), cx - (int)(7 * k), cy + (int)(8 * k), cx + (int)(7 * k), cy + (int)(8 * k), 0xFFFF);
    return;
  }
  gfx->fillRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), COL_CARD_HI);
  gfx->drawRoundRect(cx - (int)(12 * k), cy - (int)(12 * k), (int)(24 * k), (int)(24 * k), (int)(4 * k), COL_WARN);
  char ab[3];
  ab[0] = code[0] ? (char)code[0] : '?';
  ab[1] = code[1] ? (char)code[1] : 0;
  ab[2] = 0;
  drawTextC(cx, cy + (int)(5 * k), ab, F_TINY, COL_WARN);
}

static void appIconCalendar(int x, int y, bool pressed, int sz = APP_ICON_SZ) {
  float k = sz / 72.0f;
  appIconBase(x, y, sz, RGB565(255, 120, 80), RGB565(180, 40, 40), pressed);
  int cx = x + sz / 2, cy = y + sz / 2;
  // 日曆本
  gfx->fillRoundRect(cx - 20 * k, cy - 16 * k, 40 * k, 36 * k, 4 * k, 0xFFFF);
  gfx->fillRect(cx - 20 * k, cy - 16 * k, 40 * k, 10 * k, RGB565(200, 40, 40));
  gfx->fillCircle(cx - 10 * k, cy - 16 * k, 3 * k, COL_MUTED);
  gfx->fillCircle(cx + 10 * k, cy - 16 * k, 3 * k, COL_MUTED);
  // 格子點
  for (int r = 0; r < 2; r++)
    for (int c = 0; c < 3; c++)
      gfx->fillRect(cx - 12 * k + c * 10 * k, cy + 2 * k + r * 10 * k, 6 * k, 6 * k, RGB565(200, 80, 60));
}

static void appIconTimer(int x, int y, bool pressed, int sz = APP_ICON_SZ) {
  float k = sz / 72.0f;
  appIconBase(x, y, sz, RGB565(255, 180, 40), RGB565(220, 100, 20), pressed);
  int cx = x + sz / 2, cy = y + sz / 2 + 2 * k;
  gfx->fillCircle(cx, cy, 20 * k, 0xFFFF);
  gfx->fillCircle(cx, cy, 16 * k, RGB565(40, 40, 50));
  // 指針
  thickLine(cx, cy, cx + 8 * k, cy - 8 * k, 2.5f * k, COL_WARN);
  thickLine(cx, cy, cx, cy - 12 * k, 2 * k, 0xFFFF);
  gfx->fillCircle(cx, cy, 3 * k, COL_WARN);
  // 頂鈕
  gfx->fillRoundRect(cx - 4 * k, cy - 26 * k, 8 * k, 6 * k, 2, 0xFFFF);
}

// ===================== 校徽（RGB565 + alpha，同底色混合）=====================
#include "crest.h"

static void drawCrest(int x0, int y0, const CrestImg &img) {
  uint16_t *fb = gfx->getFramebuffer();
  if (!fb) return;
  int W = gfx->width(), H = gfx->height();
  for (int j = 0; j < img.h; j++) {
    int y = y0 + j;
    if (y < 0 || y >= H) continue;
    for (int i = 0; i < img.w; i++) {
      int x = x0 + i;
      if (x < 0 || x >= W) continue;
      int idx = j * img.w + i;
      uint8_t a = pgm_read_byte(&img.a[idx]);
      if (a == 0) continue;
      uint16_t c = pgm_read_word(&img.rgb[idx]);
      uint16_t &d = fb[y * W + x];
      d = (a >= 250) ? c : lerp565(d, c, a);
    }
  }
}

