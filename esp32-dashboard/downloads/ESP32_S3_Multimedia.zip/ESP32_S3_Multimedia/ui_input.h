#pragma once
// 觸控手勢 + 各 App 嘅撳掣邏輯

static bool gNeedDraw = true;
static inline bool inRect(int x, int y, int rx, int ry, int rw, int rh) {
  return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
}
static inline bool inCircle(int x, int y, int cx, int cy, int r) {
  return (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r;
}

// ---------- 開 / 關 App ----------
static void openApp(AppId a) {
  ui.app = a;
  ui.pressed = B_NONE;
  ui.pressedRow = -1;
  if (ui.dlg != DLG_ALERT) ui.dlg = DLG_NONE;  // 鬧鐘／倒數提示唔因切換 App 自動消失
  ui.kbPressed = -1;
  gDashboardActive = (a == APP_DASH || a == APP_HOME);
  if (a == APP_DASH) gBusForce = true;
  if (a == APP_BUS) {
    ui.busView = BV_LIST;
    ui.busScroll = 0;
    ui.busFilter[0] = 0;
  }
  if (a == APP_WIFI) {
    ui.wv = WV_LIST;
    ui.wifiScroll = 0;
    STATE_LOCK();
    bool need = gNet.scanState == 0 || !gNet.connected;
    STATE_UNLOCK();
    if (need) netRequestScan();
  }
  if (a == APP_CAL) {
    ui.calY = 0;
    ui.calM = 0;
    calEnsure();
  }
  if (a == APP_TMR && ui.tmrTab > TT_ALM) ui.tmrTab = TT_SW;
  gNeedDraw = true;
}
static void goBack() {
  if (ui.dlg != DLG_NONE) return;
  if (ui.app == APP_WIFI && ui.wv == WV_KB) {
    ui.wv = WV_LIST;
    ui.kbText[0] = 0;
  } else if (ui.app == APP_BUS && ui.busView != BV_LIST) {
    // 路線鍵盤 → 路線列表；路線列表 / 揀站 → 巴士站鍵盤；巴士站鍵盤 → 三格
    if (ui.busView == BV_KB && ui.kbMode == KM_ROUTE) ui.busView = BV_ROUTES;
    else if (ui.busView == BV_KB) ui.busView = BV_LIST;
    else {
      ui.busView = BV_KB;
      ui.kbMode = KM_STOP;
      snprintf(ui.kbText, sizeof(ui.kbText), "%s", ui.busQuery);
    }
    ui.busFilter[0] = 0;
    ui.busScroll = 0;
  } else {
    openApp(APP_HOME);
  }
  gNeedDraw = true;
}

// ---------- WiFi 動作 ----------
static bool gConnFromKb = false;
static void startConnect(const char *ssid, const char *pass, bool fromKb) {
  strncpy(ui.dlgSsid, ssid, 32);
  ui.dlgSsid[32] = 0;
  gConnFromKb = fromKb;
  netRequestConnect(ssid, pass);
  ui.dlg = DLG_CONNECTING;
}
static bool savedPass(const char *ssid, char *pass) {
  bool f = false;
  STATE_LOCK();
  for (int i = 0; i < gNet.savedCount; i++)
    if (strcmp(gNet.saved[i].ssid, ssid) == 0) {
      strcpy(pass, gNet.saved[i].pass);
      f = true;
    }
  STATE_UNLOCK();
  return f;
}
static void openKeyboard(const char *ssid, bool ssidMode) {
  ui.wv = WV_KB;
  ui.kbMode = ssidMode ? KM_SSID : KM_PASS;
  snprintf(ui.kbSsid, sizeof(ui.kbSsid), "%s", ssid ? ssid : "");
  ui.kbText[0] = 0;
  ui.kbPage = 0;
  ui.kbShift = 0;
  ui.kbShow = false;
  ui.kbPressed = -1;
}

// ---------- 巴士站設定動作 ----------
// 開巴士站鍵盤（預先填上次用過嘅站，方便同一個站加多條路線）
static void busOpenStopKb(int slot) {
  ui.busSlot = slot;
  ui.busView = BV_KB;
  ui.kbMode = KM_STOP;
  ui.kbPage = 0;
  ui.kbShift = 0;
  ui.kbPressed = -1;
  ui.busFilter[0] = 0;
  const char *pre = ui.busQuery;
  STATE_LOCK();
  if (slot < BUS_MAX_SLOTS && gBusCfg[slot].used && gBusCfg[slot].code[0]) pre = gBusCfg[slot].code;
  else if (!pre[0]) {
    for (int i = 0; i < BUS_MAX_SLOTS; i++)
      if (gBusCfg[i].used && gBusCfg[i].code[0]) {
        pre = gBusCfg[i].code;
        break;
      }
  }
  snprintf(ui.kbText, sizeof(ui.kbText), "%s", pre);
  STATE_UNLOCK();
}
// 揀咗路線 → 存入嗰格
static void busPick(const BusRouteOpt &o) {
  BusSlot c;
  memset(&c, 0, sizeof(c));
  STATE_LOCK();
  const BusStopCand &st = gBusS.stops[o.stop < gBusS.nStops ? o.stop : 0];
  c.used = true;
  utf8Copy(c.route, sizeof(c.route), o.route);
  c.dir = o.dir;
  c.serviceType = o.serviceType ? o.serviceType : 1;
  utf8Copy(c.stopId, sizeof(c.stopId), st.id);
  utf8Copy(c.code, sizeof(c.code), st.code);
  utf8Copy(c.stopName, sizeof(c.stopName), st.name);
  utf8Copy(c.dest, sizeof(c.dest), o.dest);
  int dup = busSlotOf(c.stopId, c.route, c.dir, ui.busSlot);
  STATE_UNLOCK();
  char m[96];
  if (dup >= 0) {
    snprintf(m, sizeof(m), "第 %d 格已經係呢條路線", dup + 1);
    showToast(m);
    return;
  }
  busCfgSet(ui.busSlot, c);
  snprintf(m, sizeof(m), "已儲存第 %d 格：%s 往%s", ui.busSlot + 1, c.route, c.dest);
  showToast(m, 2600);
  ui.busView = BV_LIST;
  ui.busFilter[0] = 0;
  ui.busScroll = 0;
}
// 鍵盤撳「確定」：手動輸入路線
static void busManualRoute(const char *typed) {
  char r[6];
  size_t k = 0;
  for (const char *p = typed; *p && k < sizeof(r) - 1; p++)
    if (*p != ' ') r[k++] = (*p >= 'a' && *p <= 'z') ? *p - 32 : *p;
  r[k] = 0;
  if (!k) {
    showToast("請輸入路線號碼");
    return;
  }
  // 路線列表入面有 → 直接揀（有幾個方向就俾使用者揀）
  int hit = -1, cnt = 0;
  STATE_LOCK();
  for (int i = 0; i < gBusS.nRoutes; i++)
    if (strcmp(gBusS.routes[i].route, r) == 0) {
      if (hit < 0) hit = i;
      cnt++;
    }
  BusRouteOpt o = {};
  if (hit >= 0) o = gBusS.routes[hit];
  STATE_UNLOCK();
  if (cnt == 1) {
    busPick(o);
  } else if (cnt > 1) {
    snprintf(ui.busFilter, sizeof(ui.busFilter), "%s", r);
    ui.busView = BV_ROUTES;
    ui.busScroll = 0;
  } else {
    netBusCheck(r);
    ui.dlg = DLG_BUS_BUSY;
  }
}
// loop() 叫：等網絡工作搜尋完
static void busPoll() {
  if (ui.dlg != DLG_BUS_BUSY) return;
  STATE_LOCK();
  uint8_t st = gBusS.st;
  BusRouteOpt chk = gBusS.checked;
  if (st == BSS_FAIL) snprintf(ui.dlgMsg, sizeof(ui.dlgMsg), "%s", gBusS.msg);
  if (st != BSS_BUSY) gBusS.st = BSS_IDLE;
  STATE_UNLOCK();
  switch (st) {
    case BSS_STOPS: ui.dlg = DLG_NONE; ui.busView = BV_STOPS; ui.busScroll = 0; break;
    case BSS_ROUTES: ui.dlg = DLG_NONE; ui.busView = BV_ROUTES; ui.busScroll = 0; ui.busFilter[0] = 0; break;
    case BSS_ROUTE_OK: ui.dlg = DLG_NONE; busPick(chk); break;
    case BSS_FAIL: ui.dlg = DLG_BUS_FAIL; break;
    default: return;
  }
  gNeedDraw = true;
}
static uint32_t gLastShiftTap = 0;
static void kbPress(uint8_t code) {
  size_t len = strlen(ui.kbText);
  size_t maxLen = ui.kbMode == KM_PASS ? 63 : (ui.kbMode == KM_ROUTE ? 5 : 32);
  switch (code) {
    case K_SHIFT:
      if (ui.kbShift == 0) ui.kbShift = (millis() - gLastShiftTap < 400) ? 2 : 1;
      else if (ui.kbShift == 1 && millis() - gLastShiftTap < 400) ui.kbShift = 2;  // 雙擊 = 大楷鎖定
      else ui.kbShift = 0;
      gLastShiftTap = millis();
      break;
    case K_BKSP:
      if (len) ui.kbText[len - 1] = 0;
      break;
    case K_MODE: ui.kbPage = ui.kbPage == 0 ? 1 : 0; break;
    case K_SYMTOG: ui.kbPage = ui.kbPage == 1 ? 2 : 1; break;
    case K_CLEAR: ui.kbText[0] = 0; break;
    case K_OK:
      if (ui.kbMode == KM_STOP) {
        char q[33];
        if (busClassify(ui.kbText, q, sizeof(q)) == 0) { showToast("請輸入站牌號碼，例如 YL395"); break; }
        utf8Copy(ui.busQuery, sizeof(ui.busQuery), ui.kbText);
        netBusFind(ui.kbText);
        ui.dlg = DLG_BUS_BUSY;
      } else if (ui.kbMode == KM_ROUTE) {
        busManualRoute(ui.kbText);
      } else if (ui.kbMode == KM_SSID) {
        if (len == 0) { showToast("請輸入網絡名稱"); break; }
        char ssid[33];
        strcpy(ssid, ui.kbText);
        openKeyboard(ssid, false);
      } else {
        startConnect(ui.kbSsid, ui.kbText, true);
      }
      break;
    default:
      if (len < maxLen) {
        ui.kbText[len] = kbCharFor(code);
        ui.kbText[len + 1] = 0;
      }
      if (ui.kbShift == 1) ui.kbShift = 0;
  }
}
static int kbHit(int x, int y) {
  kbLayout();
  for (int i = 0; i < gKeyN; i++)
    if (inRect(x, y, gKeys[i].x, gKeys[i].y - 1, gKeys[i].w, gKeys[i].h + 3)) return i;
  return -1;
}


// ---------- 計時／鬧鐘推進（loop 每圈叫）----------
static void timerTick() {
  uint32_t now = millis();
  bool redraw = false;
  // 倒數
  if (gTmr.cdRun) {
    uint32_t dt = now - gTmr.cdTick;
    gTmr.cdTick = now;
    if (dt < 60000) {
      if (gTmr.cdLeft > dt) gTmr.cdLeft -= dt;
      else {
        gTmr.cdLeft = 0;
        gTmr.cdRun = false;
        gTmr.alert = ALERT_COUNTDOWN;
        gTmr.alertSince = now;
        ui.dlg = DLG_ALERT;
        redraw = true;
      }
    }
    if (ui.app == APP_TMR && ui.tmrTab == TT_CD) redraw = true;
  }
  // 碼錶畫面刷新
  if (gTmr.swRun && ui.app == APP_TMR && ui.tmrTab == TT_SW) redraw = true;
  // 鬧鐘
  if (gTmr.almOn && gTmr.alert == ALERT_NONE) {
    struct tm t;
    if (nowLocal(&t)) {
      int yday = t.tm_yday;
      if (t.tm_hour == gTmr.almH && t.tm_min == gTmr.almM && t.tm_sec < 3) {
        if (gTmr.almLastYday != yday) {
          gTmr.almLastYday = yday;
          gTmr.alert = ALERT_ALARM;
          gTmr.alertSince = now;
          ui.dlg = DLG_ALERT;
          redraw = true;
        }
      }
    }
  }
  // 提示閃爍
  if (ui.dlg == DLG_ALERT) {
    ui.frame++;
    redraw = true;
  }
  if (redraw) gNeedDraw = true;
}
static void timerDismissAlert() {
  gTmr.alert = ALERT_NONE;
  ui.dlg = DLG_NONE;
  gNeedDraw = true;
}

// ---------- 撳落去：決定高亮邊個掣 ----------
static uint8_t hitButton(int x, int y) {
  if (ui.dlg != DLG_NONE) {
    const char *lb[3];
    int n = dlgButtons(lb);
    for (int i = 0; i < n; i++) {
      int bx, by, bw, bh;
      dlgButtonRect(i, n, &bx, &by, &bw, &bh);
      if (inRect(x, y, bx, by, bw, bh)) return B_DLG0 + i;
    }
    return B_NONE;
  }
  if (ui.app != APP_HOME && inRect(x, y, 0, 0, 110, HDR_H + 4)) return B_BACK;
  switch (ui.app) {
    case APP_HOME: {
      for (int i = 0; i < HOME_ICONS; i++)
        if (inRect(x, y, HOME_ICON_X[i] - 6, HOME_ROW1_Y - 4, HOME_ICON_SZ + 12, HOME_ICON_SZ + 22))
          return B_ICON0 + i;
      if (inRect(x, y, 10, HOME_CARD_Y, 300, HOME_CARD_H)) return B_HOMECARD;
      return B_NONE;
    }
    case APP_DASH:
      if (inRect(x, y, 4, 158, 312, 78)) return B_BUSCARD;
      return B_NONE;
    case APP_CAL:
      if (inRect(x, y, 244, 0, 36, HDR_H + 4)) return B_CAL_PREV;
      if (inRect(x, y, 280, 0, 40, HDR_H + 4)) return B_CAL_NEXT;
      return B_NONE;
    case APP_TMR:
      for (int i = 0; i < 3; i++)
        if (inRect(x, y, 8 + i * 104, 28, 100, 28)) return B_TMR_TAB0 + i;
      if (ui.tmrTab == TT_SW) {
        if (inRect(x, y, 40, 148, 110, 44)) return B_TMR_START;
        if (inRect(x, y, 170, 148, 110, 44)) return B_TMR_RESET;
      } else if (ui.tmrTab == TT_CD) {
        if (!gTmr.cdRun) {
          if (inRect(x, y, 70, 118, 44, 30)) return B_TMR_M_UP;
          if (inRect(x, y, 70, 150, 44, 30)) return B_TMR_M_DN;
          if (inRect(x, y, 206, 118, 44, 30)) return B_TMR_S_UP;
          if (inRect(x, y, 206, 150, 44, 30)) return B_TMR_S_DN;
        }
        if (inRect(x, y, 40, 188, 110, 40)) return B_TMR_START;
        if (inRect(x, y, 170, 188, 110, 40)) return B_TMR_RESET;
      } else {
        if (inRect(x, y, 70, 126, 44, 30)) return B_TMR_H_UP;
        if (inRect(x, y, 70, 158, 44, 30)) return B_TMR_H_DN;
        if (inRect(x, y, 206, 126, 44, 30)) return B_TMR_M_UP;
        if (inRect(x, y, 206, 158, 44, 30)) return B_TMR_M_DN;
        if (inRect(x, y, 90, 196, 140, 36)) return B_ALM_TOGGLE;
      }
      return B_NONE;
    case APP_BUS:
      if (ui.busView == BV_ROUTES && inRect(x, y, 232, 0, 88, HDR_H + 4)) return B_BMANUAL;
      if (ui.busView == BV_LIST && inRect(x, y, 0, 210, 100, 30)) return B_BRESET;
      return B_NONE;
    case APP_WIFI:
      if (ui.wv == WV_KB) {
        if (ui.kbMode == KM_PASS && inRect(x, y, 272, KB_BOX_Y - 4, 48, KB_BOX_H + 6)) return B_EYE;
        return B_NONE;
      }
      if (inRect(x, y, 236, 0, 42, HDR_H + 4)) return B_WADD;
      if (inRect(x, y, 278, 0, 42, HDR_H + 4)) return B_WSCAN;
      if (inRect(x, y, 0, WF_TABS_Y - 2, 160, 28)) return B_TAB0;
      if (inRect(x, y, 160, WF_TABS_Y - 2, 160, 28)) return B_TAB1;
      return B_NONE;
    default: return B_NONE;
  }
}
static int hitRow(int x, int y) {
  if (ui.dlg != DLG_NONE) return -1;
  if (ui.app == APP_WIFI && ui.wv == WV_LIST && y >= WF_LIST_Y) {
    int r = (y - WF_LIST_Y + ui.wifiScroll) / WF_ROW_H;
    return r < wifiRowCount() ? r : -1;
  }
  if (ui.app == APP_BUS && ui.busView == BV_LIST && y >= BL_Y0) {
    int r = (y - BL_Y0) / BL_RH;
    return (r < BUS_MAX_SLOTS && (y - BL_Y0) % BL_RH < BL_RH - 4) ? r : -1;
  }
  if (ui.app == APP_BUS && (ui.busView == BV_STOPS || ui.busView == BV_ROUTES) && y >= BR_LIST_Y) {
    int r = (y - BR_LIST_Y + ui.busScroll) / BR_ROW_H;
    STATE_LOCK();
    int n = busRowCount();
    STATE_UNLOCK();
    return r < n ? r : -1;
  }
  return -1;
}

// ---------- 確認撳（放手時）----------
static void onButton(uint8_t b) {
  switch (b) {
    case B_BACK: goBack(); break;
    case B_ICON0: openApp(APP_DASH); break;
    case B_ICON1: openApp(APP_CAL); break;
    case B_ICON2: openApp(APP_TMR); break;
    case B_ICON3: openApp(APP_WIFI); break;
    case B_ICON4: case B_BUSCARD: openApp(APP_BUS); break;
    case B_CAL_PREV:
      calEnsure();
      if (--ui.calM < 1) { ui.calM = 12; ui.calY--; }
      break;
    case B_CAL_NEXT:
      calEnsure();
      if (++ui.calM > 12) { ui.calM = 1; ui.calY++; }
      break;
    case B_TMR_TAB0: ui.tmrTab = TT_SW; break;
    case B_TMR_TAB1: ui.tmrTab = TT_CD; break;
    case B_TMR_TAB2: ui.tmrTab = TT_ALM; break;
    case B_TMR_START:
      if (ui.tmrTab == TT_SW) {
        if (gTmr.swRun) {
          gTmr.swAcc += millis() - gTmr.swStart;
          gTmr.swRun = false;
        } else {
          gTmr.swStart = millis();
          gTmr.swRun = true;
        }
      } else if (ui.tmrTab == TT_CD) {
        if (gTmr.cdRun) {
          gTmr.cdRun = false;
        } else {
          if (gTmr.cdLeft == 0)
            gTmr.cdLeft = ((uint32_t)gTmr.cdSetM * 60u + gTmr.cdSetS) * 1000u;
          if (gTmr.cdLeft == 0) { showToast("請先設定時間"); break; }
          gTmr.cdTick = millis();
          gTmr.cdRun = true;
        }
      }
      break;
    case B_TMR_RESET:
      if (ui.tmrTab == TT_SW) {
        gTmr.swRun = false;
        gTmr.swAcc = 0;
      } else if (ui.tmrTab == TT_CD) {
        gTmr.cdRun = false;
        gTmr.cdLeft = ((uint32_t)gTmr.cdSetM * 60u + gTmr.cdSetS) * 1000u;
      }
      break;
    case B_TMR_H_UP: gTmr.almH = (gTmr.almH + 1) % 24; alarmSave(); break;
    case B_TMR_H_DN: gTmr.almH = (gTmr.almH + 23) % 24; alarmSave(); break;
    case B_TMR_M_UP:
      if (ui.tmrTab == TT_ALM) { gTmr.almM = (gTmr.almM + 1) % 60; alarmSave(); }
      else if (gTmr.cdSetM < 99) gTmr.cdSetM++;
      break;
    case B_TMR_M_DN:
      if (ui.tmrTab == TT_ALM) { gTmr.almM = (gTmr.almM + 59) % 60; alarmSave(); }
      else if (gTmr.cdSetM > 0) gTmr.cdSetM--;
      break;
    case B_TMR_S_UP: gTmr.cdSetS = (gTmr.cdSetS + 1) % 60; break;
    case B_TMR_S_DN: gTmr.cdSetS = (gTmr.cdSetS + 59) % 60; break;
    case B_ALM_TOGGLE:
      gTmr.almOn = !gTmr.almOn;
      gTmr.almLastYday = -1;
      if (!gTmr.almLabel[0]) snprintf(gTmr.almLabel, sizeof(gTmr.almLabel), "鬧鐘");
      alarmSave();
      showToast(gTmr.almOn ? "鬧鐘已開啟" : "鬧鐘已關閉");
      break;
    case B_HOMECARD: {  // 主畫面底部卡片：未連線 → WiFi 設定；未設定路線 → 巴士站設定；否則 → 儀表板
      STATE_LOCK();
      bool con = gNet.connected, any = false;
      for (int i = 0; i < BUS_MAX_SLOTS; i++) any |= gBusCfg[i].used;
      STATE_UNLOCK();
      openApp(!con ? APP_WIFI : (!any ? APP_BUS : APP_DASH));
      break;
    }
    case B_BMANUAL:
      ui.busView = BV_KB;
      ui.kbMode = KM_ROUTE;
      ui.kbText[0] = 0;
      ui.kbPressed = -1;
      break;
    case B_BRESET: ui.dlg = DLG_BUS_RESET; break;
    case B_WSCAN: netRequestScan(); break;
    case B_WADD: openKeyboard("", true); break;
    case B_TAB0: ui.wifiTab = 0; ui.wifiScroll = 0; break;
    case B_TAB1: ui.wifiTab = 1; ui.wifiScroll = 0; break;
    case B_EYE: ui.kbShow = !ui.kbShow; break;
    case B_DLG0: case B_DLG1: case B_DLG2: {
      int i = b - B_DLG0;
      Dlg d = ui.dlg;
      if (d == DLG_ALERT) { timerDismissAlert(); break; }
      ui.dlg = DLG_NONE;
      if (d == DLG_BUS_SLOT) {
        if (i == 0) busOpenStopKb(ui.busSlot);
        else if (i == 1) {
          busCfgDelete(ui.busSlot);
          showToast("已刪除呢一格");
        }
      } else if (d == DLG_BUS_RESET) {
        if (i == 0) {
          busCfgReset();
          showToast("已還原預設路線");
        }
      } else if (d == DLG_SAVED) {
        if (i == 0) {
          char pass[65] = "";
          savedPass(ui.dlgSsid, pass);
          char ssid[33];
          strcpy(ssid, ui.dlgSsid);
          startConnect(ssid, pass, false);
        } else if (i == 1) {
          netRequestForget(ui.dlgSsid);
          showToast("已忘記這個網絡");
        }
      } else if (d == DLG_OK) {
        ui.wv = WV_LIST;
        ui.kbText[0] = 0;
      } else if (d == DLG_FAIL) {
        if (i == 0) {  // 重試
          if (gConnFromKb) ui.wv = WV_KB;
          else {
            char pass[65] = "", ssid[33];
            strcpy(ssid, ui.dlgSsid);
            savedPass(ssid, pass);
            startConnect(ssid, pass, false);
          }
        } else {
          ui.wv = WV_LIST;
        }
      }
      break;
    }
  }
  gNeedDraw = true;
}
static void onRowTap(int row, int x) {
  if (ui.app == APP_BUS) {
    if (ui.busView == BV_LIST) {
      STATE_LOCK();
      bool used = gBusCfg[row].used;
      STATE_UNLOCK();
      ui.busSlot = row;
      if (used) ui.dlg = DLG_BUS_SLOT;
      else busOpenStopKb(row);
    } else if (ui.busView == BV_STOPS) {
      netBusRoutes(row);
      ui.dlg = DLG_BUS_BUSY;
    } else if (ui.busView == BV_ROUTES) {
      STATE_LOCK();
      uint8_t idx[BS_MAX_ROUTES];
      int n = busVisibleRoutes(idx);
      BusRouteOpt o = {};
      if (row < n) o = gBusS.routes[idx[row]];
      STATE_UNLOCK();
      if (row < n) busPick(o);
    }
  } else if (ui.app == APP_WIFI) {
    char ssid[33];
    bool secure = true, saved;
    STATE_LOCK();
    if (ui.wifiTab == 0) {
      strcpy(ssid, gNet.scan[row].ssid);
      secure = gNet.scan[row].secure;
    } else {
      strcpy(ssid, gNet.saved[row].ssid);
    }
    saved = isSaved(ssid);
    bool cur = gNet.connected && strcmp(gNet.ssid, ssid) == 0;
    STATE_UNLOCK();
    if (ui.wifiTab == 1 && x >= 256) {  // 「忘記」小掣
      netRequestForget(ssid);
      showToast("已忘記這個網絡");
    } else if (saved) {
      strcpy(ui.dlgSsid, ssid);
      ui.dlg = DLG_SAVED;
    } else if (cur) {
      showToast("已連線到這個網絡");
    } else if (!secure) {
      startConnect(ssid, "", false);
    } else {
      openKeyboard(ssid, false);
    }
  }
  gNeedDraw = true;
}

// ---------- 觸控狀態機 ----------
struct TouchSM {
  bool down;
  int16_t sx, sy, x, y;
  uint32_t t0, lastSeen, lastRepeat;
  bool dragging;
  int scroll0;
  uint8_t btn;
  int row, key;
};
static TouchSM ts = {};

static int *activeScroll(int *maxS) {
  if (ui.dlg != DLG_NONE) return nullptr;
  if (ui.app == APP_WIFI && ui.wv == WV_LIST && ts.sy >= WF_LIST_Y) {
    *maxS = wifiMaxScroll();
    return &ui.wifiScroll;
  }
  if (ui.app == APP_BUS && (ui.busView == BV_STOPS || ui.busView == BV_ROUTES) && ts.sy >= BR_LIST_Y) {
    STATE_LOCK();
    *maxS = busMaxScroll();
    STATE_UNLOCK();
    return &ui.busScroll;
  }
  return nullptr;
}
static void touchUpdate() {
  int16_t x, y;
  bool t = touchRead(&x, &y);
  uint32_t now = millis();
#if TOUCH_DEBUG
  // 除錯：手指郁就重畫十字同座標
  static int16_t dbgX = -1, dbgY = -1;
  if (t && (x != dbgX || y != dbgY)) {
    dbgX = x;
    dbgY = y;
    gNeedDraw = true;
  }
#endif
  if (t) {
    ts.lastSeen = now;
    if (!ts.down) {  // 新觸碰
      ts.down = true;
      ts.sx = ts.x = x;
      ts.sy = ts.y = y;
      ts.t0 = ts.lastRepeat = now;
      ts.dragging = false;
      ts.btn = hitButton(x, y);
      ts.row = (ts.btn == B_NONE) ? hitRow(x, y) : -1;
      bool kbOn = (ui.app == APP_WIFI && ui.wv == WV_KB) || (ui.app == APP_BUS && ui.busView == BV_KB);
      ts.key = (kbOn && ui.dlg == DLG_NONE && ts.btn == B_NONE) ? kbHit(x, y) : -1;
      int ms;
      int *sp = activeScroll(&ms);
      ts.scroll0 = sp ? *sp : 0;
      ui.pressed = ts.btn;
      ui.pressedRow = ts.row;
      ui.kbPressed = ts.key;
      gNeedDraw = true;
    } else {
      ts.x = x;
      ts.y = y;
      int dy = y - ts.sy;
      int ms;
      int *sp = activeScroll(&ms);
      if (sp && !ts.dragging && abs(dy) > 8) {
        ts.dragging = true;
        ui.pressedRow = -1;
        gNeedDraw = true;
      }
      if (ts.dragging && sp) {
        int ns = ts.scroll0 - dy;
        if (ns < 0) ns = 0;
        if (ns > ms) ns = ms;
        if (ns != *sp) {
          *sp = ns;
          gNeedDraw = true;
        }
      }
      // 長按 ⌫ 連續刪除
      if (ts.key >= 0 && gKeys[ts.key].code == K_BKSP && now - ts.t0 > 500 && now - ts.lastRepeat > 80) {
        ts.lastRepeat = now;
        kbPress(K_BKSP);
        gNeedDraw = true;
      }
    }
  } else if (ts.down && now - ts.lastSeen > 60) {  // 放手（CST328 會間歇回報 0 點，所以等 60ms 先當放手）
    ts.down = false;
    int dx = ts.x - ts.sx, dy = ts.y - ts.sy;
    bool moved = abs(dx) > 14 || abs(dy) > 14;
    ui.pressed = B_NONE;
    ui.pressedRow = -1;
    int key = ts.key;
    ui.kbPressed = -1;
    gNeedDraw = true;
    if (ts.dragging) return;
    // 日曆左右掃換月
    if (ui.app == APP_CAL && abs(dx) > 60 && abs(dy) < 40) {
      calEnsure();
      if (dx < 0) { if (++ui.calM > 12) { ui.calM = 1; ui.calY++; } }
      else { if (--ui.calM < 1) { ui.calM = 12; ui.calY--; } }
      gNeedDraw = true;
      return;
    }
    // 由左邊緣向右掃 = 返回
    if (ui.app != APP_HOME && ts.sx < 40 && dx > 80 && abs(dy) < 60) {
      goBack();
      return;
    }
    if (moved) return;
    if (ts.btn != B_NONE) {
      if (hitButton(ts.x, ts.y) == ts.btn) onButton(ts.btn);
    } else if (ts.row >= 0) {
      onRowTap(ts.row, ts.sx);
    } else if (key >= 0) {
      bool repeated = gKeys[key].code == K_BKSP && now - ts.t0 > 500;
      if (!repeated) kbPress(gKeys[key].code);
    }
  }
}
