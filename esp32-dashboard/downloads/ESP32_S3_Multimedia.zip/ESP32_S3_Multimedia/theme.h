#pragma once
// 現代深色主題（沿用資訊儀表板嘅配色，再加幾隻強調色）
#ifndef RGB565
#define RGB565(r, g, b) ((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))
#endif

#define COL_BG       0x10A2  // 深炭灰底
#define COL_BG2      0x0861  // 漸層底部
#define COL_CARD     0x18E3  // 卡片
#define COL_CARD_HI  0x2945  // 卡片（按下 / 高亮）
#define COL_TEXT     0xEF7D  // 柔白
#define COL_MUTED    0x8410  // 次要灰
#define COL_ACCENT   0x07BB  // 青藍強調色
#define COL_ACCENT_D 0x0311  // 深青（選中行底色）
#define COL_LINE     0x3186  // 分隔線
#define COL_WARN     0xFBE4  // 琥珀
#define COL_OK       RGB565(52, 199, 89)
#define COL_DANGER   RGB565(255, 69, 58)
#define COL_KMB      RGB565(218, 32, 40)   // 九巴紅
#define COL_SUN      RGB565(255, 196, 0)
#define COL_CLOUD    RGB565(200, 208, 220)
#define COL_CLOUD_D  RGB565(130, 140, 155)
#define COL_RAIN     RGB565(64, 156, 255)
#define COL_BOLT     RGB565(255, 214, 10)
#define COL_MOON     RGB565(235, 225, 170)
#define COL_KEY      0x3186  // 鍵盤按鍵
#define COL_KEY_FN   0x2104  // 功能鍵
#define COL_KEY_HI   0x5AEB  // 按下

// 字型：Arduino_GFX 內附嘅 U8g2 CJK 字型 + U8g2 拉丁 / 數字字型
#define F_ZH16  u8g2_font_unifont_h_chinese4 // 16px，7199 個常用中文字；缺字自動改用 F_ZH12
#define F_ZH12  u8g2_font_cubic11_h_cjk      // 12px 俐方體11號，10167 字（含粵語字、簡體、假名）
#define F_CLOCK u8g2_font_logisoso34_tn      // 大時鐘
#define F_BIG   u8g2_font_fub20_tf           // 溫度（含 °）
#define F_NUM   u8g2_font_fub17_tr           // 巴士分鐘
#define F_MED   u8g2_font_helvB12_tr         // 路線號 / 鍵盤
#define F_SMALL u8g2_font_helvB10_tf         // 細數字（含 °）
#define F_TINY  u8g2_font_helvR08_tr         // 好細嘅數字
