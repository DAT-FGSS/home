#pragma once
/*
 * Waveshare ESP32-S3-Touch-LCD-2.8 腳位表
 *
 * 所有腳位都係由 Waveshare 官方資料抄出嚟，冇估：
 *   [W] 官方 Wiki「Internal Hardware Connection」表
 *       https://www.waveshare.com/wiki/ESP32-S3-Touch-LCD-2.8
 *   [D] 官方 Arduino Demo（ESP32-S3-Touch-LCD-2.8-Demo.zip →
 *       Arduino/examples/LVGL_Arduino/）
 *       https://files.waveshare.com/wiki/ESP32-S3-Touch-LCD-2.8/ESP32-S3-Touch-LCD-2.8-Demo.zip
 *
 * 板上冇 IO expander：LCD、觸控（同埋本程式冇用嘅 SD、I2S）全部直接接 ESP32-S3 GPIO。
 */

// ---- LCD：ST7789，240x320，SPI ----  [W] LCD 表；[D] Display_ST7789.h
#define LCD_SCK   40
#define LCD_MOSI  45
#define LCD_MISO  -1   // NC
#define LCD_CS    42
#define LCD_DC    41
#define LCD_RST   39
#define LCD_BL     5   // 背光 PWM
#define LCD_SPI_HZ 80000000UL  // [D] Display_ST7789.h: SPIFreq 80000000

// ---- 觸控：獨立 I2C 匯流排（Wire1），晶片開機自動偵測（見 touch_drv.h）----
//   V1 板：CST328 @0x1A   [D] Touch_CST328.h：CST328_ADDR 0x1A，400kHz，用 Wire1
//   V2 板：CST3530 @0x58  [D2] ESP32-S3-Touch-LCD-2.8-V2-Demo.zip → Touch_CST3530.h：CST3530_ADDR 0x58，同一組腳
//   （Waveshare：V1 已停產，2026-06-05 起出貨改為 V2：https://docs.waveshare.com/ESP32-S3-Touch-LCD-2.8）
// [W] LCD 表：TP_SDA=GPIO1, TP_SCL=GPIO3, TP_INT=GPIO4, TP_RST=GPIO2
#define TP_SDA     1
#define TP_SCL     3
#define TP_INT     4
#define TP_RST     2
#define TP_I2C_ADDR 0x1A   // CST328（V1）；CST3530（V2）用 0x58
#define TP_I2C_HZ  400000

// ---- 本程式冇用（音樂播放功能已刪除），留返做參考 ----
// microSD（TF）卡 SDMMC 1-bit：CLK=14, CMD=17, D0=16, D3=21   [W] TF Card 表；[D] SD_Card.h
// PCM5101 I2S 音訊：BCLK=48, LRCK=38, DOUT=47                  [W] Speaker 表；[D] Audio_PCM5101.h

// ---- 電池電源鍵（只係用電池時有用）----  [D] PWR_Key.h
#define PWR_KEY_PIN   6
#define PWR_CTRL_PIN  7

// ---- 板載 I2C（RTC PCF85063 0x51 / IMU QMI8658 0x6B），本程式冇用 ----  [W][D]
// #define I2C_SDA 11
// #define I2C_SCL 10
