#pragma once
#include <stdio.h>
// 農曆（2020–2036）、二十四節氣、香港公眾假期、簡短宜忌
// 傳統中文；資料表細小，適合 3MB APP 分區。
#include <stdint.h>
#include <time.h>
#include <string.h>

#define LUNAR_Y0 2020
#define LUNAR_YN 17  // 2020..2036

// 農曆年正月初一距 2020-01-01 嘅日數；最後一項係 2037 年正月初一（上界）
static const uint16_t LUNAR_NY[LUNAR_YN + 1] = {
    24, 408, 762, 1117, 1501, 1855, 2239, 2593, 2947, 3331, 3686, 4040, 4424, 4779, 5163, 5517, 5871,
    6255  // 2037-02-15 approx upper bound; regenerated: verify below
};
// bits0-3 = 閏月（0=無）；bit(4+i)=1 → 該月（含閏，按時間序）30 日，否則 29 日
static const uint32_t LUNAR_ENC[LUNAR_YN] = {
    0x152E4u, 0x05560u, 0x0AB50u, 0x15B22u, 0x06D20u, 0x0EA56u, 0x07250u, 0x064B0u, 0x0C975u,
    0x0CAB0u, 0x055A0u, 0x0AD63u, 0x0B690u, 0x1752Bu, 0x0B520u, 0x0B250u, 0x1A4B6u};

// 二十四節氣：每年 24 個「日」（月固定：1,1,2,2,…,12,12）
static const uint8_t SOLAR_TERM_DAY[LUNAR_YN][24] = {
    {6, 20, 4, 19, 5, 20, 4, 19, 5, 20, 5, 21, 6, 22, 7, 22, 7, 22, 8, 23, 7, 22, 7, 21},  // 2020
    {5, 20, 3, 18, 5, 20, 4, 20, 5, 21, 5, 21, 7, 22, 7, 23, 7, 23, 8, 23, 7, 22, 7, 21},  // 2021
    {5, 20, 4, 19, 5, 20, 5, 20, 5, 21, 6, 21, 7, 23, 7, 23, 7, 23, 8, 23, 7, 22, 7, 22},  // 2022
    {5, 20, 4, 19, 6, 21, 5, 20, 6, 21, 6, 21, 7, 23, 8, 23, 8, 23, 8, 24, 8, 22, 7, 22},  // 2023
    {6, 20, 4, 19, 5, 20, 4, 19, 5, 20, 5, 21, 6, 22, 7, 22, 7, 22, 8, 23, 7, 22, 6, 21},  // 2024
    {5, 20, 3, 18, 5, 20, 4, 20, 5, 21, 5, 21, 7, 22, 7, 23, 7, 23, 8, 23, 7, 22, 7, 21},  // 2025
    {5, 20, 4, 18, 5, 20, 5, 20, 5, 21, 5, 21, 7, 23, 7, 23, 7, 23, 8, 23, 7, 22, 7, 22},  // 2026
    {5, 20, 4, 19, 6, 21, 5, 20, 6, 21, 6, 21, 7, 23, 8, 23, 8, 23, 8, 23, 7, 22, 7, 22},  // 2027
    {6, 20, 4, 19, 5, 20, 4, 19, 5, 20, 5, 21, 6, 22, 7, 22, 7, 22, 8, 23, 7, 22, 6, 21},  // 2028
    {5, 20, 3, 18, 5, 20, 4, 20, 5, 21, 5, 21, 7, 22, 7, 23, 7, 23, 8, 23, 7, 22, 7, 21},  // 2029
    {5, 20, 4, 18, 5, 20, 5, 20, 5, 21, 5, 21, 7, 23, 7, 23, 7, 23, 8, 23, 7, 22, 7, 22},  // 2030
    {5, 20, 4, 19, 6, 21, 5, 20, 6, 21, 6, 21, 7, 23, 8, 23, 8, 23, 8, 23, 7, 22, 7, 22},  // 2031
    {6, 20, 4, 19, 5, 20, 4, 19, 5, 20, 5, 21, 6, 22, 7, 22, 7, 22, 8, 23, 7, 22, 6, 21},  // 2032
    {5, 20, 3, 18, 5, 20, 4, 20, 5, 21, 5, 21, 7, 22, 7, 23, 7, 23, 8, 23, 7, 22, 7, 21},  // 2033
    {5, 20, 4, 18, 5, 20, 5, 20, 5, 21, 5, 21, 7, 23, 7, 23, 7, 23, 8, 23, 7, 22, 7, 22},  // 2034
    {5, 20, 4, 19, 6, 21, 5, 20, 5, 21, 6, 21, 7, 23, 7, 23, 8, 23, 8, 23, 7, 22, 7, 22},  // 2035
    {6, 20, 4, 19, 5, 20, 4, 19, 5, 20, 5, 21, 6, 22, 7, 22, 7, 22, 8, 23, 7, 22, 6, 21},  // 2036
};
static const uint8_t SOLAR_TERM_MON[24] = {1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12};
static const char *const SOLAR_TERM_NAME[24] = {
    "小寒", "大寒", "立春", "雨水", "驚蟄", "春分", "清明", "穀雨", "立夏", "小滿", "芒種", "夏至",
    "小暑", "大暑", "立秋", "處暑", "白露", "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至"};

static const char *const LDAY_NAME[31] = {
    "",   "初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十",
    "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十",
    "廿一", "廿二", "廿三", "廿四", "廿五", "廿六", "廿七", "廿八", "廿九", "三十"};
static const char *const LMON_NAME[13] = {"", "正月", "二月", "三月", "四月", "五月", "六月",
                                          "七月", "八月", "九月", "十月", "冬月", "臘月"};

struct CalHoliday {
  uint16_t y;
  uint8_t m, d;
  const char *name;  // 短名（格內顯示）
};
// 香港公眾假期 2026–2028（2028 為坊間推算，政府憲報未出前僅供參考）
static const CalHoliday HK_HOLIDAYS[] = {
    // 2026（政府憲報）
    {2026, 1, 1, "元旦"},   {2026, 2, 17, "年初一"}, {2026, 2, 18, "年初二"}, {2026, 2, 19, "年初三"},
    {2026, 4, 3, "受難節"}, {2026, 4, 4, "受難翌日"}, {2026, 4, 6, "清明日"}, {2026, 4, 7, "復活翌日"},
    {2026, 5, 1, "勞動節"}, {2026, 5, 25, "佛誕翌日"}, {2026, 6, 19, "端午"}, {2026, 7, 1, "特區日"},
    {2026, 9, 26, "中秋翌日"}, {2026, 10, 1, "國慶"}, {2026, 10, 19, "重陽翌日"},
    {2026, 12, 25, "聖誕"}, {2026, 12, 26, "節禮日"},
    // 2027（政府憲報）
    {2027, 1, 1, "元旦"},   {2027, 2, 6, "年初一"}, {2027, 2, 8, "年初三"}, {2027, 2, 9, "年初四"},
    {2027, 3, 26, "受難節"}, {2027, 3, 27, "受難翌日"}, {2027, 3, 29, "復活節"}, {2027, 4, 5, "清明"},
    {2027, 5, 1, "勞動節"}, {2027, 5, 13, "佛誕"}, {2027, 6, 9, "端午"}, {2027, 7, 1, "特區日"},
    {2027, 9, 16, "中秋翌日"}, {2027, 10, 1, "國慶"}, {2027, 10, 8, "重陽"},
    {2027, 12, 25, "聖誕"}, {2027, 12, 27, "節禮日"},
    // 2028（推算）
    {2028, 1, 1, "元旦"},   {2028, 1, 26, "年初一"}, {2028, 1, 27, "年初二"}, {2028, 1, 28, "年初三"},
    {2028, 4, 4, "清明"},   {2028, 4, 14, "受難節"}, {2028, 4, 15, "受難翌日"}, {2028, 4, 17, "復活節"},
    {2028, 5, 1, "勞動節"}, {2028, 5, 2, "佛誕"}, {2028, 5, 29, "端午"}, {2028, 7, 1, "特區日"},
    {2028, 10, 2, "國慶補假"}, {2028, 10, 4, "中秋翌日"}, {2028, 10, 26, "重陽"},
    {2028, 12, 25, "聖誕"}, {2028, 12, 26, "節禮日"},
};
#define HK_HOLIDAY_N (sizeof(HK_HOLIDAYS) / sizeof(HK_HOLIDAYS[0]))

// 簡短宜忌：按星期＋農曆日號取模，唔係完整通勝
static const char *const YI_LIST[] = {"出行", "簽約", "交易", "開業", "祈福", "求嗣", "上課", "會友", "掃除", "納財"};
static const char *const JI_LIST[] = {"嫁娶", "安床", "作灶", "探病", "動土", "安葬", "開張", "移徙", "豎柱", "行船"};
#define YI_N 10
#define JI_N 10

struct LunarDate {
  int year, month, day;
  bool leap;
  bool ok;
};

static int calDaysInMonth(int y, int m) {
  static const uint8_t md[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if (m < 1 || m > 12) return 0;
  if (m == 2) {
    bool ly = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
    return ly ? 29 : 28;
  }
  return md[m - 1];
}

static int calDayOfWeek(int y, int m, int d) {  // 0=日
  struct tm t = {};
  t.tm_year = y - 1900;
  t.tm_mon = m - 1;
  t.tm_mday = d;
  t.tm_hour = 12;
  mktime(&t);
  return t.tm_wday;
}

static int calSolarOffset(int y, int m, int d) {  // 距 2020-01-01
  struct tm t0 = {}, t1 = {};
  t0.tm_year = 2020 - 1900;
  t0.tm_mon = 0;
  t0.tm_mday = 1;
  t0.tm_hour = 12;
  t1.tm_year = y - 1900;
  t1.tm_mon = m - 1;
  t1.tm_mday = d;
  t1.tm_hour = 12;
  time_t a = mktime(&t0), b = mktime(&t1);
  if (a == (time_t)-1 || b == (time_t)-1) return -1;
  return (int)((b - a) / 86400);
}

static LunarDate solarToLunar(int y, int m, int d) {
  LunarDate r = {};
  int off = calSolarOffset(y, m, d);
  if (off < LUNAR_NY[0] || off >= LUNAR_NY[LUNAR_YN]) return r;
  int yi = 0;
  for (int i = 0; i < LUNAR_YN; i++) {
    if (off >= LUNAR_NY[i] && off < LUNAR_NY[i + 1]) {
      yi = i;
      break;
    }
  }
  uint32_t enc = LUNAR_ENC[yi];
  int leap = enc & 0xF;
  int n = leap ? 13 : 12;
  int rem = off - LUNAR_NY[yi];
  for (int i = 0; i < n; i++) {
    int len = ((enc >> (4 + i)) & 1) ? 30 : 29;
    if (rem < len) {
      r.year = LUNAR_Y0 + yi;
      if (leap) {
        if (i < leap) {
          r.month = i + 1;
          r.leap = false;
        } else if (i == leap) {
          r.month = leap;
          r.leap = true;
        } else {
          r.month = i;  // i=leap+1 → month leap+1
          r.leap = false;
        }
      } else {
        r.month = i + 1;
        r.leap = false;
      }
      r.day = rem + 1;
      r.ok = true;
      return r;
    }
    rem -= len;
  }
  return r;
}

static const char *calHolidayName(int y, int m, int d) {
  for (size_t i = 0; i < HK_HOLIDAY_N; i++)
    if (HK_HOLIDAYS[i].y == y && HK_HOLIDAYS[i].m == m && HK_HOLIDAYS[i].d == d) return HK_HOLIDAYS[i].name;
  return nullptr;
}

static const char *calSolarTermName(int y, int m, int d) {
  if (y < LUNAR_Y0 || y >= LUNAR_Y0 + LUNAR_YN) return nullptr;
  int yi = y - LUNAR_Y0;
  for (int i = 0; i < 24; i++)
    if (SOLAR_TERM_MON[i] == m && SOLAR_TERM_DAY[yi][i] == d) return SOLAR_TERM_NAME[i];
  return nullptr;
}

// 格內短標籤：優先假期／節氣，否則農曆日（初一顯示月份）
static void calCellLabel(int y, int m, int d, char *out, size_t n) {
  out[0] = 0;
  const char *h = calHolidayName(y, m, d);
  if (h) {
    snprintf(out, n, "%s", h);
    return;
  }
  const char *t = calSolarTermName(y, m, d);
  if (t) {
    snprintf(out, n, "%s", t);
    return;
  }
  LunarDate L = solarToLunar(y, m, d);
  if (!L.ok) return;
  if (L.day == 1) {
    if (L.leap) snprintf(out, n, "閏%s", LMON_NAME[L.month]);
    else snprintf(out, n, "%s", LMON_NAME[L.month]);
  } else if (L.day >= 1 && L.day <= 30) {
    snprintf(out, n, "%s", LDAY_NAME[L.day]);
  }
}

static void __attribute__((unused)) calLunarLine(int y, int m, int d, char *out, size_t n) {
  LunarDate L = solarToLunar(y, m, d);
  if (!L.ok) {
    snprintf(out, n, "農曆 （範圍外）");
    return;
  }
  snprintf(out, n, "農曆 %s%s%s", L.leap ? "閏" : "", LMON_NAME[L.month], LDAY_NAME[L.day]);
}

static void calYiJi(int y, int m, int d, char *yi, size_t yn, char *ji, size_t jn) {
  LunarDate L = solarToLunar(y, m, d);
  int w = calDayOfWeek(y, m, d);
  int seed = (L.ok ? (L.month * 31 + L.day) : (m * 31 + d)) + w * 3;
  int i0 = seed % YI_N, i1 = (seed / 3) % YI_N;
  if (i1 == i0) i1 = (i1 + 1) % YI_N;
  int j0 = (seed * 5 + 2) % JI_N, j1 = (seed * 7 + 1) % JI_N;
  if (j1 == j0) j1 = (j1 + 1) % JI_N;
  snprintf(yi, yn, "%s、%s、%s", YI_LIST[i0], YI_LIST[i1], YI_LIST[(i0 + 4) % YI_N]);
  snprintf(ji, jn, "%s、%s、%s", JI_LIST[j0], JI_LIST[j1], JI_LIST[(j0 + 3) % JI_N]);
}
