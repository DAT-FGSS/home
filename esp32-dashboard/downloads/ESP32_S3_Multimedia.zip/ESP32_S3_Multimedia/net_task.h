#pragma once
// 網絡工作（行喺 core 0）：WiFi 自動連線 / 掃描 / 使用者連線、NTP、天文台、九巴
// 所有 WiFi 操作都喺呢度做，UI 只係透過 gNetCmd 發指令，咁 HTTPS 卡住都唔會令觸控冇反應。
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#if __has_include("secrets.h")
#include "secrets.h"
#endif

static volatile uint8_t gDiscReason = 0;

// ---------- 已儲存 WiFi（NVS / Preferences，namespace "wifi"）----------
static void savedLoad() {
  Preferences p;
  SavedNet tmp[MAX_SAVED_WIFI];
  uint8_t n = 0;
  if (p.begin("wifi", true)) {
    n = p.getUChar("n", 0);
    if (n > MAX_SAVED_WIFI) n = MAX_SAVED_WIFI;
    for (uint8_t i = 0; i < n; i++) {
      char k[4];
      snprintf(k, sizeof(k), "s%u", i);
      p.getString(k, tmp[i].ssid, sizeof(tmp[i].ssid));
      snprintf(k, sizeof(k), "p%u", i);
      p.getString(k, tmp[i].pass, sizeof(tmp[i].pass));
    }
    p.end();
  }
  STATE_LOCK();
  gNet.savedCount = n;
  memcpy(gNet.saved, tmp, sizeof(SavedNet) * n);
  STATE_UNLOCK();
}
static void savedStore() {
  STATE_LOCK();
  uint8_t n = gNet.savedCount;
  SavedNet tmp[MAX_SAVED_WIFI];
  memcpy(tmp, gNet.saved, sizeof(SavedNet) * n);
  STATE_UNLOCK();
  Preferences p;
  if (!p.begin("wifi", false)) return;
  p.clear();
  p.putUChar("n", n);
  for (uint8_t i = 0; i < n; i++) {
    char k[8];
    snprintf(k, sizeof(k), "s%u", i);
    p.putString(k, tmp[i].ssid);
    snprintf(k, sizeof(k), "p%u", i);
    p.putString(k, tmp[i].pass);
  }
  p.end();
}
// 連線成功 → 放去第一位（最近用過）；超過 5 個就踢走最舊嗰個
static void savedRemember(const char *ssid, const char *pass) {
  STATE_LOCK();
  SavedNet list[MAX_SAVED_WIFI];
  uint8_t n = 0;
  strncpy(list[0].ssid, ssid, 32);
  list[0].ssid[32] = 0;
  strncpy(list[0].pass, pass, 64);
  list[0].pass[64] = 0;
  n = 1;
  for (uint8_t i = 0; i < gNet.savedCount && n < MAX_SAVED_WIFI; i++)
    if (strcmp(gNet.saved[i].ssid, ssid) != 0) list[n++] = gNet.saved[i];
  memcpy(gNet.saved, list, sizeof(SavedNet) * n);
  gNet.savedCount = n;
  STATE_UNLOCK();
  savedStore();
}
static void savedForget(const char *ssid) {
  STATE_LOCK();
  uint8_t n = 0;
  for (uint8_t i = 0; i < gNet.savedCount; i++)
    if (strcmp(gNet.saved[i].ssid, ssid) != 0) gNet.saved[n++] = gNet.saved[i];
  gNet.savedCount = n;
  STATE_UNLOCK();
  savedStore();
}

// ---------- 掃描 ----------
static void doScan() {
  STATE_LOCK();
  gNet.scanState = 1;
  STATE_UNLOCK();
  bumpVer();
  int n = WiFi.scanNetworks(false, false);
  ScanItem items[SCAN_MAX];
  int cnt = 0;
  for (int i = 0; i < n; i++) {
    String s = WiFi.SSID(i);
    if (s.length() == 0) continue;  // 隱藏網絡用「手動加入」
    int8_t r = WiFi.RSSI(i);
    int dup = -1;
    for (int k = 0; k < cnt; k++)
      if (strcmp(items[k].ssid, s.c_str()) == 0) dup = k;
    if (dup >= 0) {
      if (r > items[dup].rssi) items[dup].rssi = r;
      continue;
    }
    if (cnt >= SCAN_MAX) continue;
    strncpy(items[cnt].ssid, s.c_str(), 32);
    items[cnt].ssid[32] = 0;
    items[cnt].rssi = r;
    items[cnt].secure = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
    cnt++;
  }
  WiFi.scanDelete();
  // 訊號強排先
  for (int a = 0; a < cnt; a++)
    for (int b = a + 1; b < cnt; b++)
      if (items[b].rssi > items[a].rssi) {
        ScanItem t = items[a];
        items[a] = items[b];
        items[b] = t;
      }
  STATE_LOCK();
  memcpy(gNet.scan, items, sizeof(ScanItem) * cnt);
  gNet.scanCount = cnt;
  gNet.scanState = 2;
  STATE_UNLOCK();
  bumpVer();
  Serial.printf("[WiFi] scan: %d networks\n", cnt);
}

// ---------- 連線 ----------
static bool doConnect(const char *ssid, const char *pass, uint32_t timeoutMs, char *why, size_t whyN) {
  WiFi.disconnect(false, false);
  vTaskDelay(pdMS_TO_TICKS(150));
  gDiscReason = 0;
  Serial.printf("[WiFi] connecting to %s\n", ssid);
  if (pass && pass[0]) WiFi.begin(ssid, pass);
  else WiFi.begin(ssid);
  uint32_t t0 = millis();
  int authFails = 0;
  uint8_t lastR = 0;
  if (why) snprintf(why, whyN, "連線逾時，請檢查訊號");
  while (millis() - t0 < timeoutMs) {
    wl_status_t s = WiFi.status();
    if (s == WL_CONNECTED) return true;
    uint8_t r = gDiscReason;
    if (r && r != lastR) {
      lastR = r;
      Serial.printf("[WiFi] disconnect reason %u\n", r);
    }
    if (r == WIFI_REASON_AUTH_FAIL || r == WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT || r == WIFI_REASON_HANDSHAKE_TIMEOUT) {
      if (++authFails >= 2) {
        if (why) snprintf(why, whyN, "密碼錯誤");
        break;
      }
      gDiscReason = 0;
    }
    if ((r == WIFI_REASON_NO_AP_FOUND || s == WL_NO_SSID_AVAIL) && millis() - t0 > 6000) {
      if (why) snprintf(why, whyN, "找不到這個網絡（只支援 2.4GHz）");
      break;
    }
    vTaskDelay(pdMS_TO_TICKS(200));
  }
  WiFi.disconnect(false, false);
  return false;
}

// ---------- HTTPS ----------
// 課堂用：setInsecure（唔驗證憑證）。暫態 TLS／DNS 失敗好常見 → 短重試 + backoff。
// 每次新建 client（唔長駐 reuse），避免 ESP32 殘留 TLS session 搞到之後全敗。
static bool httpsGetOnce(const char *url, String &body, uint32_t timeoutMs) {
  body = "";
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client;
  client.setInsecure();
  // 底層 socket 讀寫逾時（秒）；同 HTTPClient 逾時對齊，避免卡死 net task
  uint32_t sec = (timeoutMs + 999) / 1000;
  if (sec < 3) sec = 3;
  if (sec > 20) sec = 20;
  client.setTimeout(sec);
  HTTPClient https;
  https.setReuse(false);
  https.setTimeout(timeoutMs);
  uint32_t connMs = timeoutMs > 8000 ? 8000 : timeoutMs;
  https.setConnectTimeout(connMs);
  if (!https.begin(client, url)) {
    Serial.printf("[HTTP] begin fail %s\n", url);
    return false;
  }
  int code = https.GET();
  if (code != HTTP_CODE_OK) {
    Serial.printf("[HTTP] %d %s\n", code, url);
    https.end();
    return false;
  }
  body = https.getString();
  https.end();
  return body.length() > 0;
}

static bool httpsGet(const char *url, String &body, uint32_t timeoutMs = 10000) {
  body = "";
  const int maxTries = 3;
  for (int attempt = 0; attempt < maxTries; attempt++) {
    if (WiFi.status() != WL_CONNECTED) return false;
    if (attempt > 0) {
      uint32_t back = 250u * (uint32_t)attempt * (uint32_t)attempt;  // 250、1000ms
      Serial.printf("[HTTP] retry %d (+%ums) %s\n", attempt, (unsigned)back, url);
      vTaskDelay(pdMS_TO_TICKS(back));
      if (WiFi.status() != WL_CONNECTED) return false;
    }
    if (httpsGetOnce(url, body, timeoutMs)) return true;
  }
  return false;
}

// 兩次 HTTPS 之間讓出 CPU／釋放 TLS 緩衝，減低連續握手 OOM
static void httpsPause() {
  vTaskDelay(pdMS_TO_TICKS(80));
  yield();
}

// ---------- 天文台 ----------
static bool fetchWeatherNow() {
  String body;
  if (!httpsGet(HKO_RHR_URL, body)) return false;
  JsonDocument filter;
  filter["icon"] = true;
  filter["temperature"]["data"][0]["place"] = true;
  filter["temperature"]["data"][0]["value"] = true;
  filter["humidity"]["data"][0]["value"] = true;
  JsonDocument doc;
  if (deserializeJson(doc, body, DeserializationOption::Filter(filter))) return false;
  WeatherNow w = {true, 50, -999, -1, false};
  if (doc["icon"].is<JsonArray>() && doc["icon"].size() > 0) w.icon = doc["icon"][0] | 50;
  JsonArray t = doc["temperature"]["data"].as<JsonArray>();
  for (size_t p = 0; p < sizeof(WEATHER_STATIONS) / sizeof(WEATHER_STATIONS[0]) && w.tempC < -100; p++)
    for (JsonObject o : t)
      if (strcmp(o["place"] | "", WEATHER_STATIONS[p]) == 0) {
        w.tempC = o["value"] | -999;
        break;
      }
  if (w.tempC < -100 && !t.isNull() && t.size() > 0) w.tempC = t[0]["value"] | -999;
  JsonArray h = doc["humidity"]["data"].as<JsonArray>();
  if (!h.isNull() && h.size() > 0) w.humidity = h[0]["value"] | -1;
  if (w.tempC < -100) return false;
  STATE_LOCK();
  gWeather = w;
  STATE_UNLOCK();
  Serial.printf("[WX] icon=%d %dC %d%%\n", w.icon, w.tempC, w.humidity);
  return true;
}
// HKO fnd：串流讀取（唔用 httpsGet/getString），brace 掃描頭三日。
// 每隻日物件用字串 helper 解析（唔經 ArduinoJson），避免長中文 NoMemory／heap 不足 → UI「--」。
// 字串 helper：喺 [s,e) 搵 key／解析冒號後整數或字串
static const char *fndFindKey(const char *s, const char *e, const char *key) {
  size_t klen = strlen(key);
  for (const char *p = s; p + klen <= e; p++)
    if (memcmp(p, key, klen) == 0) return p;
  return nullptr;
}
static bool fndParseIntAfterColon(const char *p, const char *e, int *out) {
  const char *c = (const char *)memchr(p, ':', (size_t)(e - p));
  if (!c || c >= e) return false;
  c++;
  while (c < e && (*c == ' ' || *c == '\t')) c++;
  if (c >= e || !((*c >= '0' && *c <= '9') || *c == '-')) return false;
  *out = atoi(c);
  return true;
}
static bool fndParseStrAfterColon(const char *p, const char *e, char *dst, size_t n) {
  const char *c = (const char *)memchr(p, ':', (size_t)(e - p));
  if (!c || c >= e) return false;
  c++;
  while (c < e && (*c == ' ' || *c == '\t')) c++;
  if (c >= e || *c != '"') return false;
  c++;
  const char *q = (const char *)memchr(c, '"', (size_t)(e - c));
  if (!q) return false;
  size_t L = (size_t)(q - c);
  if (L >= n) L = n - 1;
  memcpy(dst, c, L);
  dst[L] = 0;
  return true;
}
static bool fndNestIntValue(const char *s, const char *e, const char *parent, int *out) {
  const char *p = fndFindKey(s, e, parent);
  if (!p) return false;
  const char *v = fndFindKey(p, e, "\"value\"");
  if (!v || v > p + 64) return false;
  return fndParseIntAfterColon(v, e, out);
}
// 由單一「日」JSON 物件緩衝（含頭尾 {}）抽出 ForecastDay；成功回 true
static bool parseFndDayObject(const char *buf, int len, ForecastDay *out, int idx) {
  if (!buf || len < 8 || !out) return false;
  const char *s = buf;
  const char *e = buf + len;
  char fd[16] = {0}, week[16] = {0};
  int icon = -1, maxC = 0, minC = 0;
  const char *fdKey = fndFindKey(s, e, "\"forecastDate\"");
  if (fdKey) fndParseStrAfterColon(fdKey, e, fd, sizeof(fd));
  const char *wk = fndFindKey(s, e, "\"week\"");
  if (wk) fndParseStrAfterColon(wk, e, week, sizeof(week));
  const char *ik = fndFindKey(s, e, "\"ForecastIcon\"");
  if (ik) fndParseIntAfterColon(ik, e, &icon);
  fndNestIntValue(s, e, "\"forecastMaxtemp\"", &maxC);
  fndNestIntValue(s, e, "\"forecastMintemp\"", &minC);
  if (icon < 0 && !week[0]) return false;
  memset(out, 0, sizeof(*out));
  out->valid = true;
  out->icon = icon >= 0 ? icon : 50;
  out->maxC = maxC;
  out->minC = minC;
  utf8Copy(out->week, sizeof(out->week), week);
  Serial.printf("[WX] fnd[%d] %s %s %d-%dC icon=%d\n", idx, fd, out->week, out->minC, out->maxC,
                out->icon);
  return true;
}

class HkoFndScan {
 public:
  ForecastDay days[3];
  int n = 0;
  size_t got = 0;
  void reset() {
    memset(days, 0, sizeof(days));
    n = 0;
    got = 0;
    len = depth = 0;
    inStr = esc = skip = false;
  }
  void feed(char c) {
    if (n >= 3) return;
    bool endObj = false;
    if (inStr) {
      if (esc) esc = false;
      else if (c == '\\') esc = true;
      else if (c == '"') inStr = false;
    } else if (c == '"') {
      inStr = true;
    } else if (c == '{' || c == '[') {
      depth++;
      if (c == '{' && depth == 3) {  // {"weatherForecast":[ {這裏} ]}
        len = 0;
        skip = false;
      }
    } else if (c == '}' || c == ']') {
      if (c == '}' && depth == 3) endObj = true;
      depth--;
    }
    if (depth >= 3 || endObj) {
      if (len < (int)sizeof(buf) - 1) buf[len++] = c;
      else skip = true;
    }
    if (endObj) {
      buf[len] = 0;
      if (skip)
        Serial.printf("[WX] fnd obj 過長略過（len>=%d）\n", (int)sizeof(buf));
      else
        check();
      len = 0;
    }
  }
  void feedBody(const char *s, size_t nbytes) {
    got += nbytes;
    for (size_t i = 0; i < nbytes && n < 3; i++) feed(s[i]);
  }

 private:
  char buf[1024];  // 日物件通常 ~330–460B；長中文預留
  int len = 0, depth = 0;
  bool inStr = false, esc = false, skip = false;
  void check() {
    if (n >= 3) return;
    if (parseFndDayObject(buf, len, &days[n], n)) n++;
  }
};

static bool fetchForecast() {
  if (WiFi.status() != WL_CONNECTED) return false;
  static HkoFndScan sink;  // buf 唔放 stack

  for (int attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) {
      Serial.printf("[WX] fnd retry %d\n", attempt);
      vTaskDelay(pdMS_TO_TICKS(300u * (uint32_t)attempt));
      if (WiFi.status() != WL_CONNECTED) return false;
    }

    // 每次重試新建 TLS client，避免上次失敗殘留
    WiFiClientSecure client;
    client.setInsecure();
    client.setTimeout(15);
    HTTPClient https;
    https.setReuse(false);
    https.setTimeout(15000);
    https.setConnectTimeout(8000);
    if (!https.begin(client, HKO_FND_URL)) {
      Serial.println("[WX] fnd: begin fail");
      continue;
    }
    int code = https.GET();
    Serial.printf("[WX] fnd HTTP %d\n", code);
    if (code != HTTP_CODE_OK) {
      https.end();
      continue;
    }
    WiFiClient *stream = https.getStreamPtr();
    if (!stream) {
      Serial.println("[WX] fnd: no stream");
      https.end();
      continue;
    }

    sink.reset();
    uint8_t chunk[512];
    size_t total = 0;
    const uint32_t t0 = millis();
    const uint32_t budgetMs = 15000;
    const int contentLen = https.getSize();  // -1 if unknown

    // 1) 讀到攞齊三日（或 timeout／斷線）
    while (sink.n < 3 && (millis() - t0) < budgetMs) {
      int avail = stream->available();
      if (avail <= 0) {
        if (!https.connected() && !stream->available()) break;
        delay(2);
        continue;
      }
      size_t toRead = (size_t)avail;
      if (toRead > sizeof(chunk)) toRead = sizeof(chunk);
      int rd = stream->readBytes((char *)chunk, toRead);
      if (rd <= 0) break;
      total += (size_t)rd;
      sink.feedBody((const char *)chunk, (size_t)rd);
    }

    // 2) drain 剩餘 body，確保連線乾淨關閉（唔再餵 scanner）
    uint32_t idleMs = 0;
    while ((millis() - t0) < budgetMs) {
      if (contentLen > 0 && (int)total >= contentLen) break;
      int avail = stream->available();
      if (avail <= 0) {
        if (!https.connected() && !stream->available()) break;
        delay(2);
        idleMs += 2;
        if (idleMs >= 400) break;  // 冇新資料一陣就當完
        continue;
      }
      idleMs = 0;
      size_t toRead = (size_t)avail;
      if (toRead > sizeof(chunk)) toRead = sizeof(chunk);
      int rd = stream->readBytes((char *)chunk, toRead);
      if (rd <= 0) break;
      total += (size_t)rd;
    }
    https.end();

    Serial.printf("[WX] fnd bytes=%u days=%d\n", (unsigned)total, sink.n);

    if (sink.n <= 0) {
      Serial.printf("[WX] fnd fail: 0 days（bytes=%u HTTP was %d）\n", (unsigned)total, code);
      continue;  // 再試
    }

    STATE_LOCK();
    memcpy(gForecast, sink.days, sizeof(sink.days));
    if (sink.n < 3) memset(gForecast + sink.n, 0, sizeof(ForecastDay) * (size_t)(3 - sink.n));
    STATE_UNLOCK();
    Serial.printf("[WX] fnd ok: %d days\n", sink.n);
    return true;
  }
  return false;
}

// 將 warnsum 嘅 code／type 正規化成圖符鍵（WFIREY／WFIRER／WRAINA…）
static void normalizeWarnCode(char *code, size_t cap, const char *typ) {
  if (!code || !code[0]) return;
  auto has = [&](const char *needle) -> bool {
    return typ && typ[0] && strstr(typ, needle) != nullptr;
  };
  // 火災：property 名可能係 WFIRE，真正顏色喺 code 或 type
  if (strcmp(code, "WFIRE") == 0) {
    if (has("Yellow") || has("YELLOW") || has("黃"))
      snprintf(code, cap, "WFIREY");
    else if (has("Red") || has("RED") || has("紅"))
      snprintf(code, cap, "WFIRER");
  }
  // 暴雨：可能得 WRAIN，顏色喺 type
  if (strcmp(code, "WRAIN") == 0) {
    if (has("Black") || has("BLACK") || has("黑"))
      snprintf(code, cap, "WRAINB");
    else if (has("Red") || has("RED") || has("紅"))
      snprintf(code, cap, "WRAINR");
    else if (has("Amber") || has("AMBER") || has("Yellow") || has("黃"))
      snprintf(code, cap, "WRAINA");
  }
  // 熱帶氣旋：property 名 WTCSGNL，code 應該已係 TC*；若只有 type 字串就試解析
  if (strcmp(code, "WTCSGNL") == 0 && typ && typ[0]) {
    if (strstr(typ, "10") || strstr(typ, "Hurricane") || strstr(typ, "颶風"))
      snprintf(code, cap, "TC10");
    else if (strstr(typ, "No. 9") || strstr(typ, "No.9") || strstr(typ, "九"))
      snprintf(code, cap, "TC9");
    else if (strstr(typ, "No. 8") || strstr(typ, "No.8") || strstr(typ, "八")) {
      if (strstr(typ, "Northeast") || strstr(typ, "東北") || strstr(typ, "NE"))
        snprintf(code, cap, "TC8NE");
      else if (strstr(typ, "Northwest") || strstr(typ, "西北") || strstr(typ, "NW"))
        snprintf(code, cap, "TC8NW");
      else if (strstr(typ, "Southeast") || strstr(typ, "東南") || strstr(typ, "SE"))
        snprintf(code, cap, "TC8SE");
      else if (strstr(typ, "Southwest") || strstr(typ, "西南") || strstr(typ, "SW"))
        snprintf(code, cap, "TC8SW");
      else
        snprintf(code, cap, "TC8NE");  // 方向未知時用 NE 作後備鍵
    } else if (strstr(typ, "No. 3") || strstr(typ, "No.3") || strstr(typ, "三") || strstr(typ, "Strong Wind"))
      snprintf(code, cap, "TC3");
    else if (strstr(typ, "No. 1") || strstr(typ, "No.1") || strstr(typ, "一") || strstr(typ, "Standby"))
      snprintf(code, cap, "TC1");
  }
}

static bool warnHasCode(const WxWarnSum &w, const char *code) {
  for (uint8_t i = 0; i < w.n; i++)
    if (strcmp(w.items[i].code, code) == 0) return true;
  return false;
}

static bool warnHasFire(const WxWarnSum &w) {
  for (uint8_t i = 0; i < w.n; i++)
    if (strncmp(w.items[i].code, "WFIRE", 5) == 0) return true;
  return false;
}

static bool fetchWarnsum() {
  String body;
  if (!httpsGet(HKO_WARNSUM_URL, body)) return false;
  JsonDocument doc;
  if (deserializeJson(doc, body)) return false;
  JsonObject root = doc.as<JsonObject>();
  if (root.isNull()) return false;
  WxWarnSum w = {};
  w.valid = true;
  for (JsonPair kv : root) {
    if (w.n >= WX_WARN_MAX) break;
    JsonObject o = kv.value().as<JsonObject>();
    if (o.isNull()) continue;
    const char *action = o["actionCode"] | "";
    if (strcmp(action, "CANCEL") == 0) continue;
    const char *code = o["code"] | "";
    if (!code[0]) code = kv.key().c_str();
    const char *name = o["name"] | "";
    const char *typ = o["type"] | "";
    char buf[12];
    utf8Copy(buf, sizeof(buf), code);
    normalizeWarnCode(buf, sizeof(buf), typ);
    if (warnHasCode(w, buf)) continue;  // 避免重複
    utf8Copy(w.items[w.n].code, sizeof(w.items[w.n].code), buf);
    utf8Copy(w.items[w.n].name, sizeof(w.items[w.n].name), name);
    Serial.printf("[WX] warn[%u]=%s\n", w.n, w.items[w.n].code);
    w.n++;
  }
  STATE_LOCK();
  gWxWarn = w;
  STATE_UNLOCK();
  Serial.printf("[WX] warnsum n=%u\n", w.n);
  return true;
}

// 後備：本港天氣報告 flw 嘅 fireDangerWarning（warnsum 空／漏咗火災時補上）
// 唔會假造「永遠黃色」——只喺字串真係寫咗黃／紅先加。
static void mergeFlwFireDanger() {
  String body;
  if (!httpsGet(HKO_FLW_URL, body)) {
    Serial.println("[WX] flw: fetch fail（火災後備略過）");
    return;
  }
  JsonDocument doc;
  if (deserializeJson(doc, body)) {
    Serial.println("[WX] flw: json fail");
    return;
  }
  const char *fd = doc["fireDangerWarning"] | "";
  if (!fd[0]) {
    Serial.println("[WX] flw: fireDangerWarning 空");
    return;
  }
  const char *add = nullptr;
  if (strstr(fd, "黃") || strstr(fd, "Yellow") || strstr(fd, "yellow") || strstr(fd, "YELLOW"))
    add = "WFIREY";
  else if (strstr(fd, "紅") || strstr(fd, "Red") || strstr(fd, "red") || strstr(fd, "RED"))
    add = "WFIRER";
  if (!add) {
    Serial.printf("[WX] flw: fireDanger 有字但唔識色：「%.40s」\n", fd);
    return;
  }
  STATE_LOCK();
  WxWarnSum w = gWxWarn;
  STATE_UNLOCK();
  if (warnHasFire(w)) {
    Serial.printf("[WX] flw: 已有火災警告，略過後備 %s\n", add);
    return;
  }
  if (w.n >= WX_WARN_MAX) {
    Serial.println("[WX] flw: warn 已滿，略過火災後備");
    return;
  }
  w.valid = true;
  w.failed = false;
  utf8Copy(w.items[w.n].code, sizeof(w.items[w.n].code), add);
  utf8Copy(w.items[w.n].name, sizeof(w.items[w.n].name),
           strcmp(add, "WFIREY") == 0 ? "黃色火災危險警告" : "紅色火災危險警告");
  Serial.printf("[WX] warn[%u]=%s (flw backup)\n", w.n, add);
  w.n++;
  STATE_LOCK();
  gWxWarn = w;
  STATE_UNLOCK();
}

// ---------- 鬧鐘 NVS（namespace "alarm"）----------
static void alarmLoad() {
  Preferences p;
  if (!p.begin("alarm", true)) return;
  STATE_LOCK();
  gTmr.almOn = p.getBool("on", false);
  gTmr.almH = p.getUChar("h", 7);
  gTmr.almM = p.getUChar("m", 0);
  String lb = p.getString("lb", "鬧鐘");
  utf8Copy(gTmr.almLabel, sizeof(gTmr.almLabel), lb.c_str());
  if (gTmr.almH > 23) gTmr.almH = 7;
  if (gTmr.almM > 59) gTmr.almM = 0;
  gTmr.almLastYday = -1;
  STATE_UNLOCK();
  p.end();
  Serial.printf("[ALM] %s %02u:%02u\n", gTmr.almOn ? "ON" : "OFF", gTmr.almH, gTmr.almM);
}
static void alarmSave() {
  TimerRT t;
  STATE_LOCK();
  t = gTmr;
  STATE_UNLOCK();
  Preferences p;
  if (!p.begin("alarm", false)) return;
  p.putBool("on", t.almOn);
  p.putUChar("h", t.almH);
  p.putUChar("m", t.almM);
  p.putString("lb", t.almLabel);
  p.end();
}

// ---------- 九巴 ----------
static bool parseIso(const char *s, time_t *out) {
  int y, mo, d, h, mi, se;
  if (!s || sscanf(s, "%d-%d-%dT%d:%d:%d", &y, &mo, &d, &h, &mi, &se) != 6) return false;
  struct tm t = {};
  t.tm_year = y - 1900;
  t.tm_mon = mo - 1;
  t.tm_mday = d;
  t.tm_hour = h;
  t.tm_min = mi;
  t.tm_sec = se;
  t.tm_isdst = 0;
  *out = mktime(&t);  // TZ 已設為 HKT-8，API 時間都係 +08:00
  return *out != (time_t)-1;
}
static bool fetchBus(int i) {
  STATE_LOCK();
  BusSlot c = gBusCfg[i];
  STATE_UNLOCK();
  if (!c.used) {
    STATE_LOCK();
    gBus[i].failed = false;  // 未設定格唔好令「三格全失敗」誤判
    STATE_UNLOCK();
    return true;
  }
  char url[128];
  snprintf(url, sizeof(url), KMB_API "/eta/%s/%s/%u", c.stopId, c.route, c.serviceType ? c.serviceType : 1);
  String body;
  if (!httpsGet(url, body)) return false;
  // 唔用 Filter：ArduinoJson 7 對 data[0] filter 喺實機可能令陣列變空（同三日預報一樣）
  JsonDocument doc;
  if (deserializeJson(doc, body)) return false;
  JsonArray arr = doc["data"].as<JsonArray>();
  time_t now = time(nullptr);
  bool synced = gNet.timeSynced;
  struct E { time_t t; int es; bool sched; } list[8];
  int n = 0, baseSeq = -1;
  char baseDir[4] = "";
  for (JsonObject o : arr) {
    const char *eta = o["eta"] | "";  // null（冇班次）→ ""
    int seq = o["seq"] | 0;
    const char *dir = o["dir"] | "";
    if (c.dir && dir[0] && dir[0] != c.dir) continue;  // 只要設定咗嘅方向
    if (baseSeq < 0) {  // 同一個站可能出現兩次（循環線）→ 只用第一組 seq/dir
      baseSeq = seq;
      strncpy(baseDir, dir, 3);
    } else if (seq != baseSeq || strcmp(dir, baseDir) != 0) continue;
    time_t t;
    if (!eta[0] || !parseIso(eta, &t)) continue;
    if (synced && t < now - 30) continue;  // 已開出
    if (n >= 8) break;
    list[n].t = t;
    list[n].es = o["eta_seq"] | (n + 1);
    list[n].sched = strstr(o["rmk_tc"] | "", "原定") != nullptr;
    n++;
  }
  // 按 eta_seq 排（API 通常已排好）
  for (int a = 0; a < n; a++)
    for (int b = a + 1; b < n; b++)
      if (list[b].es < list[a].es) {
        E t = list[a];
        list[a] = list[b];
        list[b] = t;
      }
  STATE_LOCK();
  bool same = gBusCfg[i].used && strcmp(gBusCfg[i].route, c.route) == 0 && strcmp(gBusCfg[i].stopId, c.stopId) == 0;
  if (same) {  // 拎資料期間使用者改咗設定 → 呢份資料作廢
    gBus[i].valid = true;
    gBus[i].failed = false;
    gBus[i].n = n > BUS_MAX_ETA ? BUS_MAX_ETA : n;
    for (int k = 0; k < gBus[i].n; k++) {
      gBus[i].eta[k] = list[k].t;
      gBus[i].sched[k] = list[k].sched;
    }
  }
  STATE_UNLOCK();
  Serial.printf("[BUS] %s @%s: %d upcoming\n", c.route, c.code[0] ? c.code : c.stopId, n);
  return true;
}

// ---------- 巴士站設定：儲存（NVS namespace "bus"）----------
#define BUS_NVS_VER 1
static void busCfgDefaults() {
  STATE_LOCK();
  for (int i = 0; i < BUS_MAX_SLOTS; i++) busSlotFromDefault(gBusCfg[i], BUS_DEFAULTS[i]);
  STATE_UNLOCK();
}
// 開機讀設定；冇儲存過就用預設路線
static void busCfgLoad() {
  Preferences p;
  bool ok = false;
  BusSlot tmp[BUS_MAX_SLOTS];
  memset(tmp, 0, sizeof(tmp));
  if (p.begin("bus", true)) {
    if (p.getUChar("ver", 0) == BUS_NVS_VER) {
      ok = true;
      for (int i = 0; i < BUS_MAX_SLOTS; i++) {
        char k[4];
        snprintf(k, sizeof(k), "s%d", i);
        if (p.getBytesLength(k) == sizeof(BusSlot)) p.getBytes(k, &tmp[i], sizeof(BusSlot));
        tmp[i].route[sizeof(tmp[i].route) - 1] = 0;  // 防止壞資料
        tmp[i].stopId[16] = 0;
        tmp[i].code[sizeof(tmp[i].code) - 1] = 0;
        tmp[i].stopName[sizeof(tmp[i].stopName) - 1] = 0;
        tmp[i].dest[sizeof(tmp[i].dest) - 1] = 0;
        if (tmp[i].used && (!tmp[i].route[0] || strlen(tmp[i].stopId) != 16)) tmp[i].used = false;
      }
    }
    p.end();
  }
  if (!ok) {
    busCfgDefaults();
    Serial.println("[BUS] 未有巴士站設定，用預設路線");
  } else {
    STATE_LOCK();
    memcpy(gBusCfg, tmp, sizeof(tmp));
    STATE_UNLOCK();
    Serial.println("[BUS] 已讀取巴士站設定");
  }
  for (int i = 0; i < BUS_MAX_SLOTS; i++)
    if (gBusCfg[i].used)
      Serial.printf("[BUS] 第 %d 格：%s 往%s @%s %s（%s）\n", i + 1, gBusCfg[i].route, gBusCfg[i].dest, gBusCfg[i].stopName,
                    gBusCfg[i].code, gBusCfg[i].stopId);
}
static void busCfgSave() {
  BusSlot tmp[BUS_MAX_SLOTS];
  STATE_LOCK();
  memcpy(tmp, gBusCfg, sizeof(tmp));
  STATE_UNLOCK();
  Preferences p;
  if (!p.begin("bus", false)) return;
  for (int i = 0; i < BUS_MAX_SLOTS; i++) {
    char k[4];
    snprintf(k, sizeof(k), "s%d", i);
    p.putBytes(k, &tmp[i], sizeof(BusSlot));
  }
  p.putUChar("ver", BUS_NVS_VER);
  p.end();
}
// 改設定（UI 叫）：清走嗰格舊嘅到站資料，叫網絡工作即刻重新攞
static void busCfgChanged(int slot) {
  STATE_LOCK();
  if (slot < 0) {
    memset(gBus, 0, sizeof(gBus));
  } else {
    memset(&gBus[slot], 0, sizeof(BusInfo));
  }
  STATE_UNLOCK();
  busCfgSave();
  gBusCfgVer = gBusCfgVer + 1;
  gBusForce = true;
  bumpVer();
}
static void busCfgSet(int slot, const BusSlot &s) {
  STATE_LOCK();
  gBusCfg[slot] = s;
  gBusCfg[slot].used = true;
  STATE_UNLOCK();
  busCfgChanged(slot);
}
static void busCfgDelete(int slot) {
  STATE_LOCK();
  memset(&gBusCfg[slot], 0, sizeof(BusSlot));
  STATE_UNLOCK();
  busCfgChanged(slot);
}
static void busCfgReset() {
  busCfgDefaults();
  busCfgChanged(-1);
}

// ---------- 巴士站設定：搵站 / 路線 ----------
#include "kmb_stops.h"
static void bsProgress(const char *fmt, int v = -1) {
  STATE_LOCK();
  snprintf(gBusS.progress, sizeof(gBusS.progress), fmt, v);
  STATE_UNLOCK();
  bumpVer();
}
static void bsFinish(uint8_t st, const char *msg = "") {
  STATE_LOCK();
  gBusS.st = st;
  snprintf(gBusS.msg, sizeof(gBusS.msg), "%s", msg);
  STATE_UNLOCK();
  bumpVer();
}
static void hex8(const uint8_t *b, char *out) {
  static const char H[] = "0123456789ABCDEF";
  for (int i = 0; i < 8; i++) {
    out[i * 2] = H[b[i] >> 4];
    out[i * 2 + 1] = H[b[i] & 15];
  }
  out[16] = 0;
}
// 1) 內置表：站牌號碼 → 站 ID（可能多過一個）。回傳搵到幾多個
static int kmbTableLookup(const char *code, BusStopCand *out, int maxN) {
  uint32_t key = ((uint32_t)((code[0] - 'A') * 26 + (code[1] - 'A')) << 13) |
                 ((uint32_t)((code[2] - '0') * 100 + (code[3] - '0') * 10 + (code[4] - '0')) << 3) |
                 (code[5] ? (uint32_t)(code[5] - 'a' + 1) : 0);
  int lo = 0, hi = KMB_STOP_N;
  while (lo < hi) {  // lower_bound
    int mid = (lo + hi) / 2;
    if (pgm_read_dword(&KMB_STOP_KEY[mid]) < key) lo = mid + 1;
    else hi = mid;
  }
  int n = 0;
  for (int i = lo; i < KMB_STOP_N && n < maxN && pgm_read_dword(&KMB_STOP_KEY[i]) == key; i++) {
    uint8_t b[8];
    memcpy_P(b, KMB_STOP_ID[i], 8);
    memset(&out[n], 0, sizeof(BusStopCand));
    hex8(b, out[n].id);
    utf8Copy(out[n].code, sizeof(out[n].code), code);
    n++;
  }
  return n;
}
// 2) 用站 ID 攞站名（亦順便確認呢個 ID 仲存在）。1 = 有，0 = 冇呢個站，-1 = 網絡錯誤
static int kmbStopName(BusStopCand &c) {
  char url[96];
  snprintf(url, sizeof(url), KMB_API "/stop/%s", c.id);
  String body;
  if (!httpsGet(url, body)) {
    Serial.printf("[BUS] stop/%s: HTTPS failed\n", c.id);
    return -1;
  }
  // 唔用 Filter：站 JSON 好細；Filter 喺實機可能令 name_tc 變空 → 誤判「冇呢個站」
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, body);
  if (err) {
    Serial.printf("[BUS] stop/%s: JSON err %s (%u bytes)\n", c.id, err.c_str(), (unsigned)body.length());
    return -1;
  }
  const char *tc = doc["data"]["name_tc"] | "";
  if (!tc[0]) {
    Serial.printf("[BUS] stop/%s: no name_tc (%u bytes)\n", c.id, (unsigned)body.length());
    return 0;
  }
  char code[8];
  busSplitName(tc, c.name, sizeof(c.name), code, sizeof(code));
  if (code[0]) utf8Copy(c.code, sizeof(c.code), code);
  return 1;
}
// 3) 後備：一路下載九巴全部站點（約 1.2MB），一路逐個站比對，唔使將成個檔放入記憶體
class KmbStopScan : public Stream {
 public:
  bool byCode = true;   // true = 比對站牌號碼；false = 英文站名包含關鍵字
  const char *q = "";
  BusStopCand *out = nullptr;
  int maxN = 0, n = 0;
  size_t total = 0, got = 0, lastPub = 0;
  size_t write(uint8_t c) override { feed((char)c); return 1; }
  size_t write(const uint8_t *b, size_t len) override {
    if (byCode && n >= 2) return 0;  // 號碼最多兩個站 ID，搵到就停（會令下載提早結束）
    for (size_t i = 0; i < len; i++) feed((char)b[i]);
    got += len;
    if (got - lastPub > 48 * 1024) {
      lastPub = got;
      if (total) bsProgress("下載九巴站點資料 %d%%", (int)(got * 100 / total));
      else bsProgress("下載九巴站點資料 %dKB", (int)(got / 1024));
    }
    return len;
  }
  void reset() {
    byCode = true;
    q = "";
    out = nullptr;
    maxN = n = 0;
    total = got = lastPub = 0;
    len = depth = 0;
    inStr = esc = skip = false;
  }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}

 private:
  char buf[448];
  int len = 0, depth = 0;
  bool inStr = false, esc = false, skip = false;
  void feed(char c) {
    bool endObj = false;
    if (inStr) {
      if (esc) esc = false;
      else if (c == '\\') esc = true;
      else if (c == '"') inStr = false;
    } else if (c == '"') {
      inStr = true;
    } else if (c == '{' || c == '[') {
      depth++;
      if (c == '{' && depth == 3) {  // {"data":[ {這裏} ]}
        len = 0;
        skip = false;
      }
    } else if (c == '}' || c == ']') {
      if (c == '}' && depth == 3) endObj = true;
      depth--;
    }
    if (depth >= 3 || endObj) {
      if (len < (int)sizeof(buf) - 1) buf[len++] = c;
      else skip = true;
    }
    if (endObj) {
      buf[len] = 0;
      if (!skip) check();
      len = 0;
    }
  }
  void check() {
    if (n >= maxN) return;
    JsonDocument doc;
    if (deserializeJson(doc, buf, len)) return;
    const char *id = doc["stop"] | "";
    const char *en = doc["name_en"] | "";
    const char *tc = doc["name_tc"] | "";
    if (strlen(id) != 16) return;
    bool hit = false;
    if (byCode) {
      char pat[12];
      snprintf(pat, sizeof(pat), "(%s)", q);
      size_t pl = strlen(pat), le = strlen(en), lt = strlen(tc);
      hit = (le >= pl && strcmp(en + le - pl, pat) == 0) || (lt >= pl && strcmp(tc + lt - pl, pat) == 0);
    } else {
      char up[96];
      size_t k = 0;
      for (; en[k] && k < sizeof(up) - 1; k++) up[k] = (en[k] >= 'a' && en[k] <= 'z') ? en[k] - 32 : en[k];
      up[k] = 0;
      hit = strstr(up, q) != nullptr;
    }
    if (!hit) return;
    BusStopCand &c = out[n++];
    memset(&c, 0, sizeof(c));
    utf8Copy(c.id, sizeof(c.id), id);
    busSplitName(tc, c.name, sizeof(c.name), c.code, sizeof(c.code));
  }
};
static int kmbScanStops(bool byCode, const char *q, BusStopCand *out, int maxN, bool *netOk) {
  static KmbStopScan sink;  // buf 唔放 stack
  sink.reset();
  sink.byCode = byCode;
  sink.q = q;
  sink.out = out;
  sink.maxN = maxN;
  *netOk = false;
  bsProgress("下載九巴站點資料…");
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient https;
  https.setTimeout(15000);
  https.setConnectTimeout(15000);
  if (!https.begin(client, KMB_API "/stop")) return 0;
  int code = https.GET();
  if (code == HTTP_CODE_OK) {
    sink.total = https.getSize() > 0 ? (size_t)https.getSize() : 0;
    int r = https.writeToStream(&sink);
    *netOk = (r >= 0) || sink.n > 0;
    Serial.printf("[BUS] 站點清單：讀咗 %u bytes，搵到 %d 個（r=%d）\n", (unsigned)sink.got, sink.n, r);
  } else {
    Serial.printf("[HTTP] %d stop list\n", code);
  }
  https.end();
  return sink.n;
}
// 4) stop-eta 串流掃描（物件約 <400B）：唔用成份 JsonDocument，亦唔下載 /route-stop（~3MB，會 OOM／restart）
// 欄位：route / dir / dest_tc / service_type
class KmbStopEtaScan : public Stream {
 public:
  BusRouteOpt *out = nullptr;
  int maxN = 0, n = 0, stopIdx = 0;
  size_t got = 0;
  size_t write(uint8_t c) override { feed((char)c); return 1; }
  size_t write(const uint8_t *b, size_t len) override {
    for (size_t i = 0; i < len; i++) feed((char)b[i]);
    got += len;
    return len;
  }
  void reset(BusRouteOpt *o, int maxRoutes, int startN, int si) {
    out = o;
    maxN = maxRoutes;
    n = startN;
    stopIdx = si;
    got = 0;
    len = depth = 0;
    inStr = esc = skip = false;
  }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}

 private:
  char buf[448];
  int len = 0, depth = 0;
  bool inStr = false, esc = false, skip = false;
  void feed(char c) {
    bool endObj = false;
    if (inStr) {
      if (esc) esc = false;
      else if (c == '\\') esc = true;
      else if (c == '"') inStr = false;
    } else if (c == '"') {
      inStr = true;
    } else if (c == '{' || c == '[') {
      depth++;
      if (c == '{' && depth == 3) {  // {"data":[ {這裏} ]}
        len = 0;
        skip = false;
      }
    } else if (c == '}' || c == ']') {
      if (c == '}' && depth == 3) endObj = true;
      depth--;
    }
    if (depth >= 3 || endObj) {
      if (len < (int)sizeof(buf) - 1) buf[len++] = c;
      else skip = true;
    }
    if (endObj) {
      buf[len] = 0;
      if (!skip) check();
      len = 0;
    }
  }
  void check() {
    JsonDocument doc;
    if (deserializeJson(doc, buf, len)) return;
    const char *r = doc["route"] | "";
    const char *d = doc["dir"] | "";
    const char *dest = doc["dest_tc"] | "";
    int st = doc["service_type"].as<int>();
    if (st <= 0) st = 1;
    if (!r[0] || strlen(r) > 5) return;
    if (d[0] != 'I' && d[0] != 'O') return;
    // 同一路線、同方向、同目的地只要一個（揀 service_type 最細）
    int dup = -1;
    for (int k = 0; k < n; k++)
      if (strcmp(out[k].route, r) == 0 && out[k].dir == d[0] &&
          strncmp(out[k].dest, dest, sizeof(out[k].dest) - 1) == 0)
        dup = k;
    if (dup >= 0) {
      if (st < out[dup].serviceType) {
        out[dup].serviceType = (uint8_t)st;
        out[dup].stop = (uint8_t)stopIdx;
      }
      return;
    }
    if (n >= maxN) return;
    BusRouteOpt &x = out[n++];
    memset(&x, 0, sizeof(x));
    utf8Copy(x.route, sizeof(x.route), r);
    x.dir = d[0];
    x.serviceType = (uint8_t)st;
    x.stop = (uint8_t)stopIdx;
    utf8Copy(x.dest, sizeof(x.dest), dest);
  }
};
// 路線排序：數字部分先，再比較字母（例如 68X < 276 < 276P < B9 < N276）
static int routeCmp(const char *a, const char *b) {
  auto lead = [](const char *s) { return (*s >= 'A' && *s <= 'Z') ? 1 : 0; };
  int la = lead(a), lb = lead(b);
  if (la != lb) return la - lb;
  const char *pa = a, *pb = b;
  while (*pa >= 'A' && *pa <= 'Z') pa++;
  while (*pb >= 'A' && *pb <= 'Z') pb++;
  int na = atoi(pa), nb = atoi(pb);
  if (na != nb) return na - nb;
  return strcmp(a, b);
}
// 細 PROGMEM 種子：config.h BUS_DEFAULTS（YL395／YL392）；stop-eta 成功但 0 條時補上
static void kmbMergeSeedRoutes(const BusStopCand *stops, int nStops, BusRouteOpt *out, int *nInOut) {
  int n = *nInOut;
  for (int d = 0; d < BUS_MAX_SLOTS; d++) {
    const BusDefault &bd = BUS_DEFAULTS[d];
    int si = -1;
    for (int s = 0; s < nStops; s++) {
      if (strcmp(stops[s].id, bd.stopId) == 0) {
        si = s;
        break;
      }
      if (stops[s].code[0] && strcasecmp(stops[s].code, bd.code) == 0) {
        si = s;
        break;
      }
    }
    if (si < 0) continue;
    int dup = -1;
    for (int k = 0; k < n; k++)
      if (strcmp(out[k].route, bd.route) == 0 && out[k].dir == bd.dir &&
          strncmp(out[k].dest, bd.dest, sizeof(out[k].dest) - 1) == 0)
        dup = k;
    if (dup >= 0) {
      if (bd.serviceType < out[dup].serviceType) {
        out[dup].serviceType = bd.serviceType;
        out[dup].stop = (uint8_t)si;
      }
      continue;
    }
    if (n >= BS_MAX_ROUTES) break;
    BusRouteOpt &x = out[n++];
    memset(&x, 0, sizeof(x));
    utf8Copy(x.route, sizeof(x.route), bd.route);
    x.dir = bd.dir;
    x.serviceType = bd.serviceType;
    x.stop = (uint8_t)si;
    utf8Copy(x.dest, sizeof(x.dest), bd.dest);
  }
  if (n > *nInOut) Serial.printf("[BUS] seed：補咗 %d 條預設路線\n", n - *nInOut);
  *nInOut = n;
}
// 用站名種子填空名（網絡查站名失敗時）
static void kmbFillNameFromSeed(BusStopCand &c) {
  if (c.name[0]) return;
  for (int d = 0; d < BUS_MAX_SLOTS; d++) {
    if (strcmp(c.id, BUS_DEFAULTS[d].stopId) == 0) {
      utf8Copy(c.name, sizeof(c.name), BUS_DEFAULTS[d].stopName);
      if (!c.code[0]) utf8Copy(c.code, sizeof(c.code), BUS_DEFAULTS[d].code);
      return;
    }
  }
  if (c.code[0]) utf8Copy(c.name, sizeof(c.name), c.code);
}
// 4) 攞某幾個站有咩路線經過（stop-eta 串流）；成功但 0 條 → 種子；永唔下載 /route-stop
static bool kmbStopRoutes(const BusStopCand *stops, int nStops, BusRouteOpt *out, int *nOut) {
  static KmbStopEtaScan sink;  // buf 唔放 stack
  int n = 0;
  bool anyHttpOk = false;
  for (int s = 0; s < nStops; s++) {
    bsProgress(nStops > 1 ? "查詢經過嘅路線（%d）…" : "查詢經過嘅路線…", s + 1);
    char url[96];
    snprintf(url, sizeof(url), KMB_API "/stop-eta/%s", stops[s].id);
    WiFiClientSecure client;
    client.setInsecure();
    HTTPClient https;
    https.setTimeout(12000);
    https.setConnectTimeout(12000);
    if (!https.begin(client, url)) {
      Serial.printf("[BUS] stop-eta %s：begin 失敗\n", stops[s].id);
      continue;
    }
    int code = https.GET();
    if (code != HTTP_CODE_OK) {
      Serial.printf("[BUS] stop-eta %s：HTTP %d\n", stops[s].id, code);
      https.end();
      continue;
    }
    anyHttpOk = true;
    int before = n;
    sink.reset(out, BS_MAX_ROUTES, n, s);
    int r = https.writeToStream(&sink);
    n = sink.n;
    Serial.printf("[BUS] stop-eta %s：HTTP %d，%u bytes，r=%d，+%d → 累計 %d 條路線\n", stops[s].id, code,
                  (unsigned)sink.got, r, n - before, n);
    https.end();
  }
  if (n == 0 && anyHttpOk) {
    Serial.println("[BUS] stop-eta 得 0 條（HTTP OK）→ 用預設種子，唔下載 route-stop");
    kmbMergeSeedRoutes(stops, nStops, out, &n);
  }
  for (int a = 0; a < n; a++)
    for (int b = a + 1; b < n; b++)
      if (routeCmp(out[b].route, out[a].route) < 0 ||
          (strcmp(out[b].route, out[a].route) == 0 && out[b].serviceType < out[a].serviceType)) {
        BusRouteOpt t = out[a];
        out[a] = out[b];
        out[b] = t;
      }
  *nOut = n;
  return anyHttpOk || n > 0;
}
// 搵到站之後：攞路線列表，交俾 UI
static bool bsPublishRoutes(const BusStopCand *stops, int nStops) {
  static BusRouteOpt routes[BS_MAX_ROUTES];
  int nr = 0;
  bool ok = kmbStopRoutes(stops, nStops, routes, &nr);
  STATE_LOCK();
  gBusS.nStops = nStops;
  memcpy(gBusS.stops, stops, sizeof(BusStopCand) * nStops);
  gBusS.nRoutes = nr;
  memcpy(gBusS.routes, routes, sizeof(BusRouteOpt) * nr);
  gBusS.routesFailed = !ok;
  STATE_UNLOCK();
  Serial.printf("[BUS] %s %s：%d 條路線%s\n", stops[0].code, stops[0].name, nr, ok ? "" : "（查詢失敗）");
  bsFinish(BSS_ROUTES);
  return ok && nr > 0;
}
static void doBusFind(const char *query) {
  static BusStopCand found[BS_MAX_STOPS];
  char q[33];
  int kind = busClassify(query, q, sizeof(q));
  STATE_LOCK();
  snprintf(gBusS.query, sizeof(gBusS.query), "%s", q);
  STATE_UNLOCK();
  if (WiFi.status() != WL_CONNECTED) return bsFinish(BSS_FAIL, "未連線 WiFi，請先去「WiFi 設定」");
  int n = 0;
  bool netOk = true;
  if (kind == 1) {  // 站牌號碼
    n = kmbTableLookup(q, found, 2);
    Serial.printf("[BUS] 站牌 %s：內置表搵到 %d 個站 ID\n", q, n);
    if (n > 0) {
      // 表已有 ID：查站名失敗都繼續（用種子／號碼做顯示名）；唔強制下載 1.2MB /stop
      for (int i = 0; i < n; i++) {
        bsProgress("查詢站名…");
        int r = kmbStopName(found[i]);
        if (r <= 0) {
          Serial.printf("[BUS] 站名查詢失敗（r=%d），用表內 ID 繼續\n", r);
          kmbFillNameFromSeed(found[i]);
        }
      }
      bsPublishRoutes(found, n);  // 0 條 → BSS_ROUTES 空列表＋手動輸入；永唔 route-stop
      return;
    }
    // 內置表冇（新站）→ 串流下載最新 /stop 清單
    n = kmbScanStops(true, q, found, 2, &netOk);
    for (int i = 0; i < n; i++) utf8Copy(found[i].code, sizeof(found[i].code), q);
    if (n == 0) return bsFinish(BSS_FAIL, netOk ? "搵唔到呢個站牌號碼（只支援九巴／龍運）" : "網絡錯誤：下載站點清單失敗，請再試");
    bsPublishRoutes(found, n);
    return;
  } else if (kind == 2) {  // 16 位站 ID
    memset(&found[0], 0, sizeof(BusStopCand));
    utf8Copy(found[0].id, sizeof(found[0].id), q);
    bsProgress("查詢站名…");
    int r = kmbStopName(found[0]);
    if (r < 0) {
      kmbFillNameFromSeed(found[0]);
      if (!found[0].name[0]) utf8Copy(found[0].name, sizeof(found[0].name), q);
      Serial.println("[BUS] 站 ID：網絡查站名失敗，仍然查 stop-eta");
    } else if (r == 0) {
      return bsFinish(BSS_FAIL, "搵唔到呢個站 ID");
    }
    n = 1;
  } else if (kind == 3) {  // 英文站名
    n = kmbScanStops(false, q, found, BS_MAX_STOPS, &netOk);
    if (n == 0) return bsFinish(BSS_FAIL, netOk ? "冇英文站名包含呢個字" : "下載九巴站點資料失敗，請再試");
    if (n > 1) {
      STATE_LOCK();
      gBusS.nStops = n;
      memcpy(gBusS.stops, found, sizeof(BusStopCand) * n);
      gBusS.nRoutes = 0;
      STATE_UNLOCK();
      return bsFinish(BSS_STOPS);
    }
  } else {
    return bsFinish(BSS_FAIL, "請輸入站牌號碼，例如 YL395");
  }
  bsPublishRoutes(found, n);
}
static void doBusRoutes(uint8_t idx) {
  BusStopCand c;
  STATE_LOCK();
  bool ok = idx < gBusS.nStops;
  if (ok) c = gBusS.stops[idx];
  STATE_UNLOCK();
  if (!ok) return bsFinish(BSS_FAIL, "請重新搜尋");
  if (WiFi.status() != WL_CONNECTED) return bsFinish(BSS_FAIL, "未連線 WiFi");
  bsPublishRoutes(&c, 1);
}
// 手動輸入路線：用 /eta/{站}/{路線}/1 確認呢條路線有經過，順便攞方向同目的地
static void doBusCheck(const char *typed) {
  char route[6];
  utf8Copy(route, sizeof(route), typed);
  BusStopCand stops[2];
  STATE_LOCK();
  int ns = gBusS.nStops > 2 ? 2 : gBusS.nStops;
  memcpy(stops, gBusS.stops, sizeof(BusStopCand) * ns);
  STATE_UNLOCK();
  if (ns == 0) return bsFinish(BSS_FAIL, "請重新搜尋巴士站");
  if (WiFi.status() != WL_CONNECTED) return bsFinish(BSS_FAIL, "未連線 WiFi");
  bool anyOk = false;
  for (int s = 0; s < ns; s++) {
    bsProgress("確認路線…");
    char url[128];
    snprintf(url, sizeof(url), KMB_API "/eta/%.16s/%.5s/1", stops[s].id, route);
    String body;
    if (!httpsGet(url, body)) continue;
    anyOk = true;
    JsonDocument doc;
    if (deserializeJson(doc, body)) continue;
    JsonArray a = doc["data"].as<JsonArray>();
    if (a.isNull() || a.size() == 0) continue;
    BusRouteOpt x;
    memset(&x, 0, sizeof(x));
    utf8Copy(x.route, sizeof(x.route), route);
    x.dir = (a[0]["dir"] | "O")[0];
    x.serviceType = 1;
    x.stop = s;
    utf8Copy(x.dest, sizeof(x.dest), a[0]["dest_tc"] | "");
    STATE_LOCK();
    gBusS.checked = x;
    STATE_UNLOCK();
    return bsFinish(BSS_ROUTE_OK);
  }
  char m[64];
  if (anyOk) snprintf(m, sizeof(m), "呢個站冇 %s 號巴士", route);
  else snprintf(m, sizeof(m), "網絡錯誤，請再試");
  bsFinish(BSS_FAIL, m);
}

// ---------- 主迴圈 ----------
static void publishLink() {
  bool c = WiFi.status() == WL_CONNECTED;
  STATE_LOCK();
  bool changed = (c != gNet.connected);
  gNet.connected = c;
  if (c) {
    int8_t r = WiFi.RSSI();
    if (rssiBars(r) != rssiBars(gNet.rssi)) changed = true;
    gNet.rssi = r;
    strncpy(gNet.ssid, WiFi.SSID().c_str(), 32);
    gNet.ssid[32] = 0;
    strncpy(gNet.ip, WiFi.localIP().toString().c_str(), 15);
    gNet.ip[15] = 0;
  }
  struct tm t;
  time_t now = time(nullptr);
  localtime_r(&now, &t);
  bool ts = (t.tm_year + 1900) >= 2024;
  if (ts != gNet.timeSynced) changed = true;
  gNet.timeSynced = ts;
  STATE_UNLOCK();
  if (changed) bumpVer();
}
static bool tryAutoConnect() {
  STATE_LOCK();
  uint8_t n = gNet.savedCount;
  SavedNet saved[MAX_SAVED_WIFI];
  memcpy(saved, gNet.saved, sizeof(SavedNet) * n);
  STATE_UNLOCK();
#if defined(WIFI_SSID) && defined(WIFI_PASS)
  if (n == 0 && strcmp(WIFI_SSID, "YOUR_WIFI_SSID") != 0) {  // secrets.h 後備
    strncpy(saved[0].ssid, WIFI_SSID, 32);
    saved[0].ssid[32] = 0;
    strncpy(saved[0].pass, WIFI_PASS, 64);
    saved[0].pass[64] = 0;
    n = 1;
  }
#endif
  if (n == 0) return false;
  STATE_LOCK();
  gNet.connecting = true;
  STATE_UNLOCK();
  bumpVer();
  doScan();
  // 揀訊號最強嘅已儲存網絡；全部都掃唔到就順次序試（可能係隱藏網絡）
  int order[MAX_SAVED_WIFI], cnt = 0;
  int8_t best[MAX_SAVED_WIFI];
  STATE_LOCK();
  for (int i = 0; i < n; i++) {
    best[i] = -127;
    for (int k = 0; k < gNet.scanCount; k++)
      if (strcmp(gNet.scan[k].ssid, saved[i].ssid) == 0) best[i] = gNet.scan[k].rssi;
  }
  STATE_UNLOCK();
  for (int i = 0; i < n; i++) order[cnt++] = i;
  for (int a = 0; a < cnt; a++)
    for (int b = a + 1; b < cnt; b++)
      if (best[order[b]] > best[order[a]]) {
        int t = order[a];
        order[a] = order[b];
        order[b] = t;
      }
  bool ok = false;
  for (int k = 0; k < cnt && !ok; k++) {
    if (best[order[k]] == -127 && k > 0) break;  // 掃唔到嘅只試第一個
    if (gNetCmd != NC_NONE) break;               // 使用者有新指令，讓路
    ok = doConnect(saved[order[k]].ssid, saved[order[k]].pass, 12000, nullptr, 0);
    if (ok && n > 0 && gNet.savedCount == 0) savedRemember(saved[order[k]].ssid, saved[order[k]].pass);
  }
  STATE_LOCK();
  gNet.connecting = false;
  STATE_UNLOCK();
  bumpVer();
  return ok;
}

static void netTask(void *) {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.onEvent([](arduino_event_id_t, arduino_event_info_t info) { gDiscReason = info.wifi_sta_disconnected.reason; },
               ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
  savedLoad();
  bumpVer();
  uint32_t lastAuto = 0, lastWx = 0, lastBus = 0, lastLinkPub = 0, lostSince = 0;
  bool firstAuto = true, ntpStarted = false, wxEver = false, wxFailed = false;
  for (;;) {
    // ---- 1. UI 指令 ----
    NetCmd cmd = gNetCmd;
    bool skipWxBus = false;  // 巴士站搜尋期間唔同跑天氣／ETA，慳 heap／TLS
    if (cmd != NC_NONE) {
      char ssid[33], pass[65], bq[33];
      STATE_LOCK();
      strcpy(ssid, gCmdSsid);
      strcpy(pass, gCmdPass);
      strcpy(bq, gBusQ);
      gNetCmd = NC_NONE;
      STATE_UNLOCK();
      if (cmd == NC_BUS_FIND || cmd == NC_BUS_ROUTES || cmd == NC_BUS_CHECK) skipWxBus = true;
      if (cmd == NC_BUS_FIND) {
        doBusFind(bq);
      } else if (cmd == NC_BUS_ROUTES) {
        doBusRoutes(gBusQStop);
      } else if (cmd == NC_BUS_CHECK) {
        doBusCheck(bq);
      } else if (cmd == NC_SCAN) {
        doScan();
      } else if (cmd == NC_FORGET) {
        savedForget(ssid);
        if (WiFi.status() == WL_CONNECTED && WiFi.SSID() == ssid) WiFi.disconnect(false, false);
        bumpVer();
      } else if (cmd == NC_CONNECT) {
        char why[64];
        bool ok = doConnect(ssid, pass, 15000, why, sizeof(why));
        if (ok) savedRemember(ssid, pass);
        STATE_LOCK();
        gNet.userConn = ok ? UC_OK : UC_FAIL;
        if (ok) snprintf(gNet.userMsg, sizeof(gNet.userMsg), "%s  IP %s", ssid, WiFi.localIP().toString().c_str());
        else snprintf(gNet.userMsg, sizeof(gNet.userMsg), "%s", why);
        STATE_UNLOCK();
        lastAuto = millis();
        publishLink();
        bumpVer();
      }
    }
    // ---- 2. 狀態 ----
    if (millis() - lastLinkPub > 1000) {
      lastLinkPub = millis();
      publishLink();
    }
    bool con = WiFi.status() == WL_CONNECTED;
    // ---- 3. 自動連線（開機 / 斷線超過 10 秒後每 30 秒）----
    if (!con) {
      if (!lostSince) lostSince = millis();
      bool due = firstAuto || (millis() - lastAuto > WIFI_RETRY_MS && millis() - lostSince > 10000);
      if (due && gNetCmd == NC_NONE) {
        firstAuto = false;
        tryAutoConnect();
        lastAuto = millis();
        publishLink();
      }
    } else {
      lostSince = 0;
      firstAuto = false;
      if (!ntpStarted) {
        configTzTime(TZ_INFO, NTP_SERVER_1, NTP_SERVER_2, NTP_SERVER_3);
        ntpStarted = true;
      }
      // ---- 4. 天氣（10 分鐘；失敗 1 分鐘後再試）----
      // 巴士搵站／路線／確認進行緊（或啱啱做完）就延後，避免同 HTTPS 搶記憶體
      if (skipWxBus || gNetCmd == NC_BUS_FIND || gNetCmd == NC_BUS_ROUTES || gNetCmd == NC_BUS_CHECK) {
        vTaskDelay(pdMS_TO_TICKS(100));
        continue;
      }
      uint32_t wxDue = wxFailed ? 60000UL : WEATHER_INTERVAL_MS;
      if (!wxEver || millis() - lastWx > wxDue) {
        lastWx = millis();
        bool a = false, b = false, c = false;
        if (WiFi.status() == WL_CONNECTED) {
          a = fetchWeatherNow();
          httpsPause();
          if (gNetCmd == NC_NONE && WiFi.status() == WL_CONNECTED) {
            b = fetchForecast();
            httpsPause();
          }
          if (gNetCmd == NC_NONE && WiFi.status() == WL_CONNECTED) {
            c = fetchWarnsum();
            httpsPause();
            mergeFlwFireDanger();  // warnsum 成功或失敗都試 flw 火災後備（有字先加）
          }
        }
        // 即時天氣成功 → 清失敗旗標；失敗時若仍有舊資料 → 唔 sticky 顯示「更新失敗」
        // （暫態 HTTPS 失敗好常見；有上次成功資料就繼續顯示，1 分鐘後再試）
        wxFailed = !a;
        if (!b) Serial.println("[WX] forecast update failed (即時天氣仍可用)");
        if (!c) {
          STATE_LOCK();
          // 保留上次警告內容；只喺從未成功過時標失敗
          if (!gWxWarn.valid) gWxWarn.failed = true;
          STATE_UNLOCK();
        } else {
          STATE_LOCK();
          gWxWarn.failed = false;
          STATE_UNLOCK();
        }
        wxEver = true;
        STATE_LOCK();
        if (a)
          gWeather.failed = false;
        else if (!gWeather.valid)
          gWeather.failed = true;   // 從未成功過 → 頂欄可顯示失敗
        else
          gWeather.failed = false;  // 有舊資料：唔因一次暫態失敗嚇學生
        STATE_UNLOCK();
        bumpVer();
      }
      // ---- 5. 巴士（儀表板開住 30 秒；否則 3 分鐘）----
      uint32_t busDue = gDashboardActive ? BUS_INTERVAL_MS : BUS_IDLE_INTERVAL_MS;
      if (gBusForce || lastBus == 0 || millis() - lastBus > busDue) {
        gBusForce = false;
        lastBus = millis();
        gBusFetching = true;
        bumpVer();
        for (int i = 0; i < BUS_MAX_SLOTS; i++) {
          if (gNetCmd != NC_NONE) break;
          if (WiFi.status() != WL_CONNECTED) break;
          bool ok = fetchBus(i);
          if (!ok) {
            STATE_LOCK();
            // 保留上次 ETA；只標呢一格失敗（頂欄要已設定格都冇可用資料先「更新失敗」）
            gBus[i].failed = true;
            STATE_UNLOCK();
          }
          httpsPause();
        }
        gBusFetching = false;
        bumpVer();
      }
    }
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

// ---------- 俾 UI 用嘅指令 ----------
static void netRequestScan() {
  STATE_LOCK();
  gNetCmd = NC_SCAN;
  STATE_UNLOCK();
}
static void netRequestConnect(const char *ssid, const char *pass) {
  STATE_LOCK();
  strncpy(gCmdSsid, ssid, 32);
  gCmdSsid[32] = 0;
  strncpy(gCmdPass, pass, 64);
  gCmdPass[64] = 0;
  gNet.userConn = UC_BUSY;
  gNetCmd = NC_CONNECT;
  STATE_UNLOCK();
}
static void netRequestForget(const char *ssid) {
  STATE_LOCK();
  strncpy(gCmdSsid, ssid, 32);
  gCmdSsid[32] = 0;
  gCmdPass[0] = 0;
  gNetCmd = NC_FORGET;
  STATE_UNLOCK();
}
static void netBusFind(const char *q) {
  STATE_LOCK();
  snprintf(gBusQ, sizeof(gBusQ), "%.32s", q);
  gBusS.st = BSS_BUSY;
  gBusS.progress[0] = 0;
  gNetCmd = NC_BUS_FIND;
  STATE_UNLOCK();
}
static void netBusRoutes(uint8_t stopIdx) {
  STATE_LOCK();
  gBusQStop = stopIdx;
  gBusS.st = BSS_BUSY;
  gBusS.progress[0] = 0;
  gNetCmd = NC_BUS_ROUTES;
  STATE_UNLOCK();
}
static void netBusCheck(const char *route) {
  STATE_LOCK();
  snprintf(gBusQ, sizeof(gBusQ), "%.32s", route);
  gBusS.st = BSS_BUSY;
  gBusS.progress[0] = 0;
  gNetCmd = NC_BUS_CHECK;
  STATE_UNLOCK();
}
