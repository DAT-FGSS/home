#include "calendar_data.h"
#pragma once
// 各畫面嘅版面同繪製（320x240 橫向）。只讀 state.h 啲資料。

// ===================== UI 狀態 =====================
enum AppId : uint8_t { APP_HOME, APP_DASH, APP_WIFI, APP_BUS, APP_CAL, APP_TMR };
enum WifiView : uint8_t { WV_LIST, WV_KB };
enum BusView : uint8_t { BV_LIST, BV_KB, BV_STOPS, BV_ROUTES };
enum KbMode : uint8_t { KM_SSID = 0, KM_PASS, KM_STOP, KM_ROUTE };
enum Dlg : uint8_t {
  DLG_NONE, DLG_SAVED, DLG_CONNECTING, DLG_OK, DLG_FAIL,
  DLG_BUS_SLOT, DLG_BUS_BUSY, DLG_BUS_FAIL, DLG_BUS_RESET,
  DLG_ALERT  // 倒數完／鬧鐘（全屏提示，無喇叭）
};
enum BtnId : uint8_t {
  B_NONE = 0, B_BACK, B_ICON0, B_ICON1, B_ICON2, B_ICON3, B_ICON4, B_HOMECARD,
  B_WSCAN, B_WADD, B_TAB0, B_TAB1, B_EYE, B_DLG0, B_DLG1, B_DLG2,
  B_BMANUAL, B_BRESET, B_BUSCARD,
  B_CAL_PREV, B_CAL_NEXT,
  B_TMR_TAB0, B_TMR_TAB1, B_TMR_TAB2,
  B_TMR_START, B_TMR_RESET,
  B_TMR_H_UP, B_TMR_H_DN, B_TMR_M_UP, B_TMR_M_DN, B_TMR_S_UP, B_TMR_S_DN,
  B_ALM_TOGGLE
};
enum TimerTab : uint8_t { TT_SW = 0, TT_CD, TT_ALM };
struct UiState {
  AppId app;
  uint8_t pressed;     // 按住緊嘅掣（畫高亮用）
  int pressedRow;      // 按住緊嘅列表行
  uint8_t wifiTab;     // 0 附近網絡, 1 已儲存
  int wifiScroll;
  WifiView wv;
  uint8_t kbMode;      // KbMode：網絡名稱 / 密碼 / 巴士站號碼 / 路線
  char kbSsid[33];
  char kbText[65];
  uint8_t kbPage;      // 0 英文字母, 1 數字符號, 2 更多符號
  uint8_t kbShift;     // 0 關, 1 一次, 2 大楷鎖定
  bool kbShow;         // 顯示密碼
  int kbPressed;       // 按住緊嘅鍵
  Dlg dlg;
  char dlgSsid[33];
  char dlgMsg[64];
  char toast[48];
  uint32_t toastUntil;
  uint32_t frame;      // 動畫用
  // 巴士站設定
  BusView busView;
  uint8_t busSlot;     // 改緊第幾格（0–2）
  int busScroll;
  char busFilter[6];   // 手動輸入路線有幾個方向 → 只顯示呢條路線
  char busQuery[33];   // 上次輸入嘅巴士站
  // 日曆
  int calY, calM;      // 顯示緊嘅年月；0 = 未初始化 → 用今日
  // 計時器分頁
  uint8_t tmrTab;      // TimerTab
};
static UiState ui = {APP_HOME, B_NONE, -1, 0, 0, WV_LIST, KM_SSID, "", "", 0, 0, false, -1,
                     DLG_NONE, "", "", "", 0, 0, BV_LIST, 0, 0, "", "", 0, 0, TT_SW};

static uint32_t uiMillis();  // 由主程式 / 預覽程式提供

static const char *const WEEK_ZH[7] = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};

static bool nowLocal(struct tm *t, time_t *out = nullptr) {
  time_t n = time(nullptr);
  if (out) *out = n;
  localtime_r(&n, t);
  return (t->tm_year + 1900) >= 2024;
}

// ===================== 版面常數 =====================
#define HDR_H 26
// 主畫面：第一行 5 個 App 圖示；第二行校徽＋「粉嶺官立中學製作」
#define HOME_ICONS 5
#define HOME_ICON_SZ 40
#define HOME_ROW1_Y 24
#define HOME_ROW2_Y 98
// 320÷5=64，圖示 40 置中：12 + i*64
static const int HOME_ICON_X[HOME_ICONS] = {12, 76, 140, 204, 268};
#define HOME_CARD_Y 178
#define HOME_CARD_H 58
// WiFi
#define WF_STATUS_Y 30
#define WF_TABS_Y 58
#define WF_LIST_Y 86
#define WF_ROW_H 34
// 鍵盤
#define KB_Y0 82
#define KB_RH 39
#define KB_BOX_Y 46
#define KB_BOX_H 30
#define KBC_Y0 80      // 巴士站 / 路線用嘅「數字 + 大楷」鍵盤（5 行）
#define KBC_RH 32
// 巴士站設定
#define BL_Y0 58       // 三格
#define BL_RH 52
#define BR_LIST_Y 58   // 路線 / 站列表
#define BR_ROW_H 34
// 彈出視窗
#define DLG_X 30
#define DLG_Y 56
#define DLG_W 260
#define DLG_H 128

// ===================== 共用：頂欄 =====================
static void drawHeader(const char *title, bool back = true) {
  fillGradV(0, 0, 320, HDR_H, 0x18E3, 0x10A2);
  gfx->drawFastHLine(0, HDR_H - 1, 320, COL_LINE);
  int x = 10;
  if (back) {
    if (ui.pressed == B_BACK) gfx->fillRoundRect(2, 2, 104, HDR_H - 4, 8, COL_CARD_HI);
    iconBack(10, 6, COL_ACCENT);
    x = 26;
  }
  drawText(x, 19, title, F_ZH16, COL_TEXT);
}
static void drawWifiStatusIcon(int cx, int cy) {
  STATE_LOCK();
  bool on = gNet.connected;
  int lvl = rssiBars(gNet.rssi);
  STATE_UNLOCK();
  iconWifi(cx, cy, 12, lvl, on);
}
static void drawToast() {
  if (!ui.toast[0] || (int32_t)(uiMillis() - ui.toastUntil) > 0) return;
  int w = textW(ui.toast, F_ZH12) + 28;
  int x = (320 - w) / 2;
  gfx->fillRoundRect(x, 200, w, 26, 13, 0x4A69);
  drawText(x + 14, 218, ui.toast, F_ZH12, COL_TEXT);
}
static void showToast(const char *msg, uint32_t ms = 2200) {
  strncpy(ui.toast, msg, sizeof(ui.toast) - 1);
  ui.toast[sizeof(ui.toast) - 1] = 0;
  ui.toastUntil = uiMillis() + ms;
}
// ===================== 主畫面 =====================
static void dashEta(int x, int y, time_t eta, bool sched, time_t now, bool big);
// 底部卡片右邊：所有已設定路線之中最快到嗰班（同儀表板一樣，略過已開出嘅班次）
static void drawHomeBus(int x, int y, int w, bool con) {
  if (!con) {
    drawText(x, y + 26, "未連線 WiFi", F_ZH12, COL_WARN);
    drawText(x, y + 48, "請開「WiFi 設定」", F_ZH12, COL_MUTED, w);
    return;
  }
  STATE_LOCK();
  BusInfo b[BUS_MAX_SLOTS];
  memcpy(b, gBus, sizeof(b));
  BusSlot cfg[BUS_MAX_SLOTS];
  memcpy(cfg, gBusCfg, sizeof(cfg));
  STATE_UNLOCK();
  struct tm t;
  time_t now;
  bool ok = nowLocal(&t, &now);
  int used = 0, valid = 0, bs = -1, bk = -1;
  for (int i = 0; i < BUS_MAX_SLOTS; i++) {
    if (!cfg[i].used) continue;
    used++;
    if (!b[i].valid) continue;
    valid++;
    for (int k = 0; ok && k < b[i].n; k++) {
      if (b[i].eta[k] < now - 30) continue;
      if (bs < 0 || b[i].eta[k] < b[bs].eta[bk]) {
        bs = i;
        bk = k;
      }
      break;  // 每條路線只睇最近一班
    }
  }
  if (!used) {
    drawText(x, y + 26, "未設定巴士路線", F_ZH12, COL_MUTED);
    drawText(x, y + 48, "請開「巴士站設定」", F_ZH12, COL_MUTED, w);
    return;
  }
  if (bs < 0) {
    drawText(x, y + 24, "下一班巴士", F_ZH12, COL_MUTED);
    drawText(x, y + 48, (valid && ok) ? "暫時沒有班次" : "載入中…", F_ZH12, COL_MUTED);
    return;
  }
  // 路線牌 + 目的地
  int pw = textW(cfg[bs].route, F_MED) + 14;
  gfx->fillRoundRect(x, y + 9, pw, 20, 6, COL_KMB);
  drawText(x + 7, y + 24, cfg[bs].route, F_MED, 0xFFFF);
  char dest[37];
  utf8Copy(dest, sizeof(dest), cfg[bs].dest);
  int dw = w - pw - 6;
  if (textW(dest, F_ZH12) > dw) {  // 太長 → 只要括號 / 空格前面
    char *cut = strpbrk(dest, "( ");
    if (cut && cut != dest) *cut = 0;
  }
  drawText(x + pw + 6, y + 24, dest, F_ZH12, COL_MUTED, dw);
  // 分鐘（大）+ 同一條路線下一班（細）
  dashEta(x, y + 54, b[bs].eta[bk], b[bs].sched[bk], now, true);
  if (bk + 1 < b[bs].n) {
    long d = (long)(b[bs].eta[bk + 1] - now) / 60;
    char nb[8];
    if (d < 1) d = 1;
    if (d > 99) snprintf(nb, sizeof(nb), "99+");
    else snprintf(nb, sizeof(nb), "%ld", d);
    int rx = x + w - textW("分", F_ZH12);
    drawText(rx, y + 53, "分", F_ZH12, COL_MUTED);
    rx -= textW(nb, F_SMALL) + 2;
    drawText(rx, y + 53, nb, F_SMALL, COL_MUTED);
    drawTextR(rx - 4, y + 53, "下班", F_ZH12, COL_MUTED);
  }
}
static void drawHome() {
  fillGradV(0, 0, 320, 240, RGB565(24, 30, 48), RGB565(8, 10, 16));
  struct tm t;
  bool ok = nowLocal(&t);
  char buf[40];
  if (ok) snprintf(buf, sizeof(buf), "%02d:%02d", t.tm_hour, t.tm_min);
  else snprintf(buf, sizeof(buf), "--:--");
  drawText(12, 16, buf, F_MED, COL_TEXT);
  if (ok) {
    snprintf(buf, sizeof(buf), "%d月%d日", t.tm_mon + 1, t.tm_mday);
    drawTextC(160, 15, buf, F_ZH12, COL_MUTED);
  }
  drawWifiStatusIcon(302, 17);
  // 活躍倒數／鬧鐘小徽章
  bool badge = gTmr.cdRun || gTmr.almOn;
  if (badge) {
    gfx->fillRoundRect(214, 3, 28, 16, 8, COL_WARN);
    drawTextC(228, 15, "計", F_ZH12, 0x0000);
  }
  if (gTouch.fail) {
    gfx->fillRoundRect(badge ? 178 : 244, 3, 32, 16, 8, COL_DANGER);
    drawText(badge ? 182 : 248, 15, "觸控", F_ZH12, 0xFFFF);
  }

  static const char *const names[HOME_ICONS] = {"儀表板", "日曆", "計時器", "WiFi", "巴士站"};
  // 第一行：五個 App
  for (int i = 0; i < HOME_ICONS; i++) {
    bool pr = (ui.pressed == B_ICON0 + i);
    int x = HOME_ICON_X[i], y = HOME_ROW1_Y;
    if (i == 0) appIconDashboard(x, y, pr, HOME_ICON_SZ);
    else if (i == 1) appIconCalendar(x, y, pr, HOME_ICON_SZ);
    else if (i == 2) appIconTimer(x, y, pr, HOME_ICON_SZ);
    else if (i == 3) appIconWifi(x, y, pr, HOME_ICON_SZ);
    else appIconBus(x, y, pr, HOME_ICON_SZ);
    drawTextC(x + HOME_ICON_SZ / 2, y + HOME_ICON_SZ + 12, names[i], F_ZH12, COL_TEXT);
  }
  // 第二行：校徽＋「粉嶺官立中學製作」（冇 App 圖示）
  {
    const char *credit = "粉嶺官立中學製作";
    int cw = CREST_S.w, gap = 10;
    int tw = textW(credit, F_ZH12);
    int total = cw + gap + tw;
    int x0 = (320 - total) / 2;
    int cy = HOME_ROW2_Y + (48 - CREST_S.h) / 2;
    drawCrest(x0, cy, CREST_S);
    drawText(x0 + cw + gap, HOME_ROW2_Y + 28, credit, F_ZH12, COL_MUTED);
  }

  // 底部卡片
  int y = HOME_CARD_Y;
  uint16_t cbg = ui.pressed == B_HOMECARD ? COL_CARD_HI : 0x2104;
  gfx->fillRoundRect(10, y, 300, HOME_CARD_H, 12, cbg);
  STATE_LOCK();
  WeatherNow w = gWeather;
  bool con = gNet.connected;
  STATE_UNLOCK();
  if (w.valid) {
    drawWx(36, y + 28, 32, w.icon, cbg);
    char tb[16];
    snprintf(tb, sizeof(tb), "%d\xC2\xB0", w.tempC);
    drawText(60, y + 30, tb, F_BIG, COL_TEXT);
    if (w.humidity >= 0) {
      iconDrop(65, y + 42, 3, COL_RAIN);
      snprintf(tb, sizeof(tb), "%d%%", w.humidity);
      drawText(72, y + 48, tb, F_TINY, COL_MUTED);
    }
  } else {
    drawText(18, y + 22, "天氣", F_ZH12, COL_MUTED);
    drawText(18, y + 42, con ? "載入中…" : "未有資料", F_ZH12, COL_MUTED);
  }
  gfx->drawFastVLine(130, y + 10, HOME_CARD_H - 20, COL_LINE);
  drawHomeBus(140, y - 2, 158, con);
  drawToast();
}

// ===================== 資訊儀表板 =====================
static void dashEta(int x, int y, time_t eta, bool sched, time_t now, bool big) {
  long d = (long)(eta - now);
  uint16_t c = big ? (sched ? COL_TEXT : COL_ACCENT) : COL_MUTED;
  if (d < 60) {
    drawText(x, y, "即將到", big ? F_ZH16 : F_ZH12, big ? COL_WARN : COL_MUTED);
    return;
  }
  long m = d / 60;
  char nb[12];
  if (m > 99) {
    struct tm t;
    localtime_r(&eta, &t);
    snprintf(nb, sizeof(nb), "%02d:%02d", t.tm_hour, t.tm_min);
    drawText(x, y, nb, big ? F_NUM : F_SMALL, c);
    return;
  }
  snprintf(nb, sizeof(nb), "%ld", m);
  int w = drawText(x, y, nb, big ? F_NUM : F_SMALL, c);
  drawText(x + w + 3, y, "分", F_ZH12, big ? COL_MUTED : COL_MUTED);
}
static void drawDashboard() {
  gfx->fillScreen(COL_BG);
  drawHeader("資訊儀表板");
  // 頂欄右邊：更新狀態 + WiFi
  STATE_LOCK();
  // 頂欄「更新失敗」：只要有可用舊資料就唔嚇學生；只喺該域完全冇資料且上次失敗先顯示
  bool wfail = gWeather.failed && !gWeather.valid;
  bool bfail = false;
  {
    int used = 0, dead = 0;
    for (int i = 0; i < BUS_MAX_SLOTS; i++) {
      if (!gBusCfg[i].used) continue;
      used++;
      if (gBus[i].failed && !gBus[i].valid) dead++;
    }
    bfail = (used > 0 && dead == used);
  }
  bool con = gNet.connected;
  STATE_UNLOCK();
  const char *st = !con ? "未連線" : (gBusFetching ? "更新中…" : ((wfail || bfail) ? "更新失敗" : ""));
  if (st[0]) drawTextR(284, 18, st, F_ZH12, con && !gBusFetching ? COL_WARN : COL_MUTED);
  drawWifiStatusIcon(302, 20);

  // ---- 天氣：左邊三日預報 / 右邊即時 ----
  STATE_LOCK();
  WeatherNow w = gWeather;
  ForecastDay fc[3];
  memcpy(fc, gForecast, sizeof(fc));
  STATE_UNLOCK();
  card(4, 30, 200, 68);
  for (int i = 0; i < 3; i++) {
    int cx = 4 + i * 66 + 34;
    if (i > 0) gfx->drawFastVLine(4 + i * 66 + 1, 38, 52, COL_LINE);
    if (!fc[i].valid) {
      drawTextC(cx, 70, "--", F_SMALL, COL_MUTED);
      continue;
    }
    char wk[16];
    // 「星期三」→「週三」
    const char *last = fc[i].week;
    size_t L = strlen(fc[i].week);
    if (L >= 3) last = fc[i].week + L - 3;
    snprintf(wk, sizeof(wk), "週%s", last);
    drawTextC(cx, 44, wk, F_ZH12, COL_MUTED);
    drawWx(cx, 61, 28, fc[i].icon, COL_CARD);
    char tb[20];
    snprintf(tb, sizeof(tb), "%d-%d\xC2\xB0", fc[i].minC, fc[i].maxC);
    drawTextC(cx, 92, tb, F_SMALL, COL_TEXT);
  }
  card(208, 30, 108, 68);
  if (w.valid) {
    drawWx(236, 56, 40, w.icon, COL_CARD);
    char tb[16];
    snprintf(tb, sizeof(tb), "%d\xC2\xB0", w.tempC);
    drawTextC(287, 62, tb, F_BIG, COL_TEXT);
    iconDrop(268, 84, 4, COL_RAIN);
    if (w.humidity >= 0) snprintf(tb, sizeof(tb), "%d%%", w.humidity);
    else snprintf(tb, sizeof(tb), "--");
    drawText(277, 90, tb, F_SMALL, COL_MUTED);
  } else {
    drawTextC(262, 70, con ? "載入中…" : "--", F_ZH12, COL_MUTED);
  }

  // ---- 中間：左邊日期、中央大時鐘、右邊天氣警告圖符 ----
  card(4, 102, 312, 52);
  struct tm t;
  time_t now;
  bool ok = nowLocal(&t, &now);
  if (ok) {
    char db[24];
    snprintf(db, sizeof(db), "%d月%d日", t.tm_mon + 1, t.tm_mday);
    drawText(12, 122, db, F_ZH12, COL_TEXT);
    drawText(12, 142, WEEK_ZH[t.tm_wday], F_ZH12, COL_MUTED);
    char tb[8];
    snprintf(tb, sizeof(tb), "%02d:%02d", t.tm_hour, t.tm_min);
    drawTextC(150, 146, tb, F_CLOCK, COL_ACCENT);
  } else {
    drawText(12, 130, "等待校時…", F_ZH12, COL_MUTED);
    drawTextC(150, 146, "--:--", F_CLOCK, COL_LINE);
  }
  // 天氣警告圖符（右邊）
  STATE_LOCK();
  WxWarnSum ws = gWxWarn;
  STATE_UNLOCK();
  int wx0 = 232, wy = 128;
  // 冇生效警告 → 留空（唔顯示「無警告」）
  if (ws.n > 0) {
    int show = ws.n > 4 ? 3 : (int)ws.n;
    for (int i = 0; i < show; i++)
      drawWarnIcon(wx0 + 10 + i * 26, wy, 24, ws.items[i].code);
    if ((int)ws.n > show) {
      char more[8];
      snprintf(more, sizeof(more), "+%u", ws.n - show);
      drawText(wx0 + 10 + show * 26, wy + 6, more, F_TINY, COL_WARN);
    }
  }

  // ---- 巴士：三張卡（巴士站設定嘅三格），每張顯示最近兩班 ----
  STATE_LOCK();
  BusInfo b[BUS_MAX_SLOTS];
  memcpy(b, gBus, sizeof(b));
  BusSlot cfg[BUS_MAX_SLOTS];
  memcpy(cfg, gBusCfg, sizeof(cfg));
  STATE_UNLOCK();
  for (int i = 0; i < BUS_MAX_SLOTS; i++) {
    int x = 4 + i * 105, y = 158, wdt = 102, h = 78;
    card(x, y, wdt, h, 10, ui.pressed == B_BUSCARD ? COL_CARD_HI : COL_CARD);
    if (!cfg[i].used) {  // 未設定：撳就去巴士站設定
      gfx->drawRoundRect(x + wdt / 2 - 14, y + 14, 28, 28, 8, COL_LINE);
      iconPlus(x + wdt / 2, y + 28, 6, COL_MUTED);
      drawTextC(x + wdt / 2, y + 64, "設定路線", F_ZH12, COL_MUTED);
      continue;
    }
    int pw = textW(cfg[i].route, F_MED) + 14;
    gfx->fillRoundRect(x + 8, y + 7, pw, 20, 6, COL_KMB);
    drawText(x + 15, y + 22, cfg[i].route, F_MED, 0xFFFF);
    // 目的地（卡太窄 → 只要括號 / 空格前面，例如「上水(清河)」→「上水」）
    char dest[37];
    utf8Copy(dest, sizeof(dest), cfg[i].dest);
    int dx = x + 8 + pw + 5, dw = x + wdt - 8 - dx - (b[i].failed ? 8 : 0);
    if (textW(dest, F_ZH12) > dw) {
      char *cut = strpbrk(dest, "( ");
      if (cut && cut != dest) *cut = 0;
    }
    if (dw > 14) drawText(dx, y + 22, dest, F_ZH12, COL_MUTED, dw);
    if (b[i].failed) gfx->fillCircle(x + wdt - 9, y + 12, 3, COL_WARN);
    // 揀出未開出嘅班次（拎資料之後過咗時間嘅都要略過）
    int idx[2], n = 0;
    for (int k = 0; k < b[i].n && n < 2; k++)
      if (ok && b[i].eta[k] >= now - 30) idx[n++] = k;
    if (!b[i].valid || !ok) {
      drawText(x + 10, y + 54, "--", F_NUM, COL_LINE);
    } else if (n == 0) {
      drawText(x + 10, y + 52, "暫時沒有班次", F_ZH12, COL_MUTED);
    } else {
      dashEta(x + 10, y + 52, b[i].eta[idx[0]], b[i].sched[idx[0]], now, true);
      if (n > 1) {
        drawText(x + 10, y + 70, "下班", F_ZH12, COL_MUTED);
        dashEta(x + 40, y + 70, b[i].eta[idx[1]], b[i].sched[idx[1]], now, false);
      }
    }
  }
  drawToast();
}


// ===================== 日曆 =====================
static void calEnsure() {
  if (ui.calY >= 2020 && ui.calM >= 1 && ui.calM <= 12) return;
  struct tm t;
  if (nowLocal(&t)) {
    ui.calY = t.tm_year + 1900;
    ui.calM = t.tm_mon + 1;
  } else {
    ui.calY = 2026;
    ui.calM = 10;
  }
}
static void drawCalendar() {
  calEnsure();
  gfx->fillScreen(COL_BG);
  drawHeader("日曆");
  // 換月：幾何箭咀（唔用 Unicode ‹ ›，字型冇會變方格）
  if (ui.pressed == B_CAL_PREV) gfx->fillRoundRect(248, 2, 32, HDR_H - 4, 6, COL_CARD_HI);
  if (ui.pressed == B_CAL_NEXT) gfx->fillRoundRect(284, 2, 32, HDR_H - 4, 6, COL_CARD_HI);
  iconChevronLeft(256, 7, COL_ACCENT);   // ◀ 換月（同返回一樣幼身）
  iconChevronRight(294, 7, COL_ACCENT);  // ▶

  struct tm today;
  bool okToday = nowLocal(&today);
  int ty = okToday ? today.tm_year + 1900 : 0, tm = okToday ? today.tm_mon + 1 : 0, td = okToday ? today.tm_mday : 0;
  int y = ui.calY, m = ui.calM;
  int focusD = (y == ty && m == tm) ? td : 1;
  if (focusD < 1) focusD = 1;

  // 紅字大標題（唔再顯示農曆副標題，慳位俾格仔）
  char head[48];
  snprintf(head, sizeof(head), "%d年%d月%d日 %s", y, m, focusD, WEEK_ZH[calDayOfWeek(y, m, focusD)]);
  drawTextC(160, 44, head, F_ZH16, COL_DANGER);

  // 星期欄
  static const char *const WD[7] = {"日", "一", "二", "三", "四", "五", "六"};
  int gridY = 50, cellW = 44, cellH = 26;
  gfx->fillRoundRect(4, gridY, 312, 15, 4, 0x2945);
  for (int i = 0; i < 7; i++) {
    uint16_t c = (i == 0 || i == 6) ? COL_DANGER : COL_TEXT;
    drawTextC(4 + cellW / 2 + i * cellW, gridY + 12, WD[i], F_ZH12, c);
  }

  int firstW = calDayOfWeek(y, m, 1);
  int dim = calDaysInMonth(y, m);
  int row0 = gridY + 16;
  for (int d = 1; d <= dim; d++) {
    int idx = firstW + d - 1;
    int row = idx / 7, col = idx % 7;
    int cx = 4 + col * cellW + cellW / 2;
    int cy = row0 + row * cellH;
    bool weekend = (col == 0 || col == 6);
    bool isToday = (y == ty && m == tm && d == td);
    // 今日框：包住數字 + 農曆標籤成格
    if (isToday) gfx->drawRect(cx - cellW / 2 + 2, cy + 1, cellW - 4, cellH - 2, COL_TEXT);
    char num[4];
    snprintf(num, sizeof(num), "%d", d);
    drawTextC(cx, cy + 13, num, F_MED, weekend ? COL_DANGER : COL_TEXT);
    char lab[16];
    calCellLabel(y, m, d, lab, sizeof(lab));
    // 全部日子用同一細字標籤（今日都唔放大、唔改強調色）
    if (lab[0]) drawTextC(cx, cy + 24, lab, F_ZH12, COL_MUTED, cellW - 6);
  }

  // 底部宜忌
  char yi[48], ji[48];
  calYiJi(y, m, focusD, yi, sizeof(yi), ji, sizeof(ji));
  int by = 218;
  gfx->fillRect(0, by - 2, 320, 24, 0x14A3);
  drawText(8, by + 14, "宜", F_ZH12, COL_OK);
  drawText(28, by + 14, yi, F_ZH12, COL_TEXT, 140);
  drawText(170, by + 14, "忌", F_ZH12, COL_DANGER);
  drawText(190, by + 14, ji, F_ZH12, COL_TEXT, 120);
  drawToast();
}

// ===================== 計時／倒數／鬧鐘 =====================
static uint32_t tmrSwElapsed() {
  uint32_t ms = gTmr.swAcc;
  if (gTmr.swRun) ms += uiMillis() - gTmr.swStart;
  return ms;
}
static void tmrFormat(uint32_t ms, char *out, size_t n, bool centi) {
  uint32_t total = ms / 10;  // centiseconds
  uint32_t cs = total % 100;
  total /= 100;
  uint32_t s = total % 60;
  total /= 60;
  uint32_t m = total % 60;
  uint32_t h = total / 60;
  if (centi) {
    if (h) snprintf(out, n, "%lu:%02lu:%02lu.%02lu", (unsigned long)h, (unsigned long)m, (unsigned long)s, (unsigned long)cs);
    else snprintf(out, n, "%02lu:%02lu.%02lu", (unsigned long)m, (unsigned long)s, (unsigned long)cs);
  } else {
    if (h) snprintf(out, n, "%lu:%02lu:%02lu", (unsigned long)h, (unsigned long)m, (unsigned long)s);
    else snprintf(out, n, "%02lu:%02lu", (unsigned long)m, (unsigned long)s);
  }
}
static void drawTimer() {
  gfx->fillScreen(COL_BG);
  drawHeader("計時器");
  // 分頁
  static const char *const tabs[3] = {"計時", "倒數", "鬧鐘"};
  for (int i = 0; i < 3; i++) {
    int x = 8 + i * 104;
    bool sel = ui.tmrTab == i;
    bool pr = ui.pressed == B_TMR_TAB0 + i;
    gfx->fillRoundRect(x, 30, 100, 24, 10, pr ? COL_KEY_HI : (sel ? COL_ACCENT_D : COL_CARD));
    drawTextC(x + 50, 47, tabs[i], F_ZH12, sel ? COL_ACCENT : COL_MUTED);
  }

  if (ui.tmrTab == TT_SW) {
    char tb[24];
    tmrFormat(tmrSwElapsed(), tb, sizeof(tb), true);
    drawTextC(160, 110, tb, F_CLOCK, COL_ACCENT);
    // 開始／暫停、重設
    bool prS = ui.pressed == B_TMR_START, prR = ui.pressed == B_TMR_RESET;
    gfx->fillRoundRect(40, 150, 110, 40, 12, prS ? COL_KEY_HI : COL_ACCENT_D);
    gfx->fillRoundRect(170, 150, 110, 40, 12, prR ? COL_KEY_HI : COL_CARD);
    drawTextC(95, 176, gTmr.swRun ? "暫停" : "開始", F_ZH16, COL_TEXT);
    drawTextC(225, 176, "重設", F_ZH16, COL_TEXT);
  } else if (ui.tmrTab == TT_CD) {
    char tb[24];
    if (gTmr.cdRun || gTmr.cdLeft > 0) tmrFormat(gTmr.cdLeft, tb, sizeof(tb), false);
    else snprintf(tb, sizeof(tb), "%02u:%02u", gTmr.cdSetM, gTmr.cdSetS);
    drawTextC(160, 100, tb, F_CLOCK, gTmr.cdRun ? COL_WARN : COL_ACCENT);
    // +/- 分秒
    auto pm = [&](int x, uint8_t up, uint8_t dn, const char *lab) {
      bool pu = ui.pressed == up, pd = ui.pressed == dn;
      gfx->fillRoundRect(x, 120, 44, 28, 8, pu ? COL_KEY_HI : COL_CARD);
      gfx->fillRoundRect(x, 152, 44, 28, 8, pd ? COL_KEY_HI : COL_CARD);
      drawTextC(x + 22, 140, "+", F_MED, COL_TEXT);
      drawTextC(x + 22, 172, "−", F_MED, COL_TEXT);
      drawTextC(x + 22, 116, lab, F_ZH12, COL_MUTED);
    };
    if (!gTmr.cdRun) {
      pm(70, B_TMR_M_UP, B_TMR_M_DN, "分");
      pm(206, B_TMR_S_UP, B_TMR_S_DN, "秒");
    }
    bool prS = ui.pressed == B_TMR_START, prR = ui.pressed == B_TMR_RESET;
    gfx->fillRoundRect(40, 190, 110, 36, 12, prS ? COL_KEY_HI : COL_ACCENT_D);
    gfx->fillRoundRect(170, 190, 110, 36, 12, prR ? COL_KEY_HI : COL_CARD);
    drawTextC(95, 214, gTmr.cdRun ? "暫停" : "開始", F_ZH16, COL_TEXT);
    drawTextC(225, 214, "重設", F_ZH16, COL_TEXT);
  } else {
    // 鬧鐘
    char tb[16];
    snprintf(tb, sizeof(tb), "%02u:%02u", gTmr.almH, gTmr.almM);
    drawTextC(160, 100, tb, F_CLOCK, gTmr.almOn ? COL_WARN : COL_ACCENT);
    drawTextC(160, 118, gTmr.almLabel[0] ? gTmr.almLabel : "鬧鐘", F_ZH12, COL_MUTED);
    auto pm = [&](int x, uint8_t up, uint8_t dn, const char *lab) {
      bool pu = ui.pressed == up, pd = ui.pressed == dn;
      gfx->fillRoundRect(x, 128, 44, 28, 8, pu ? COL_KEY_HI : COL_CARD);
      gfx->fillRoundRect(x, 160, 44, 28, 8, pd ? COL_KEY_HI : COL_CARD);
      drawTextC(x + 22, 148, "+", F_MED, COL_TEXT);
      drawTextC(x + 22, 180, "−", F_MED, COL_TEXT);
      drawTextC(x + 22, 124, lab, F_ZH12, COL_MUTED);
    };
    pm(70, B_TMR_H_UP, B_TMR_H_DN, "時");
    pm(206, B_TMR_M_UP, B_TMR_M_DN, "分");
    bool pr = ui.pressed == B_ALM_TOGGLE;
    gfx->fillRoundRect(90, 198, 140, 32, 12, pr ? COL_KEY_HI : (gTmr.almOn ? COL_ACCENT_D : COL_CARD));
    drawTextC(160, 220, gTmr.almOn ? "已開啟（撳關閉）" : "已關閉（撳開啟）", F_ZH12, COL_TEXT);
  }
  drawTextC(160, 236, "提示：無喇叭，到時全屏閃光提示", F_ZH12, COL_MUTED);
  drawToast();
}

// ===================== WiFi 設定 =====================
static bool isSaved(const char *ssid) {
  for (int i = 0; i < gNet.savedCount; i++)
    if (strcmp(gNet.saved[i].ssid, ssid) == 0) return true;
  return false;
}
static int wifiRowCount() { return ui.wifiTab == 0 ? gNet.scanCount : gNet.savedCount; }
static int wifiMaxScroll() {
  int h = 240 - WF_LIST_Y;
  int total = wifiRowCount() * WF_ROW_H;
  return total > h ? total - h : 0;
}
static void drawWifiList() {
  gfx->fillScreen(COL_BG);
  STATE_LOCK();
  NetState n = gNet;  // 複製一份（約 1.3KB）
  STATE_UNLOCK();
  // ---- 列表 ----
  int rows = ui.wifiTab == 0 ? n.scanCount : n.savedCount;
  if (rows == 0) {
    const char *m;
    if (ui.wifiTab == 0) m = (n.scanState == 1) ? "掃描中…" : "找不到網絡，按右上角重新掃描";
    else m = "未有已儲存的網絡";
    if (ui.wifiTab == 0 && n.scanState == 1) spinner(160, 140, 14, ui.frame, COL_ACCENT);
    drawTextC(160, 182, m, F_ZH12, COL_MUTED);
  }
  for (int i = 0; i < rows; i++) {
    int y = WF_LIST_Y + i * WF_ROW_H - ui.wifiScroll;
    if (y > 240) break;
    if (y + WF_ROW_H < WF_LIST_Y) continue;
    if (i == ui.pressedRow) gfx->fillRoundRect(4, y + 1, 312, WF_ROW_H - 2, 8, COL_CARD_HI);
    if (ui.wifiTab == 0) {
      const ScanItem &s = n.scan[i];
      bool cur = n.connected && strcmp(s.ssid, n.ssid) == 0;
      iconWifi(20, y + 25, 13, rssiBars(s.rssi), true);
      drawText(40, y + 23, s.ssid[0] ? s.ssid : "（隱藏網絡）", F_ZH16, cur ? COL_ACCENT : COL_TEXT, 190);
      bool sv = false;
      for (int k = 0; k < n.savedCount; k++)
        if (strcmp(n.saved[k].ssid, s.ssid) == 0) sv = true;
      if (cur) drawTextR(288, 22, "已連線", F_ZH12, COL_OK);
      else if (sv) drawTextR(288, 22, "已儲存", F_ZH12, COL_MUTED);
      if (s.secure) iconLock(298, y + 11, COL_MUTED);
    } else {
      const SavedNet &s = n.saved[i];
      bool cur = n.connected && strcmp(s.ssid, n.ssid) == 0;
      drawText(14, y + 23, s.ssid, F_ZH16, cur ? COL_ACCENT : COL_TEXT, 186);
      if (cur) drawText(206, y + 22, "已連線", F_ZH12, COL_OK);
      gfx->fillRoundRect(262, y + 6, 50, 22, 11, RGB565(90, 30, 30));
      drawTextC(287, y + 22, "忘記", F_ZH12, COL_DANGER);
    }
    gfx->drawFastHLine(12, y + WF_ROW_H - 1, 296, 0x2104);
  }
  // ---- 上面：狀態 + 分頁（蓋住捲上去嘅行）----
  gfx->fillRect(0, HDR_H, 320, WF_LIST_Y - HDR_H - 2, COL_BG);
  card(4, WF_STATUS_Y, 312, 24, 8);
  if (n.connected) {
    gfx->fillCircle(16, WF_STATUS_Y + 12, 4, COL_OK);
    int w = drawText(26, WF_STATUS_Y + 17, "已連線：", F_ZH12, COL_MUTED);
    drawText(26 + w, WF_STATUS_Y + 17, n.ssid, F_ZH12, COL_TEXT, 150);
    drawTextR(308, WF_STATUS_Y + 16, n.ip, F_TINY, COL_MUTED);
  } else {
    gfx->fillCircle(16, WF_STATUS_Y + 12, 4, n.connecting ? COL_WARN : COL_DANGER);
    drawText(26, WF_STATUS_Y + 17, n.connecting ? "自動連線中…" : "未連線，請選擇網絡", F_ZH12, COL_TEXT);
  }
  for (int t = 0; t < 2; t++) {
    int x = 4 + t * 158;
    bool sel = ui.wifiTab == t;
    gfx->fillRoundRect(x, WF_TABS_Y, 154, 24, 12, sel ? COL_ACCENT_D : COL_CARD);
    char lb[24];
    if (t == 0) snprintf(lb, sizeof(lb), "附近網絡");
    else snprintf(lb, sizeof(lb), "已儲存（%u）", n.savedCount);
    drawTextC(x + 77, WF_TABS_Y + 17, lb, F_ZH12, sel ? COL_ACCENT : COL_MUTED);
  }
  drawHeader("WiFi 設定");
  if (ui.pressed == B_WADD) gfx->fillRoundRect(240, 2, 36, HDR_H - 4, 8, COL_CARD_HI);
  if (ui.pressed == B_WSCAN) gfx->fillRoundRect(280, 2, 38, HDR_H - 4, 8, COL_CARD_HI);
  iconPlus(258, 13, 6, COL_TEXT);
  if (n.scanState == 1) spinner(299, 13, 8, ui.frame, COL_ACCENT);
  else iconRefresh(299, 13, 7, COL_TEXT);
  drawToast();
}

// ---- 觸控鍵盤 ----
// WiFi 用 QWERTY（英文 / 數字符號兩頁）；巴士站 / 路線用「數字 + 大楷」一頁過（5 行）
enum { K_SHIFT = 1, K_BKSP = 2, K_MODE = 3, K_OK = 4, K_SYMTOG = 5, K_CLEAR = 6 };
struct Key {
  int16_t x, y, w, h;
  uint8_t code;
};
static Key gKeys[48];
static int gKeyN = 0;
static inline bool kbCodeMode() { return ui.kbMode == KM_STOP || ui.kbMode == KM_ROUTE; }
static void kbAdd(int x, int y, int w, uint8_t code, int h = KB_RH - 3) {
  if (gKeyN < 48) gKeys[gKeyN++] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, code};
}
static void kbLayout() {
  gKeyN = 0;
  if (kbCodeMode()) {
    static const char *const C[4] = {"1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"};
    int kh = KBC_RH - 3;
    for (int r = 0; r < 4; r++) {
      int y = KBC_Y0 + r * KBC_RH;
      int n = strlen(C[r]);
      int x0 = (320 - n * 32) / 2;
      if (r == 3) kbAdd(0, y, 48, K_CLEAR, kh);
      for (int i = 0; i < n; i++) kbAdd(x0 + i * 32, y, 32, (uint8_t)C[r][i], kh);
      if (r == 3) kbAdd(272, y, 48, K_BKSP, kh);
    }
    int y = KBC_Y0 + 4 * KBC_RH;
    if (ui.kbMode == KM_STOP) {  // 英文站名要用空格
      kbAdd(0, y, 192, ' ', kh);
      kbAdd(192, y, 128, K_OK, kh);
    } else {
      kbAdd(0, y, 320, K_OK, kh);
    }
    return;
  }
  static const char *const L[3] = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
  static const char *const S1[3] = {"1234567890", "@#$%&-+()", "*\"'.,!?"};
  static const char *const S2[3] = {"[]{}<>^|~`", "/\\:;=_", "$%&.,?!"};
  const char *const *R = ui.kbPage == 0 ? L : (ui.kbPage == 1 ? S1 : S2);
  for (int r = 0; r < 3; r++) {
    int y = KB_Y0 + r * KB_RH;
    int n = strlen(R[r]);
    int x0 = (r < 2) ? (320 - n * 32) / 2 : 48 + (224 - n * 32) / 2;
    if (r == 2) kbAdd(0, y, 48, ui.kbPage == 0 ? K_SHIFT : K_SYMTOG);
    for (int i = 0; i < n; i++) kbAdd(x0 + i * 32, y, 32, (uint8_t)R[r][i]);
    if (r == 2) kbAdd(272, y, 48, K_BKSP);
  }
  int y = KB_Y0 + 3 * KB_RH;
  kbAdd(0, y, 64, K_MODE);
  kbAdd(64, y, 160, ' ');
  kbAdd(224, y, 96, K_OK);
}
static char kbCharFor(uint8_t code) {
  if (ui.kbPage == 0 && ui.kbShift && code >= 'a' && code <= 'z') return code - 32;
  return (char)code;
}
static void drawKeyboard() {
  gfx->fillScreen(COL_BG);
  static const char *const titles[4] = {"輸入網絡名稱", "輸入密碼", "輸入巴士站號碼", "輸入路線號碼"};
  drawHeader(titles[ui.kbMode]);
  char sub[96];
  const char *ph = "", *okLabel = "";
  switch (ui.kbMode) {
    case KM_SSID:
      snprintf(sub, sizeof(sub), "手動加入網絡（例如隱藏 SSID）");
      ph = "SSID（最多 32 字元）";
      okLabel = "下一步";
      break;
    case KM_PASS:
      snprintf(sub, sizeof(sub), "網絡：%s", ui.kbSsid);
      ph = "密碼（開放網絡可留空）";
      okLabel = "連線";
      break;
    case KM_STOP:
      snprintf(sub, sizeof(sub), "第 %d 格：巴士站牌上嘅號碼，例如 YL395", ui.busSlot + 1);
      ph = "站牌號碼（或者英文站名）";
      okLabel = "搜尋";
      break;
    default:
      STATE_LOCK();
      if (gBusS.nStops) snprintf(sub, sizeof(sub), "巴士站：%s（%s）", gBusS.stops[0].name, gBusS.stops[0].code);
      else sub[0] = 0;
      STATE_UNLOCK();
      ph = "例如 276P";
      okLabel = "確定";
      break;
  }
  drawText(8, KB_BOX_Y - 4, sub, F_ZH12, COL_MUTED, 304);
  // 輸入框
  bool pass = ui.kbMode == KM_PASS;
  int bw = pass ? 266 : 308;
  gfx->fillRoundRect(6, KB_BOX_Y, bw, KB_BOX_H, 8, 0x0841);
  gfx->drawRoundRect(6, KB_BOX_Y, bw, KB_BOX_H, 8, COL_ACCENT);
  int len = strlen(ui.kbText);
  int tx = 14, ty = KB_BOX_Y + 21, maxW = bw - 22;
  int cursorX = tx;
  if (pass && !ui.kbShow) {
    int maxDots = maxW / 11;
    int start = len > maxDots ? len - maxDots : 0;
    for (int i = start; i < len; i++) gfx->fillCircle(tx + 4 + (i - start) * 11, KB_BOX_Y + 15, 4, COL_TEXT);
    cursorX = tx + (len - start) * 11;
  } else {
    const char *s = ui.kbText;
    while (*s && textW(s, F_MED) > maxW) s++;
    cursorX = tx + drawText(tx, ty, s, F_MED, COL_TEXT);
  }
  if ((ui.frame / 4) % 2 == 0) gfx->fillRect(cursorX + 1, KB_BOX_Y + 6, 2, KB_BOX_H - 12, COL_ACCENT);
  if (len == 0) drawText(tx + 8, ty - 2, ph, F_ZH12, 0x52AA);
  if (pass) {
    gfx->fillRoundRect(276, KB_BOX_Y, 38, KB_BOX_H, 8, ui.pressed == B_EYE ? COL_KEY_HI : COL_CARD);
    iconEye(295, KB_BOX_Y + 15, ui.kbShow, COL_TEXT);
  }
  // 按鍵
  kbLayout();
  for (int i = 0; i < gKeyN; i++) {
    const Key &k = gKeys[i];
    bool fn = k.code < 32;
    bool pr = (i == ui.kbPressed);
    uint16_t bg = pr ? COL_KEY_HI : (fn ? COL_KEY_FN : COL_KEY);
    if (k.code == K_OK) bg = pr ? COL_KEY_HI : COL_ACCENT_D;
    if (k.code == K_SHIFT && ui.kbShift) bg = ui.kbShift == 2 ? COL_ACCENT : 0x8C71;
    gfx->fillRoundRect(k.x + 2, k.y, k.w - 4, k.h, 6, bg);
    int cx = k.x + k.w / 2, cy = k.y + k.h / 2;
    switch (k.code) {
      case K_SHIFT: {
        uint16_t c = ui.kbShift ? COL_BG : COL_TEXT;
        gfx->fillTriangle(cx - 8, cy, cx + 8, cy, cx, cy - 9, c);
        gfx->fillRect(cx - 4, cy, 8, 7, c);
        if (ui.kbShift == 2) gfx->fillRect(cx - 6, cy + 9, 12, 2, c);
        break;
      }
      case K_BKSP:
        gfx->fillTriangle(cx - 12, cy, cx - 5, cy - 7, cx - 5, cy + 7, COL_TEXT);
        gfx->fillRect(cx - 5, cy - 7, 17, 15, COL_TEXT);
        thickLine(cx - 1, cy - 3, cx + 6, cy + 4, 2, bg);
        thickLine(cx + 6, cy - 3, cx - 1, cy + 4, 2, bg);
        break;
      case K_MODE: drawTextC(cx, cy + 5, ui.kbPage == 0 ? "?123" : "ABC", F_MED, COL_TEXT); break;
      case K_SYMTOG: drawTextC(cx, cy + 5, ui.kbPage == 1 ? "#+=" : "123", F_MED, COL_TEXT); break;
      case K_CLEAR: drawTextC(cx, cy + 5, "清除", F_ZH12, COL_TEXT); break;
      case K_OK: drawTextC(cx, cy + 6, okLabel, F_ZH16, COL_TEXT); break;
      case ' ': drawTextC(cx, cy + 5, "空格", F_ZH12, COL_MUTED); break;
      default: {
        char s[2] = {kbCharFor(k.code), 0};
        drawTextC(cx, cy + 6, s, F_MED, COL_TEXT);
      }
    }
  }
}

// ===================== 巴士站設定 =====================
static void routePill(int x, int y, const char *route, int minW = 0) {
  int pw = textW(route, F_MED) + 14;
  if (pw < minW) pw = minW;
  gfx->fillRoundRect(x, y, pw, 22, 6, COL_KMB);
  drawTextC(x + pw / 2, y + 16, route, F_MED, 0xFFFF);
}
static void iconChevron(int x, int cy, uint16_t c) {  // 「›」
  thickLine(x, cy - 6, x + 6, cy, 2, c);
  thickLine(x + 6, cy, x, cy + 6, 2, c);
}
// 呢條路線係咪已經喺某一格（回傳格號，冇 = -1）
static int busSlotOf(const char *stopId, const char *route, char dir, int except = -1) {
  for (int i = 0; i < BUS_MAX_SLOTS; i++)
    if (i != except && gBusCfg[i].used && strcmp(gBusCfg[i].stopId, stopId) == 0 && strcmp(gBusCfg[i].route, route) == 0 &&
        (!dir || !gBusCfg[i].dir || gBusCfg[i].dir == dir))
      return i;
  return -1;
}
// 路線列表（有 busFilter 就只要嗰條路線）。idx 放 gBusS.routes 嘅位置；回傳行數
static int busVisibleRoutes(uint8_t *idx) {
  int n = 0;
  for (int i = 0; i < gBusS.nRoutes; i++)
    if (!ui.busFilter[0] || strcmp(gBusS.routes[i].route, ui.busFilter) == 0) idx[n++] = i;
  return n;
}
static int busRowCount() {
  if (ui.busView == BV_STOPS) return gBusS.nStops;
  if (ui.busView == BV_ROUTES) {
    uint8_t idx[BS_MAX_ROUTES];
    return busVisibleRoutes(idx);
  }
  return 0;
}
static int busMaxScroll() {
  int h = 240 - BR_LIST_Y;
  int total = busRowCount() * BR_ROW_H;
  return total > h ? total - h : 0;
}
static void drawBusList() {
  gfx->fillScreen(COL_BG);
  drawHeader("巴士站設定");
  card(4, 30, 312, 24, 8);
  drawText(12, 47, "最多 3 條路線，每條可以係唔同巴士站", F_ZH12, COL_MUTED, 296);
  STATE_LOCK();
  BusSlot cfg[BUS_MAX_SLOTS];
  memcpy(cfg, gBusCfg, sizeof(cfg));
  STATE_UNLOCK();
  for (int i = 0; i < BUS_MAX_SLOTS; i++) {
    int y = BL_Y0 + i * BL_RH;
    bool pr = ui.pressedRow == i;
    card(4, y, 312, BL_RH - 4, 12, pr ? COL_CARD_HI : COL_CARD);
    if (cfg[i].used) {
      routePill(12, y + 13, cfg[i].route, 56);
      char l1[64], l2[80];
      snprintf(l1, sizeof(l1), "往 %s", cfg[i].dest[0] ? cfg[i].dest : "—");
      if (cfg[i].code[0]) snprintf(l2, sizeof(l2), "%s · %s", cfg[i].stopName, cfg[i].code);
      else snprintf(l2, sizeof(l2), "%s", cfg[i].stopName[0] ? cfg[i].stopName : cfg[i].stopId);
      drawText(78, y + 20, l1, F_ZH16, COL_TEXT, 208);
      drawText(78, y + 38, l2, F_ZH12, COL_MUTED, 208);
      iconChevron(296, y + 24, COL_MUTED);
    } else {
      gfx->drawRoundRect(12, y + 13, 56, 22, 6, COL_LINE);
      iconPlus(40, y + 24, 5, COL_ACCENT);
      drawText(78, y + 20, "新增路線", F_ZH16, COL_ACCENT);
      drawText(78, y + 38, "輸入巴士站號碼，例如 YL395", F_ZH12, COL_MUTED, 208);
    }
  }
  // 底部：還原預設
  gfx->fillRoundRect(6, 214, 84, 22, 11, ui.pressed == B_BRESET ? COL_KEY_HI : COL_CARD);
  drawTextC(48, 230, "還原預設", F_ZH12, COL_TEXT);
  drawTextR(312, 230, "撳一格可以更改或刪除", F_ZH12, COL_MUTED);
  drawToast();
}
static void drawBusStops() {
  gfx->fillScreen(COL_BG);
  STATE_LOCK();
  int n = gBusS.nStops;
  BusStopCand st[BS_MAX_STOPS];
  memcpy(st, gBusS.stops, sizeof(BusStopCand) * n);
  char q[33];
  strcpy(q, gBusS.query);
  STATE_UNLOCK();
  for (int i = 0; i < n; i++) {
    int y = BR_LIST_Y + i * BR_ROW_H - ui.busScroll;
    if (y > 240) break;
    if (y + BR_ROW_H < BR_LIST_Y) continue;
    if (i == ui.pressedRow) gfx->fillRoundRect(4, y + 1, 312, BR_ROW_H - 2, 8, COL_CARD_HI);
    drawText(12, y + 23, st[i].name, F_ZH16, COL_TEXT, 226);
    drawTextR(306, y + 22, st[i].code[0] ? st[i].code : "—", F_ZH12, COL_MUTED);
    gfx->drawFastHLine(12, y + BR_ROW_H - 1, 296, 0x2104);
  }
  gfx->fillRect(0, HDR_H, 320, BR_LIST_Y - HDR_H - 2, COL_BG);
  card(4, 30, 312, 24, 8);
  char info[96];
  snprintf(info, sizeof(info), "英文站名有「%s」：%d 個站%s", q, n, n >= BS_MAX_STOPS ? "（只列頭 8 個）" : "");
  drawText(12, 47, info, F_ZH12, COL_MUTED, 296);
  drawHeader("選擇巴士站");
  drawToast();
}
static void drawBusRoutes() {
  gfx->fillScreen(COL_BG);
  STATE_LOCK();
  uint8_t idx[BS_MAX_ROUTES];
  int n = busVisibleRoutes(idx);
  BusStopCand st0 = gBusS.stops[0];
  bool failed = gBusS.routesFailed;
  for (int r = 0; r < n; r++) {
    const BusRouteOpt &o = gBusS.routes[idx[r]];
    int y = BR_LIST_Y + r * BR_ROW_H - ui.busScroll;
    if (y > 240) break;
    if (y + BR_ROW_H < BR_LIST_Y) continue;
    if (r == ui.pressedRow) gfx->fillRoundRect(4, y + 1, 312, BR_ROW_H - 2, 8, COL_CARD_HI);
    routePill(10, y + 6, o.route, 50);
    char l1[48];
    snprintf(l1, sizeof(l1), "往 %s", o.dest[0] ? o.dest : "—");
    int slot = busSlotOf(gBusS.stops[o.stop].id, o.route, o.dir);
    const char *tag = slot >= 0 ? "已設定" : (o.serviceType > 1 ? "特別班次" : "");
    int tw = tag[0] ? textW(tag, F_ZH12) + 8 : 0;
    drawText(70, y + 23, l1, F_ZH16, COL_TEXT, 240 - tw);
    if (tag[0]) drawTextR(308, y + 22, tag, F_ZH12, slot >= 0 ? COL_OK : COL_MUTED);
    gfx->drawFastHLine(12, y + BR_ROW_H - 1, 296, 0x2104);
  }
  STATE_UNLOCK();
  if (n == 0) {
    if (failed) {
      drawTextC(160, 124, "網絡錯誤，攞唔到路線列表", F_ZH16, COL_TEXT);
      drawTextC(160, 148, "請檢查 WiFi 後返回再搜尋", F_ZH12, COL_MUTED);
      drawTextC(160, 168, "或撳右上角「手動輸入」路線號碼", F_ZH12, COL_MUTED);
    } else {
      drawTextC(160, 124, "站已搵到，暫時冇可用路線", F_ZH16, COL_TEXT);
      drawTextC(160, 148, "可能係暫時冇班次資料", F_ZH12, COL_MUTED);
      drawTextC(160, 168, "可撳右上角「手動輸入」路線號碼", F_ZH12, COL_MUTED);
    }
  }
  // 上面：站名（蓋住捲上去嘅行）
  gfx->fillRect(0, HDR_H, 320, BR_LIST_Y - HDR_H - 2, COL_BG);
  card(4, 30, 312, 24, 8);
  char info[96];
  if (ui.busFilter[0]) snprintf(info, sizeof(info), "%s 號有幾個方向，請揀一個", ui.busFilter);
  else if (st0.code[0]) snprintf(info, sizeof(info), "%s（%s）", st0.name, st0.code);
  else snprintf(info, sizeof(info), "%s", st0.name);
  gfx->fillCircle(16, 42, 4, COL_KMB);
  drawText(26, 47, info, F_ZH12, COL_TEXT, 220);
  char slot[24];
  snprintf(slot, sizeof(slot), "加到第 %d 格", ui.busSlot + 1);
  drawTextR(308, 47, slot, F_ZH12, COL_MUTED);
  drawHeader("選擇路線");
  if (ui.pressed == B_BMANUAL) gfx->fillRoundRect(236, 2, 82, HDR_H - 4, 8, COL_CARD_HI);
  drawTextR(310, 18, "手動輸入", F_ZH12, COL_ACCENT);
  drawToast();
}
static void drawBus() {
  switch (ui.busView) {
    case BV_KB: drawKeyboard(); break;
    case BV_STOPS: drawBusStops(); break;
    case BV_ROUTES: drawBusRoutes(); break;
    default: drawBusList(); break;
  }
}

// ---- 彈出視窗 ----
static int dlgButtons(const char **labels) {
  switch (ui.dlg) {
    case DLG_SAVED: labels[0] = "連線"; labels[1] = "忘記"; labels[2] = "取消"; return 3;
    case DLG_OK: labels[0] = "完成"; return 1;
    case DLG_FAIL: labels[0] = "重試"; labels[1] = "取消"; return 2;
    case DLG_BUS_SLOT: labels[0] = "更改"; labels[1] = "刪除"; labels[2] = "取消"; return 3;
    case DLG_BUS_FAIL: labels[0] = "好"; return 1;
    case DLG_BUS_RESET: labels[0] = "還原"; labels[1] = "取消"; return 2;
    case DLG_ALERT: labels[0] = "關閉"; return 1;
    default: return 0;
  }
}
static void dlgButtonRect(int i, int n, int *x, int *y, int *w, int *h) {
  int gap = 8, bw = (DLG_W - 24 - gap * (n - 1)) / n;
  *x = DLG_X + 12 + i * (bw + gap);
  *y = DLG_Y + DLG_H - 42;
  *w = bw;
  *h = 32;
}
static void drawDialog() {
  if (ui.dlg == DLG_NONE) return;
  dimCanvas();
  gfx->fillRoundRect(DLG_X, DLG_Y, DLG_W, DLG_H, 16, 0x2124);
  gfx->drawRoundRect(DLG_X, DLG_Y, DLG_W, DLG_H, 16, COL_LINE);
  int cx = DLG_X + DLG_W / 2;
  switch (ui.dlg) {
    case DLG_SAVED:
      drawTextC(cx, DLG_Y + 28, ui.dlgSsid, F_ZH16, COL_TEXT, DLG_W - 24);
      drawTextC(cx, DLG_Y + 54, "已儲存的網絡", F_ZH12, COL_MUTED);
      break;
    case DLG_CONNECTING:
      spinner(cx, DLG_Y + 40, 16, ui.frame, COL_ACCENT);
      drawTextC(cx, DLG_Y + 84, "連線中…", F_ZH16, COL_TEXT);
      drawTextC(cx, DLG_Y + 106, ui.dlgSsid, F_ZH12, COL_MUTED, DLG_W - 24);
      break;
    case DLG_OK:
      gfx->fillCircle(cx, DLG_Y + 26, 14, COL_OK);
      thickLine(cx - 6, DLG_Y + 26, cx - 1, DLG_Y + 31, 3, 0xFFFF);
      thickLine(cx - 1, DLG_Y + 31, cx + 7, DLG_Y + 21, 3, 0xFFFF);
      drawTextC(cx, DLG_Y + 60, "連線成功，已儲存", F_ZH16, COL_TEXT);
      drawTextC(cx, DLG_Y + 78, ui.dlgMsg, F_ZH12, COL_MUTED, DLG_W - 24);
      break;
    case DLG_FAIL:
      gfx->fillCircle(cx, DLG_Y + 26, 14, COL_DANGER);
      thickLine(cx - 5, DLG_Y + 21, cx + 5, DLG_Y + 31, 3, 0xFFFF);
      thickLine(cx + 5, DLG_Y + 21, cx - 5, DLG_Y + 31, 3, 0xFFFF);
      drawTextC(cx, DLG_Y + 60, "連線失敗", F_ZH16, COL_TEXT);
      drawTextC(cx, DLG_Y + 78, ui.dlgMsg, F_ZH12, COL_WARN, DLG_W - 24);
      break;
    case DLG_BUS_SLOT: {
      STATE_LOCK();
      BusSlot c = gBusCfg[ui.busSlot < BUS_MAX_SLOTS ? ui.busSlot : 0];
      STATE_UNLOCK();
      char l1[64], l2[80];
      snprintf(l1, sizeof(l1), "第 %d 格：%s 往%s", ui.busSlot + 1, c.route, c.dest);
      if (c.code[0]) snprintf(l2, sizeof(l2), "%s（%s）", c.stopName, c.code);
      else snprintf(l2, sizeof(l2), "%s", c.stopName);
      drawTextC(cx, DLG_Y + 30, l1, F_ZH16, COL_TEXT, DLG_W - 24);
      drawTextC(cx, DLG_Y + 54, l2, F_ZH12, COL_MUTED, DLG_W - 24);
      break;
    }
    case DLG_BUS_BUSY: {
      spinner(cx, DLG_Y + 40, 16, ui.frame, COL_ACCENT);
      drawTextC(cx, DLG_Y + 84, "搜尋中…", F_ZH16, COL_TEXT);
      char pg[40];
      STATE_LOCK();
      strcpy(pg, gBusS.progress);
      STATE_UNLOCK();
      drawTextC(cx, DLG_Y + 106, pg, F_ZH12, COL_MUTED, DLG_W - 24);
      break;
    }
    case DLG_BUS_FAIL:
      gfx->fillCircle(cx, DLG_Y + 26, 14, COL_DANGER);
      thickLine(cx - 5, DLG_Y + 21, cx + 5, DLG_Y + 31, 3, 0xFFFF);
      thickLine(cx + 5, DLG_Y + 21, cx - 5, DLG_Y + 31, 3, 0xFFFF);
      drawTextC(cx, DLG_Y + 60, "查詢失敗", F_ZH16, COL_TEXT);
      drawTextC(cx, DLG_Y + 78, ui.dlgMsg, F_ZH12, COL_WARN, DLG_W - 24);
      break;
    case DLG_ALERT: {
      uint16_t flash = ((ui.frame / 4) % 2) ? COL_WARN : COL_DANGER;
      gfx->fillRoundRect(DLG_X, DLG_Y - 10, DLG_W, DLG_H + 20, 16, flash);
      drawTextC(cx, DLG_Y + 36, gTmr.alert == ALERT_ALARM ? "鬧鐘" : "倒數結束", F_ZH16, 0x0000);
      char msg[40];
      if (gTmr.alert == ALERT_ALARM)
        snprintf(msg, sizeof(msg), "%02u:%02u  %s", gTmr.almH, gTmr.almM, gTmr.almLabel[0] ? gTmr.almLabel : "");
      else
        snprintf(msg, sizeof(msg), "時間到！");
      drawTextC(cx, DLG_Y + 62, msg, F_ZH12, 0x0000);
      break;
    }
    case DLG_BUS_RESET:
      drawTextC(cx, DLG_Y + 34, "還原預設路線？", F_ZH16, COL_TEXT);
      drawTextC(cx, DLG_Y + 58, "276、276P、268X（形點 II）", F_ZH12, COL_MUTED, DLG_W - 24);
      break;
    default: break;
  }
  const char *lb[3];
  int n = dlgButtons(lb);
  for (int i = 0; i < n; i++) {
    int x, y, w, h;
    dlgButtonRect(i, n, &x, &y, &w, &h);
    bool pr = ui.pressed == B_DLG0 + i;
    uint16_t bg = (i == 0) ? COL_ACCENT_D : COL_CARD_HI;
    bool danger = (ui.dlg == DLG_SAVED || ui.dlg == DLG_BUS_SLOT) && i == 1;
    if (danger) bg = RGB565(90, 30, 30);
    gfx->fillRoundRect(x, y, w, h, 10, pr ? COL_KEY_HI : bg);
    uint16_t fc = danger ? COL_DANGER : (i == 0 ? COL_ACCENT : COL_TEXT);
    drawTextC(x + w / 2, y + 21, lb[i], F_ZH16, fc);
  }
}

// ===================== 觸控狀態 / 啟動畫面 / 除錯 =====================
static const char *touchChipName(uint8_t chip) {
  switch (chip) {
    case TC_CST328: return "CST328";
    case TC_CST3530: return "CST3530";
    case TC_GT911: return "GT911";
    case TC_FT6X36: return "FT6x36";
    case TC_CST816: return "CST816";
    default: return "?";
  }
}
// 掃描見到嘅位址，例如 "0x40 0x41"
static void touchFoundList(char *out, size_t n) {
  out[0] = 0;
  size_t len = 0;
  int k = gTouch.devCount < TOUCH_FOUND_MAX ? gTouch.devCount : TOUCH_FOUND_MAX;
  for (int i = 0; i < k && len + 6 < n; i++) len += snprintf(out + len, n - len, "%s0x%02X", i ? " " : "", gTouch.found[i]);
  if (gTouch.devCount > TOUCH_FOUND_MAX && len + 4 < n) snprintf(out + len, n - len, " …");
}
// 觸控狀態文字（啟動畫面同 Serial 共用）。col = 第一行顏色
static void touchStatusText(char *l1, size_t n1, char *l2, size_t n2, uint16_t *col) {
  char lst[48];
  *col = COL_DANGER;
  switch (gTouch.stat) {
    case TS_OK:
      snprintf(l1, n1, "觸控：正常（%s @0x%02X）", touchChipName(gTouch.chip), gTouch.addr);
      snprintf(l2, n2, "撳一下畫面測試觸控");
      *col = COL_OK;
      break;
    case TS_OK_NOINFO:
      snprintf(l1, n1, "觸控：正常（%s @0x%02X）", touchChipName(gTouch.chip), gTouch.addr);
      snprintf(l2, n2, "讀唔到晶片資料（照用）；撳一下畫面測試觸控");
      *col = COL_OK;
      break;
    case TS_NO_CHIP:
      snprintf(l1, n1, "觸控：搵唔到晶片（0x1A／0x58 都冇回應）");
      snprintf(l2, n2, "I2C 上冇任何裝置；每 2 秒自動重試");
      break;
    case TS_OTHER_ADDR:
      touchFoundList(lst, sizeof(lst));
      snprintf(l1, n1, "觸控：唔認得嘅晶片（I2C 有 %s）", lst);
      snprintf(l2, n2, "可能係未支援嘅觸控晶片；請影低呢版畫面");
      break;
    case TS_BUS_STUCK:
      snprintf(l1, n1, "觸控：I2C 線路卡住（SDA=%d SCL=%d）", gTouch.sdaLow ? 0 : 1, gTouch.sclLow ? 0 : 1);
      snprintf(l2, n2, "線被拉低；請斷電重開，再唔得檢查硬件");
      break;
    case TS_BUS_FAIL:
      snprintf(l1, n1, "觸控：I2C 初始化失敗");
      snprintf(l2, n2, "每 2 秒自動重試");
      break;
    case TS_LOST:
      snprintf(l1, n1, "觸控：%s 冇回應（連線中斷）", gTouch.chip ? touchChipName(gTouch.chip) : "晶片");
      snprintf(l2, n2, "自動重試中");
      break;
    default:
      snprintf(l1, n1, "觸控：檢查中…");
      l2[0] = 0;
      *col = COL_MUTED;
      break;
  }
}
// 細十字（觸控位置）
static void touchCross(int x, int y, uint16_t c) {
  gfx->fillRect(x - 10, y - 1, 21, 3, 0x0000);  // 黑邊，喺任何背景都睇得清
  gfx->fillRect(x - 1, y - 10, 3, 21, 0x0000);
  gfx->drawFastHLine(x - 9, y, 19, c);
  gfx->drawFastVLine(x, y - 9, 19, c);
  gfx->drawCircle(x, y, 6, 0x0000);
  gfx->drawCircle(x, y, 5, c);
}
// 啟動畫面。showTouch：顯示觸控狀態；dotX >= 0：畫出啱啱撳到嘅位置
static void drawSplash(const char *msg, bool showTouch, int dotX = -1, int dotY = -1) {
  fillGradV(0, 0, 320, 240, RGB565(24, 30, 48), RGB565(8, 10, 16));
  // 校徽 + 校名
  gfx->fillCircle(160, 52, 50, RGB565(30, 38, 60));  // 淡淡嘅圓形底，令校徽喺深色背景更突出
  drawCrest(160 - CREST_L.w / 2, 10, CREST_L);
  drawTextC(160, 120, "粉嶺官立中學", F_ZH16, COL_TEXT);
  drawTextC(160, 136, "Fanling Government Secondary School", F_TINY, COL_MUTED);
  drawTextC(160, 166, msg, F_ZH16, COL_TEXT);
  if (!showTouch) return;
  char l1[80], l2[80];
  uint16_t col;
  touchStatusText(l1, sizeof(l1), l2, sizeof(l2), &col);
  drawTextC(160, 196, l1, F_ZH16, col, 312);
  if (dotX >= 0) {
    snprintf(l2, sizeof(l2), "收到觸控！畫面座標 %d, %d", dotX, dotY);
    drawTextC(160, 222, l2, F_ZH12, COL_OK, 312);
    touchCross(dotX, dotY, COL_SUN);
    gfx->fillCircle(dotX, dotY, 2, COL_SUN);
  } else if (l2[0]) {
    drawTextC(160, 222, l2, F_ZH12, COL_MUTED, 312);
  }
}
#if defined(TOUCH_DEBUG) && TOUCH_DEBUG
// TOUCH_DEBUG = 1：十字 = 手指位置（黃 = 撳緊，灰 = 最後一次）；左下角 raw / scr 座標
static void drawTouchDebug() {
  char b[64];
  if (gTouch.seen) {
    bool down = uiMillis() - gTouch.lastMs < 50;  // 放手後（>60ms）會重畫一次變灰
    touchCross(gTouch.x, gTouch.y, down ? COL_SUN : COL_MUTED);
  }
  gfx->fillRect(0, 214, 240, 26, 0x0000);
  gfx->setFont(F_TINY);
  gfx->setTextColor(gTouch.fail ? COL_DANGER : 0xFFFF);
  gfx->setCursor(3, 225);
  if (gTouch.seen) snprintf(b, sizeof(b), "raw %d,%d  scr %d,%d", gTouch.rawX, gTouch.rawY, gTouch.x, gTouch.y);
  else if (gTouch.fail) snprintf(b, sizeof(b), "TOUCH FAIL (stat %u)", gTouch.stat);
  else snprintf(b, sizeof(b), "no touch yet");
  gfx->print(b);
  gfx->setCursor(3, 237);
  snprintf(b, sizeof(b), "%s@%02X %ux%u r%d s%d%d%d INT%lu e%lu", touchChipName(gTouch.chip), gTouch.addr,
           gTouch.rawW, gTouch.rawH, TOUCH_ROTATION, TOUCH_SWAP_XY, TOUCH_MIRROR_X, TOUCH_MIRROR_Y,
           (unsigned long)gTouch.intCount, (unsigned long)gTouch.errCount);
  gfx->print(b);
}
#endif

// ===================== 總入口 =====================
static void drawScreen() {
  switch (ui.app) {
    case APP_HOME: drawHome(); break;
    case APP_DASH: drawDashboard(); break;
    case APP_WIFI:
      if (ui.wv == WV_KB) drawKeyboard();
      else drawWifiList();
      break;
    case APP_BUS: drawBus(); break;
    case APP_CAL: drawCalendar(); break;
    case APP_TMR: drawTimer(); break;
  }
  drawDialog();
#if defined(TOUCH_DEBUG) && TOUCH_DEBUG
  drawTouchDebug();
#endif
}
